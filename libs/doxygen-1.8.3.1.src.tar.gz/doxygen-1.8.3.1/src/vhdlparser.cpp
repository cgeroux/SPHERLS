/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0

/* Substitute the variable and function names.  */
#define yyparse vhdlScanYYparse
#define yylex   vhdlScanYYlex
#define yyerror vhdlScanYYerror
#define yylval  vhdlScanYYlval
#define yychar  vhdlScanYYchar
#define yydebug vhdlScanYYdebug
#define yynerrs vhdlScanYYnerrs


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     t_ABSTRLIST = 258,
     t_CHARLIST = 259,
     t_DIGIT = 260,
     t_STRING = 261,
     t_LETTER = 262,
     t_ACCESS = 263,
     t_AFTER = 264,
     t_ALIAS = 265,
     t_ALL = 266,
     t_AND = 267,
     t_ARCHITECTURE = 268,
     t_ARRAY = 269,
     t_ASSERT = 270,
     t_ATTRIBUTE = 271,
     t_BEGIN = 272,
     t_BLOCK = 273,
     t_BODY = 274,
     t_BUFFER = 275,
     t_BUS = 276,
     t_CASE = 277,
     t_COMPONENT = 278,
     t_CONFIGURATION = 279,
     t_CONSTANT = 280,
     t_DISCONNECT = 281,
     t_DOWNTO = 282,
     t_ELSE = 283,
     t_ELSIF = 284,
     t_END = 285,
     t_ENTITY = 286,
     t_EXIT = 287,
     t_FILE = 288,
     t_FOR = 289,
     t_FUNCTION = 290,
     t_GENERATE = 291,
     t_GENERIC = 292,
     t_GUARDED = 293,
     t_IF = 294,
     t_IN = 295,
     t_INOUT = 296,
     t_IS = 297,
     t_LABEL = 298,
     t_LIBRARY = 299,
     t_LINKAGE = 300,
     t_LOOP = 301,
     t_MAP = 302,
     t_NAND = 303,
     t_NEW = 304,
     t_NEXT = 305,
     t_NOR = 306,
     t_NULL = 307,
     t_OF = 308,
     t_ON = 309,
     t_OPEN = 310,
     t_OR = 311,
     t_OTHERS = 312,
     t_OUT = 313,
     t_PACKAGE = 314,
     t_PORT = 315,
     t_PROCEDURE = 316,
     t_PROCESS = 317,
     t_RANGE = 318,
     t_RECORD = 319,
     t_REGISTER = 320,
     t_REPORT = 321,
     t_RETURN = 322,
     t_SELECT = 323,
     t_SEVERITY = 324,
     t_SIGNAL = 325,
     t_SUBTYPE = 326,
     t_THEN = 327,
     t_TO = 328,
     t_TRANSPORT = 329,
     t_TYPE = 330,
     t_UNITS = 331,
     t_UNTIL = 332,
     t_USE = 333,
     t_VARIABLE = 334,
     t_WAIT = 335,
     t_WHEN = 336,
     t_WHILE = 337,
     t_WITH = 338,
     t_XOR = 339,
     t_IMPURE = 340,
     t_PURE = 341,
     t_GROUP = 342,
     t_POSTPONED = 343,
     t_SHARED = 344,
     t_XNOR = 345,
     t_SLL = 346,
     t_SRA = 347,
     t_SLA = 348,
     t_SRL = 349,
     t_ROR = 350,
     t_ROL = 351,
     t_UNAFFECTED = 352,
     t_ASSUME_GUARANTEE = 353,
     t_ASSUME = 354,
     t_CONTEXT = 355,
     t_COVER = 356,
     t_DEFAULT = 357,
     t_FAIRNESS = 358,
     t_FORCE = 359,
     t_INERTIAL = 360,
     t_LITERAL = 361,
     t_PARAMETER = 362,
     t_PROTECTED = 363,
     t_PROPERTY = 364,
     t_REJECT = 365,
     t_RELEASE = 366,
     t_RESTRICT = 367,
     t_RESTRICT_GUARANTEE = 368,
     t_SEQUENCE = 369,
     t_STRONG = 370,
     t_VMODE = 371,
     t_VPROP = 372,
     t_VUNIT = 373,
     t_SLSL = 374,
     t_SRSR = 375,
     t_QQ = 376,
     t_QGT = 377,
     t_QLT = 378,
     t_QG = 379,
     t_QL = 380,
     t_QEQU = 381,
     t_QNEQU = 382,
     t_GESym = 383,
     t_GTSym = 384,
     t_LESym = 385,
     t_LTSym = 386,
     t_NESym = 387,
     t_EQSym = 388,
     t_Ampersand = 389,
     t_Minus = 390,
     t_Plus = 391,
     MED_PRECEDENCE = 392,
     t_REM = 393,
     t_MOD = 394,
     t_Slash = 395,
     t_Star = 396,
     MAX_PRECEDENCE = 397,
     t_NOT = 398,
     t_ABS = 399,
     t_DoubleStar = 400,
     t_Apostrophe = 401,
     t_LeftParen = 402,
     t_RightParen = 403,
     t_Comma = 404,
     t_VarAsgn = 405,
     t_Colon = 406,
     t_Semicolon = 407,
     t_Arrow = 408,
     t_Box = 409,
     t_Bar = 410,
     t_Dot = 411,
     t_Q = 412,
     t_At = 413,
     t_Neg = 414,
     t_LEFTBR = 415,
     t_RIGHTBR = 416,
     t_ToolDir = 417
   };
#endif
/* Tokens.  */
#define t_ABSTRLIST 258
#define t_CHARLIST 259
#define t_DIGIT 260
#define t_STRING 261
#define t_LETTER 262
#define t_ACCESS 263
#define t_AFTER 264
#define t_ALIAS 265
#define t_ALL 266
#define t_AND 267
#define t_ARCHITECTURE 268
#define t_ARRAY 269
#define t_ASSERT 270
#define t_ATTRIBUTE 271
#define t_BEGIN 272
#define t_BLOCK 273
#define t_BODY 274
#define t_BUFFER 275
#define t_BUS 276
#define t_CASE 277
#define t_COMPONENT 278
#define t_CONFIGURATION 279
#define t_CONSTANT 280
#define t_DISCONNECT 281
#define t_DOWNTO 282
#define t_ELSE 283
#define t_ELSIF 284
#define t_END 285
#define t_ENTITY 286
#define t_EXIT 287
#define t_FILE 288
#define t_FOR 289
#define t_FUNCTION 290
#define t_GENERATE 291
#define t_GENERIC 292
#define t_GUARDED 293
#define t_IF 294
#define t_IN 295
#define t_INOUT 296
#define t_IS 297
#define t_LABEL 298
#define t_LIBRARY 299
#define t_LINKAGE 300
#define t_LOOP 301
#define t_MAP 302
#define t_NAND 303
#define t_NEW 304
#define t_NEXT 305
#define t_NOR 306
#define t_NULL 307
#define t_OF 308
#define t_ON 309
#define t_OPEN 310
#define t_OR 311
#define t_OTHERS 312
#define t_OUT 313
#define t_PACKAGE 314
#define t_PORT 315
#define t_PROCEDURE 316
#define t_PROCESS 317
#define t_RANGE 318
#define t_RECORD 319
#define t_REGISTER 320
#define t_REPORT 321
#define t_RETURN 322
#define t_SELECT 323
#define t_SEVERITY 324
#define t_SIGNAL 325
#define t_SUBTYPE 326
#define t_THEN 327
#define t_TO 328
#define t_TRANSPORT 329
#define t_TYPE 330
#define t_UNITS 331
#define t_UNTIL 332
#define t_USE 333
#define t_VARIABLE 334
#define t_WAIT 335
#define t_WHEN 336
#define t_WHILE 337
#define t_WITH 338
#define t_XOR 339
#define t_IMPURE 340
#define t_PURE 341
#define t_GROUP 342
#define t_POSTPONED 343
#define t_SHARED 344
#define t_XNOR 345
#define t_SLL 346
#define t_SRA 347
#define t_SLA 348
#define t_SRL 349
#define t_ROR 350
#define t_ROL 351
#define t_UNAFFECTED 352
#define t_ASSUME_GUARANTEE 353
#define t_ASSUME 354
#define t_CONTEXT 355
#define t_COVER 356
#define t_DEFAULT 357
#define t_FAIRNESS 358
#define t_FORCE 359
#define t_INERTIAL 360
#define t_LITERAL 361
#define t_PARAMETER 362
#define t_PROTECTED 363
#define t_PROPERTY 364
#define t_REJECT 365
#define t_RELEASE 366
#define t_RESTRICT 367
#define t_RESTRICT_GUARANTEE 368
#define t_SEQUENCE 369
#define t_STRONG 370
#define t_VMODE 371
#define t_VPROP 372
#define t_VUNIT 373
#define t_SLSL 374
#define t_SRSR 375
#define t_QQ 376
#define t_QGT 377
#define t_QLT 378
#define t_QG 379
#define t_QL 380
#define t_QEQU 381
#define t_QNEQU 382
#define t_GESym 383
#define t_GTSym 384
#define t_LESym 385
#define t_LTSym 386
#define t_NESym 387
#define t_EQSym 388
#define t_Ampersand 389
#define t_Minus 390
#define t_Plus 391
#define MED_PRECEDENCE 392
#define t_REM 393
#define t_MOD 394
#define t_Slash 395
#define t_Star 396
#define MAX_PRECEDENCE 397
#define t_NOT 398
#define t_ABS 399
#define t_DoubleStar 400
#define t_Apostrophe 401
#define t_LeftParen 402
#define t_RightParen 403
#define t_Comma 404
#define t_VarAsgn 405
#define t_Colon 406
#define t_Semicolon 407
#define t_Arrow 408
#define t_Box 409
#define t_Bar 410
#define t_Dot 411
#define t_Q 412
#define t_At 413
#define t_Neg 414
#define t_LEFTBR 415
#define t_RIGHTBR 416
#define t_ToolDir 417




/* Copy the first part of user declarations.  */


#include <stdio.h>
#include <qcstring.h>
#include <qstringlist.h>

#ifndef YYSTYPE
typedef int YYSTYPE;
#endif

struct  YYMM
{
  int itype;
  QCString qstr;
};

// define struct instead of union
#define YYSTYPE YYMM

#include "membergroup.h"
#include "vhdldocgen.h"
#include "doxygen.h"
#include "searchindex.h"
#include "vhdlscanner.h"
#include "commentscan.h"
#include "entry.h"
#include "arguments.h"
#include "memberdef.h"

//-----------------------------variables ---------------------------------------------------------------------------
//static MyParserVhdl* myconv=0;

static VhdlContainer s_str;

static QList<Entry>instFiles;
static int yyLineNr;
static Entry* lastCompound;
static Entry* currentCompound;
static Entry* lastEntity;
static Entry* current;
static Entry* tempEntry;
static Entry* current_root;
static QCString compSpec;
static QCString currName;
static int levelCounter;
static QCString confName;
static QCString genLabels;
static QCString lab;
static QCString forL;
static QList<VhdlConfNode> configL;


static int currP=0;

enum  { GEN_SEC=0x1, PARAM_SEC,CONTEXT_SEC,PROTECTED_SEC } ;

static int param_sec = 0;
static int parse_sec=0;


//---------------------------- functions --------------------------------------------------------------------------------

int vhdlScanYYlex ();
void vhdlScanYYerror (char const *);

static void addVhdlType(const QCString &name,int startLine,
                        int section,int spec,
			const char* args,const char* type,
			Protection prot=Public);
static void addCompInst(char *n, char* instName,char* comp,int line);

static void newEntry();
static void initEntry(Entry *e);


static void pushLabel(QCString &,QCString&);
static QCString popLabel(QCString&);
static void addConfigureNode(const char* a,const char*b,
                         bool isRoot,bool isLeave,bool inlineConf=FALSE);
//static bool addLibUseClause(const QCString &type);
static bool isFuncProcProced();
static void initEntry(Entry *e);
static void addProto(const char *s1,const char *s2,const char *s3,
                     const char *s4,const char *s5,const char *s6);
static void createFunction(const QCString &impure,int spec,
                           const QCString &fname);

static void createFlow();    

void newVhdlEntry()
{
  newEntry();
}

Entry* getCurrentVhdlEntry()
{
  return current;
}

void initVhdlParser()
{
  lastCompound=0;
  lastEntity=0;
  currentCompound=0;
  lastEntity=0;
  current_root=s_str.root;
  current=new Entry();
  initEntry(current);
}

QList<Entry> & getVhdlInstList()
{
  return instFiles;
}




/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef int YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 216 of yacc.c.  */


#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  26
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   2814

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  163
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  407
/* YYNRULES -- Number of rules.  */
#define YYNRULES  925
/* YYNRULES -- Number of states.  */
#define YYNSTATES  1594

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   417

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
     135,   136,   137,   138,   139,   140,   141,   142,   143,   144,
     145,   146,   147,   148,   149,   150,   151,   152,   153,   154,
     155,   156,   157,   158,   159,   160,   161,   162
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     5,     7,     9,    11,    13,    16,    18,
      20,    22,    24,    26,    28,    30,    32,    34,    37,    38,
      40,    43,    45,    49,    52,    53,    56,    58,    60,    62,
      64,    66,    68,    70,    72,    74,    78,    82,    84,    88,
      93,   101,   105,   106,   108,   109,   112,   113,   116,   118,
     119,   120,   125,   126,   127,   132,   136,   144,   150,   156,
     157,   159,   162,   164,   165,   168,   170,   176,   177,   185,
     191,   192,   194,   196,   199,   200,   203,   205,   211,   217,
     221,   222,   224,   227,   229,   230,   232,   235,   237,   240,
     242,   245,   249,   255,   261,   266,   267,   269,   272,   276,
     277,   280,   282,   284,   286,   288,   290,   292,   294,   296,
     298,   300,   302,   304,   306,   308,   310,   312,   314,   316,
     318,   320,   322,   324,   326,   328,   330,   332,   334,   336,
     338,   340,   342,   344,   346,   348,   350,   352,   355,   357,
     359,   361,   363,   365,   367,   369,   371,   373,   375,   377,
     379,   381,   383,   385,   387,   389,   391,   393,   395,   397,
     399,   401,   403,   405,   407,   409,   411,   413,   415,   417,
     419,   424,   426,   428,   431,   432,   437,   438,   446,   447,
     454,   456,   459,   460,   464,   465,   468,   469,   472,   474,
     476,   478,   479,   489,   496,   497,   499,   501,   503,   506,
     509,   512,   513,   516,   518,   523,   527,   528,   531,   534,
     536,   538,   541,   549,   550,   553,   554,   556,   558,   559,
     561,   562,   564,   566,   568,   570,   572,   574,   579,   580,
     583,   586,   591,   595,   599,   600,   603,   606,   610,   612,
     614,   616,   618,   622,   624,   626,   628,   630,   633,   635,
     637,   639,   641,   643,   645,   647,   649,   653,   657,   661,
     665,   669,   673,   677,   681,   685,   689,   693,   697,   701,
     704,   706,   709,   712,   715,   718,   722,   727,   731,   735,
     739,   743,   747,   751,   755,   759,   763,   767,   771,   775,
     779,   783,   787,   791,   795,   799,   803,   806,   809,   811,
     815,   817,   819,   821,   823,   827,   829,   831,   833,   835,
     837,   840,   843,   847,   849,   851,   853,   855,   857,   861,
     863,   865,   867,   869,   871,   873,   875,   877,   881,   883,
     885,   887,   890,   893,   895,   899,   904,   908,   912,   916,
     919,   925,   930,   934,   940,   944,   949,   953,   956,   957,
     959,   960,   962,   966,   968,   971,   972,   975,   978,   980,
     982,   984,   989,   994,   998,   999,  1002,  1004,  1006,  1008,
    1010,  1012,  1014,  1016,  1018,  1020,  1022,  1027,  1028,  1031,
    1034,  1041,  1044,  1046,  1047,  1050,  1052,  1055,  1060,  1068,
    1069,  1072,  1075,  1079,  1084,  1085,  1087,  1094,  1095,  1098,
    1100,  1105,  1108,  1112,  1118,  1122,  1125,  1127,  1128,  1130,
    1134,  1137,  1141,  1142,  1144,  1147,  1152,  1153,  1156,  1159,
    1161,  1163,  1165,  1169,  1171,  1175,  1177,  1179,  1186,  1187,
    1190,  1198,  1199,  1202,  1203,  1205,  1212,  1220,  1221,  1224,
    1226,  1228,  1230,  1233,  1235,  1237,  1239,  1241,  1249,  1256,
    1258,  1260,  1261,  1264,  1273,  1280,  1281,  1286,  1287,  1289,
    1297,  1300,  1302,  1304,  1305,  1308,  1311,  1317,  1325,  1330,
    1333,  1335,  1337,  1338,  1341,  1344,  1346,  1348,  1350,  1352,
    1354,  1356,  1358,  1360,  1362,  1364,  1366,  1368,  1370,  1372,
    1374,  1376,  1378,  1380,  1382,  1384,  1391,  1399,  1400,  1404,
    1409,  1410,  1413,  1418,  1424,  1426,  1428,  1430,  1435,  1441,
    1444,  1446,  1447,  1450,  1452,  1454,  1456,  1458,  1460,  1462,
    1464,  1466,  1467,  1483,  1484,  1486,  1487,  1490,  1492,  1493,
    1498,  1503,  1504,  1509,  1510,  1515,  1516,  1521,  1522,  1524,
    1526,  1530,  1533,  1535,  1539,  1541,  1543,  1545,  1546,  1556,
    1557,  1566,  1575,  1585,  1586,  1590,  1594,  1596,  1601,  1604,
    1608,  1610,  1615,  1618,  1622,  1624,  1629,  1632,  1637,  1640,
    1644,  1646,  1652,  1654,  1658,  1664,  1667,  1669,  1670,  1673,
    1676,  1679,  1680,  1683,  1686,  1688,  1691,  1693,  1695,  1698,
    1699,  1701,  1705,  1707,  1708,  1710,  1719,  1724,  1725,  1728,
    1733,  1734,  1737,  1739,  1742,  1743,  1752,  1757,  1761,  1762,
    1768,  1772,  1774,  1777,  1780,  1784,  1788,  1790,  1791,  1802,
    1807,  1808,  1812,  1813,  1815,  1816,  1818,  1819,  1821,  1824,
    1826,  1827,  1831,  1835,  1838,  1839,  1842,  1845,  1847,  1848,
    1851,  1853,  1855,  1858,  1860,  1862,  1864,  1866,  1868,  1870,
    1872,  1874,  1877,  1879,  1881,  1883,  1886,  1888,  1894,  1900,
    1901,  1904,  1905,  1908,  1909,  1911,  1912,  1914,  1916,  1917,
    1929,  1930,  1943,  1950,  1951,  1954,  1956,  1957,  1963,  1964,
    1975,  1976,  1977,  1981,  1982,  1985,  1986,  1992,  2001,  2002,
    2004,  2005,  2007,  2008,  2011,  2017,  2018,  2021,  2022,  2024,
    2030,  2031,  2034,  2035,  2037,  2040,  2043,  2047,  2048,  2050,
    2055,  2061,  2068,  2074,  2076,  2078,  2081,  2083,  2086,  2088,
    2091,  2095,  2100,  2106,  2107,  2110,  2111,  2114,  2115,  2118,
    2120,  2124,  2128,  2132,  2135,  2136,  2138,  2146,  2147,  2151,
    2152,  2156,  2157,  2166,  2172,  2173,  2176,  2178,  2179,  2182,
    2184,  2186,  2188,  2190,  2198,  2199,  2201,  2202,  2206,  2211,
    2215,  2220,  2228,  2231,  2236,  2239,  2243,  2245,  2247,  2249,
    2253,  2254,  2258,  2259,  2263,  2266,  2269,  2271,  2273,  2275,
    2277,  2281,  2290,  2298,  2306,  2309,  2310,  2312,  2314,  2318,
    2320,  2322,  2324,  2326,  2328,  2330,  2332,  2337,  2342,  2343,
    2346,  2348,  2350,  2353,  2355,  2357,  2359,  2361,  2367,  2373,
    2374,  2377,  2379,  2382,  2386,  2388,  2392,  2393,  2402,  2409,
    2411,  2414,  2416,  2419,  2421,  2423,  2425,  2433,  2442,  2449,
    2457,  2466,  2473,  2474,  2478,  2481,  2484,  2486,  2490,  2492,
    2495,  2498,  2508,  2517,  2526,  2532,  2537,  2540,  2542,  2545,
    2549,  2551,  2553,  2561,  2570,  2577,  2585,  2590,  2595,  2598,
    2608,  2617,  2619,  2621,  2630,  2631,  2633,  2639,  2641,  2646,
    2656,  2657,  2659,  2661,  2663,  2667,  2669,  2675,  2680,  2685,
    2691,  2694,  2702,  2708,  2710,  2715,  2717,  2719,  2721,  2723,
    2727,  2734,  2742,  2744,  2746,  2747,  2750,  2753,  2754,  2756,
    2757,  2764,  2769,  2775,  2782,  2786,  2787,  2791,  2798,  2800,
    2802,  2804,  2806,  2808,  2810,  2814,  2817,  2821,  2824,  2827,
    2831,  2833,  2838,  2841,  2845,  2848
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
     164,     0,    -1,   165,    -1,   410,    -1,   235,    -1,   166,
      -1,   174,    -1,   166,   174,    -1,   500,    -1,   502,    -1,
     503,    -1,   504,    -1,   501,    -1,   172,    -1,    52,    -1,
     504,    -1,   500,    -1,   171,   500,    -1,    -1,   503,    -1,
     503,   500,    -1,   500,    -1,   173,   149,   500,    -1,   175,
     176,    -1,    -1,   175,   177,    -1,   181,    -1,   196,    -1,
     202,    -1,   191,    -1,   208,    -1,   516,    -1,   521,    -1,
     178,    -1,   179,    -1,    44,   173,   152,    -1,    78,   180,
     152,    -1,   272,    -1,   180,   149,   272,    -1,   182,     1,
     468,   152,    -1,   182,   189,   187,   185,   184,   468,   152,
      -1,    31,   500,    42,    -1,    -1,   500,    -1,    -1,    17,
     360,    -1,    -1,   185,   186,    -1,   215,    -1,    -1,    -1,
      60,   188,   240,   152,    -1,    -1,    -1,    37,   190,   240,
     152,    -1,    37,     1,   152,    -1,   192,   194,    17,   360,
      30,   193,   152,    -1,   192,     1,    30,   193,   152,    -1,
      13,   500,    53,   500,    42,    -1,    -1,   500,    -1,    13,
     500,    -1,    13,    -1,    -1,   194,   195,    -1,   216,    -1,
     198,     1,    30,   199,   152,    -1,    -1,   198,   200,   473,
      30,   199,   152,   197,    -1,    24,   500,    53,   500,    42,
      -1,    -1,   500,    -1,    24,    -1,    24,   500,    -1,    -1,
     200,   201,    -1,   222,    -1,   203,     1,    30,   204,   152,
      -1,   203,   205,    30,   204,   152,    -1,    59,   500,    42,
      -1,    -1,   500,    -1,    59,   500,    -1,    59,    -1,    -1,
     207,    -1,   205,   206,    -1,   218,    -1,   558,   152,    -1,
     558,    -1,   558,   557,    -1,   558,   557,   152,    -1,   209,
       1,    30,   210,   152,    -1,   209,   211,    30,   210,   152,
      -1,    59,    19,   500,    42,    -1,    -1,   500,    -1,    59,
      19,    -1,    59,    19,   500,    -1,    -1,   211,   212,    -1,
     219,    -1,   202,    -1,   521,    -1,   208,    -1,   522,    -1,
     288,    -1,   312,    -1,   325,    -1,   337,    -1,   334,    -1,
     224,    -1,   179,    -1,   214,    -1,   235,    -1,   344,    -1,
     345,    -1,   340,    -1,   327,    -1,   330,    -1,   495,    -1,
     494,    -1,   213,    -1,   214,    -1,   235,    -1,   470,    -1,
     344,    -1,   345,    -1,   484,    -1,   340,    -1,   327,    -1,
     330,    -1,   495,    -1,   494,    -1,   213,    -1,   569,    -1,
     216,    -1,   217,   216,    -1,   214,    -1,   470,    -1,   344,
      -1,   345,    -1,   340,    -1,   327,    -1,   330,    -1,   495,
      -1,   494,    -1,   202,    -1,   521,    -1,   522,    -1,   214,
      -1,   235,    -1,   330,    -1,   495,    -1,   494,    -1,   344,
      -1,   345,    -1,   213,    -1,   214,    -1,   235,    -1,   344,
      -1,   345,    -1,   330,    -1,   495,    -1,   494,    -1,   213,
      -1,   220,    -1,   345,    -1,   179,    -1,   494,    -1,    78,
     118,   173,   152,    -1,    86,    -1,    85,    -1,   225,   152,
      -1,    -1,    61,   500,   226,   234,    -1,    -1,   223,    35,
     167,   227,   233,    67,   271,    -1,    -1,    35,   167,   228,
     233,    67,   271,    -1,   558,    -1,   558,   557,    -1,    -1,
     107,   231,   240,    -1,    -1,   232,   240,    -1,    -1,   229,
     230,    -1,   230,    -1,   229,    -1,   233,    -1,    -1,   225,
      42,   238,   236,    17,   422,    30,   237,   152,    -1,   225,
      42,     1,    30,   237,   152,    -1,    -1,   167,    -1,    35,
      -1,    61,    -1,    61,   500,    -1,    35,   500,    -1,    35,
       6,    -1,    -1,   238,   239,    -1,   220,    -1,   147,   243,
     241,   148,    -1,   147,     1,   148,    -1,    -1,   241,   242,
      -1,   152,   243,    -1,   556,    -1,   549,    -1,   247,   500,
      -1,   247,   173,   151,   246,   313,   245,   244,    -1,    -1,
     150,   259,    -1,    -1,    20,    -1,    21,    -1,    -1,   248,
      -1,    -1,   332,    -1,    40,    -1,    58,    -1,    41,    -1,
      20,    -1,    45,    -1,   147,   255,   250,   148,    -1,    -1,
     250,   251,    -1,   149,   255,    -1,   147,   256,   253,   148,
      -1,   147,     1,   148,    -1,   147,    55,   148,    -1,    -1,
     253,   254,    -1,   149,   256,    -1,   257,   153,   258,    -1,
     258,    -1,   154,    -1,   102,    -1,   259,    -1,   287,   153,
     259,    -1,   322,    -1,   269,    -1,   259,    -1,    55,    -1,
     105,   259,    -1,   261,    -1,   262,    -1,    91,    -1,    92,
      -1,    93,    -1,    94,    -1,    95,    -1,    96,    -1,   262,
     260,   262,    -1,   262,    12,   262,    -1,   262,    84,   262,
      -1,   262,    56,   262,    -1,   262,    51,   262,    -1,   262,
      90,   262,    -1,   262,    48,   262,    -1,   261,    48,   262,
      -1,   261,    51,   262,    -1,   261,    90,   262,    -1,   261,
      12,   262,    -1,   261,    56,   262,    -1,   261,    84,   262,
      -1,   121,   268,    -1,   268,    -1,   136,   268,    -1,   135,
     268,    -1,   144,   268,    -1,   143,   268,    -1,   268,   145,
     268,    -1,   135,   268,   145,   268,    -1,   262,   139,   262,
      -1,   262,   138,   262,    -1,   262,   134,   262,    -1,   262,
     141,   262,    -1,   262,   136,   262,    -1,   262,   135,   262,
      -1,   262,   130,   262,    -1,   262,   128,   262,    -1,   262,
     131,   262,    -1,   262,   129,   262,    -1,   262,   133,   262,
      -1,   262,   132,   262,    -1,   262,   140,   262,    -1,   262,
     127,   262,    -1,   262,   126,   262,    -1,   262,   125,   262,
      -1,   262,   124,   262,    -1,   262,   123,   262,    -1,   262,
     122,   262,    -1,   135,   265,    -1,   136,   265,    -1,   265,
      -1,   263,   264,   265,    -1,   134,    -1,   135,    -1,   136,
      -1,   267,    -1,   267,   266,   267,    -1,   141,    -1,   138,
      -1,   139,    -1,   140,    -1,   268,    -1,   144,   268,    -1,
     143,   268,    -1,   268,   145,   268,    -1,   269,    -1,   168,
      -1,   277,    -1,   279,    -1,   280,    -1,   147,   259,   148,
      -1,   271,    -1,   270,    -1,   560,    -1,   502,    -1,   276,
      -1,   274,    -1,   500,    -1,   272,    -1,   269,   156,   273,
      -1,   167,    -1,   504,    -1,    11,    -1,   271,   252,    -1,
     270,   252,    -1,   146,    -1,   271,   275,   500,    -1,   276,
     147,   259,   148,    -1,   270,   275,   500,    -1,   271,   275,
      63,    -1,   270,   275,    63,    -1,   278,   148,    -1,   147,
     284,   153,   259,   148,    -1,   147,   283,   149,   283,    -1,
     278,   149,   283,    -1,   271,   146,   147,   259,   148,    -1,
     271,   146,   277,    -1,    49,   271,   271,   282,    -1,    49,
     271,   281,    -1,    49,   279,    -1,    -1,   252,    -1,    -1,
     252,    -1,   284,   153,   259,    -1,   259,    -1,   287,   285,
      -1,    -1,   285,   286,    -1,   155,   287,    -1,   259,    -1,
     322,    -1,    57,    -1,    75,   500,     1,   152,    -1,    75,
     500,   289,   152,    -1,    75,     1,   152,    -1,    -1,    42,
     290,    -1,   291,    -1,   317,    -1,   294,    -1,   300,    -1,
     304,    -1,   306,    -1,   310,    -1,   311,    -1,   505,    -1,
     510,    -1,   147,   169,   292,   148,    -1,    -1,   292,   293,
      -1,   149,   169,    -1,   317,    76,   298,   296,    30,   295,
      -1,    76,   500,    -1,    76,    -1,    -1,   296,   297,    -1,
     299,    -1,   500,   152,    -1,   500,   133,   170,   152,    -1,
      14,   147,   303,   301,   148,    53,   313,    -1,    -1,   301,
     302,    -1,   149,   303,    -1,   271,    63,   154,    -1,    14,
     318,    53,   313,    -1,    -1,   500,    -1,    64,   309,   307,
      30,    64,   305,    -1,    -1,   307,   308,    -1,   309,    -1,
     173,   151,   313,   152,    -1,     8,   313,    -1,    33,    53,
     271,    -1,    71,   500,    42,   313,   152,    -1,    71,     1,
     152,    -1,   271,   314,    -1,   315,    -1,    -1,   252,    -1,
     271,   271,   317,    -1,   271,   317,    -1,   271,   271,   316,
      -1,    -1,   252,    -1,    63,   323,    -1,   147,   321,   319,
     148,    -1,    -1,   319,   320,    -1,   149,   321,    -1,   313,
      -1,   323,    -1,   315,    -1,   259,   324,   259,    -1,   276,
      -1,   263,   324,   263,    -1,    73,    -1,    27,    -1,    25,
     173,   151,   313,   326,   152,    -1,    -1,   150,   259,    -1,
      70,   173,   151,   313,   329,   328,   152,    -1,    -1,   150,
     259,    -1,    -1,   333,    -1,    79,   173,   151,   313,   331,
     152,    -1,    89,    79,   173,   151,   313,   331,   152,    -1,
      -1,   150,   259,    -1,    25,    -1,    70,    -1,    79,    -1,
      89,    79,    -1,    33,    -1,    75,    -1,    21,    -1,    65,
      -1,    10,   335,   336,    42,   269,   523,   152,    -1,    10,
     335,   336,    42,     1,   152,    -1,   500,    -1,   502,    -1,
      -1,   151,   313,    -1,    33,   173,   151,   313,    42,   339,
     259,   152,    -1,    33,   173,   151,   500,   338,   152,    -1,
      -1,    55,   259,    42,   259,    -1,    -1,   248,    -1,    26,
     341,   151,   271,     9,   259,   152,    -1,   269,   342,    -1,
      57,    -1,    11,    -1,    -1,   342,   343,    -1,   149,   269,
      -1,    16,   500,   151,   271,   152,    -1,    16,   500,    53,
     346,    42,   259,   152,    -1,   347,   523,   151,   350,    -1,
     167,   348,    -1,    57,    -1,    11,    -1,    -1,   348,   349,
      -1,   149,   167,    -1,    31,    -1,    13,    -1,    59,    -1,
      24,    -1,    23,    -1,    43,    -1,    75,    -1,    71,    -1,
      61,    -1,    35,    -1,    70,    -1,    79,    -1,    25,    -1,
      87,    -1,    33,    -1,    76,    -1,   106,    -1,   114,    -1,
     109,    -1,   352,    -1,    39,   259,    36,   403,   354,   353,
      -1,    39,   462,   259,    36,   403,   354,   353,    -1,    -1,
      28,    36,   403,    -1,    28,   462,    36,   403,    -1,    -1,
     354,   355,    -1,    29,   259,    36,   403,    -1,    29,   462,
     259,    36,   403,    -1,   358,    -1,   358,    -1,   359,    -1,
      34,   500,    40,   321,    -1,    34,   462,   500,    40,   321,
      -1,    82,   259,    -1,   361,    -1,    -1,   361,   362,    -1,
     363,    -1,   364,    -1,   383,    -1,   384,    -1,   385,    -1,
     379,    -1,   404,    -1,   410,    -1,    -1,   500,   151,    18,
     365,   374,   373,   371,   369,   367,    17,   360,    30,    18,
     366,   152,    -1,    -1,   500,    -1,    -1,   367,   368,    -1,
     216,    -1,    -1,    60,   240,   152,   370,    -1,    60,    47,
     249,   152,    -1,    -1,    37,   240,   152,   372,    -1,    -1,
      37,    47,   249,   152,    -1,    -1,   147,   259,   148,   374,
      -1,    -1,    42,    -1,   500,    -1,   375,   156,   500,    -1,
     375,   377,    -1,   375,    -1,   147,   500,   148,    -1,    24,
      -1,    31,    -1,    23,    -1,    -1,   500,   151,   269,   380,
      37,    47,   249,   382,   152,    -1,    -1,   500,   151,   269,
     381,    60,    47,   249,   152,    -1,   500,   151,   378,   376,
      60,    47,   249,   152,    -1,   500,   151,   378,   376,    37,
      47,   249,   382,   152,    -1,    -1,    60,    47,   249,    -1,
     500,   151,   427,    -1,   427,    -1,   500,   151,    88,   427,
      -1,    88,   427,    -1,   500,   151,   457,    -1,   457,    -1,
     500,   151,    88,   457,    -1,    88,   457,    -1,   500,   151,
     386,    -1,   386,    -1,   500,   151,    88,   386,    -1,    88,
     386,    -1,   500,   151,    88,   398,    -1,    88,   398,    -1,
     500,   151,   398,    -1,   398,    -1,   394,   130,   395,   387,
     152,    -1,   388,    -1,   388,    81,   259,    -1,   388,    81,
     259,    28,   387,    -1,   391,   389,    -1,    97,    -1,    -1,
     389,   390,    -1,   149,   391,    -1,   259,   392,    -1,    -1,
       9,   259,    -1,    52,   393,    -1,    52,    -1,     9,   259,
      -1,   269,    -1,   277,    -1,   397,   396,    -1,    -1,    74,
      -1,   110,   259,   105,    -1,   105,    -1,    -1,    38,    -1,
      83,   259,    68,   394,   130,   395,   399,   152,    -1,   400,
     388,    81,   284,    -1,    -1,   400,   401,    -1,   388,    81,
     284,   149,    -1,    -1,   217,    17,    -1,    17,    -1,   402,
     360,    -1,    -1,   500,   151,   405,   356,    36,   402,   360,
     406,    -1,   409,    30,   408,   152,    -1,    30,   408,   152,
      -1,    -1,   500,   151,   407,   351,   406,    -1,   500,   151,
     527,    -1,    36,    -1,    36,   500,    -1,    30,   152,    -1,
      30,   500,   152,    -1,   500,   151,   411,    -1,   411,    -1,
      -1,   414,   412,    62,   418,   416,    17,   422,    30,   413,
     152,    -1,     1,    30,   413,   152,    -1,    -1,   414,    62,
     415,    -1,    -1,    88,    -1,    -1,   500,    -1,    -1,    42,
      -1,   416,   417,    -1,   221,    -1,    -1,   147,    11,   148,
      -1,   147,   419,   148,    -1,   269,   420,    -1,    -1,   420,
     421,    -1,   149,   269,    -1,   423,    -1,    -1,   423,   424,
      -1,   425,    -1,   427,    -1,   462,   427,    -1,   432,    -1,
     450,    -1,   439,    -1,   446,    -1,   453,    -1,   456,    -1,
     457,    -1,   458,    -1,   462,   460,    -1,   460,    -1,   461,
      -1,   464,    -1,   462,   464,    -1,   426,    -1,   449,    66,
     259,   428,   152,    -1,    15,   259,   429,   428,   152,    -1,
      -1,    69,   259,    -1,    -1,    66,   259,    -1,    -1,   157,
      -1,    -1,   157,    -1,   500,    -1,    -1,    22,   430,   259,
     433,    42,   437,   435,    30,    22,   431,   152,    -1,    -1,
     462,    22,   430,   259,   434,    42,   437,   435,    30,    22,
     431,   152,    -1,    22,     1,    30,    22,   431,   152,    -1,
      -1,   435,   436,    -1,   437,    -1,    -1,    81,   284,   153,
     438,   422,    -1,    -1,    39,   259,    72,   440,   422,   443,
     441,    30,    39,   152,    -1,    -1,    -1,    28,   442,   422,
      -1,    -1,   443,   444,    -1,    -1,    29,   259,    72,   445,
     422,    -1,   449,   448,    46,   422,    30,    46,   447,   152,
      -1,    -1,   500,    -1,    -1,   357,    -1,    -1,   500,   151,
      -1,   449,    32,   452,   451,   152,    -1,    -1,    81,   259,
      -1,    -1,   500,    -1,   449,    50,   455,   454,   152,    -1,
      -1,    81,   259,    -1,    -1,   500,    -1,    52,   152,    -1,
     269,   152,    -1,    67,   459,   152,    -1,    -1,   259,    -1,
     394,   130,   388,   152,    -1,   394,   130,   542,   388,   152,
      -1,   394,   130,   104,   541,   259,   152,    -1,   394,   130,
     111,   541,   152,    -1,   535,    -1,   531,    -1,   463,   152,
      -1,   543,    -1,   462,   545,    -1,   545,    -1,   500,   151,
      -1,   394,   150,   259,    -1,   462,   394,   150,   259,    -1,
      80,   467,   466,   465,   152,    -1,    -1,    34,   259,    -1,
      -1,    77,   259,    -1,    -1,    54,   419,    -1,    30,    -1,
      30,    23,   183,    -1,    30,    13,   183,    -1,    30,    31,
     183,    -1,    30,   500,    -1,    -1,    42,    -1,    23,   500,
     469,   472,   471,   468,   152,    -1,    -1,    60,   240,   152,
      -1,    -1,    37,   240,   152,    -1,    -1,    34,   479,   477,
     475,   474,    30,    34,   152,    -1,    34,     1,    30,    34,
     152,    -1,    -1,   475,   476,    -1,   480,    -1,    -1,   477,
     478,    -1,   179,    -1,   269,    -1,   473,    -1,   481,    -1,
      34,   486,   483,   482,    30,    34,   152,    -1,    -1,   473,
      -1,    -1,   490,   489,   152,    -1,    78,   118,   173,   152,
      -1,    78,   488,   152,    -1,    34,   486,   485,   152,    -1,
      34,   486,   485,   152,    30,    34,   152,    -1,    78,   488,
      -1,    78,   118,   173,   152,    -1,   490,   489,    -1,   487,
     151,   259,    -1,   173,    -1,    11,    -1,    57,    -1,   491,
     490,   489,    -1,    -1,    60,    47,   249,    -1,    -1,    37,
      47,   249,    -1,    31,   269,    -1,    24,   271,    -1,    55,
      -1,   500,    -1,   504,    -1,   492,    -1,   493,   149,   492,
      -1,    87,   500,   151,   499,   147,   493,   148,   152,    -1,
      87,   500,    42,   147,   498,   148,   152,    -1,    87,   500,
      42,   147,     1,   152,   148,    -1,   350,   497,    -1,    -1,
     154,    -1,   496,    -1,   498,   149,   496,    -1,   500,    -1,
     502,    -1,     7,    -1,     5,    -1,     6,    -1,     3,    -1,
       4,    -1,   108,   506,    30,   508,    -1,   108,     1,    30,
     508,    -1,    -1,   506,   507,    -1,   509,    -1,   108,    -1,
     108,   500,    -1,   179,    -1,   345,    -1,   224,    -1,   522,
      -1,   108,    19,   511,    30,   513,    -1,   108,    19,     1,
      30,   513,    -1,    -1,   511,   512,    -1,   514,    -1,   108,
      19,    -1,   108,    19,   500,    -1,   220,    -1,   100,   180,
     152,    -1,    -1,   100,   500,    42,   517,   519,    30,   518,
     152,    -1,   100,   500,    42,    30,   518,   152,    -1,   100,
      -1,   100,   500,    -1,   520,    -1,   519,   520,    -1,   179,
      -1,   178,    -1,   515,    -1,    59,   500,    42,    49,   375,
     523,   152,    -1,    59,   500,    42,    49,   375,   523,   557,
     152,    -1,    59,     1,   500,    42,    49,   152,    -1,    35,
     500,    42,    49,   375,   523,   152,    -1,    35,   500,    42,
      49,   375,   523,   557,   152,    -1,    35,   500,    42,    49,
       1,   152,    -1,    -1,   160,   524,   161,    -1,   160,   161,
      -1,    67,   271,    -1,   525,    -1,   525,    67,   271,    -1,
     271,    -1,   525,   526,    -1,   149,   271,    -1,    22,   259,
      36,   529,   530,    30,    36,   408,   152,    -1,    22,   259,
      36,   529,    30,    36,   408,   152,    -1,    22,     1,    36,
       1,    30,    36,   408,   152,    -1,    81,   462,   284,   153,
     403,    -1,    81,   284,   153,   403,    -1,   529,   528,    -1,
     528,    -1,    30,   152,    -1,    30,   500,   152,    -1,   532,
      -1,   534,    -1,   394,   130,   391,    81,   259,   533,   152,
      -1,   394,   130,   542,   391,    81,   259,   533,   152,    -1,
     394,   130,   391,    81,   259,   152,    -1,   394,   130,   542,
     391,    81,   259,   152,    -1,   394,   130,     1,   152,    -1,
      28,   259,    81,   259,    -1,    28,   259,    -1,   394,   130,
     104,   541,   259,    81,   259,   544,   152,    -1,   394,   130,
     104,   541,   259,    81,   259,   152,    -1,   536,    -1,   540,
      -1,    83,   259,    68,   430,   394,   130,   537,   538,    -1,
      -1,   542,    -1,   391,    81,   284,   149,   538,    -1,   539,
      -1,   391,    81,   284,   152,    -1,    83,   259,    68,   430,
     394,   130,   104,   541,   546,    -1,    -1,    40,    -1,    58,
      -1,    74,    -1,   110,   259,   105,    -1,   105,    -1,   463,
      81,   259,   544,   152,    -1,   463,    81,   259,   152,    -1,
      28,   259,    81,   259,    -1,   544,    28,   259,    81,   259,
      -1,    28,   259,    -1,    83,   259,    68,   430,   548,   150,
     546,    -1,   259,    81,   284,   149,   546,    -1,   547,    -1,
     259,    81,   284,   152,    -1,   269,    -1,   277,    -1,   550,
      -1,   551,    -1,    61,   500,   554,    -1,    35,   552,   554,
      67,   271,   553,    -1,   223,    35,   552,   554,    67,   271,
     553,    -1,   500,    -1,   502,    -1,    -1,    42,   500,    -1,
      42,   154,    -1,    -1,   107,    -1,    -1,   107,   555,   147,
     243,   241,   148,    -1,   147,   243,   241,   148,    -1,    59,
     500,    42,    49,   375,    -1,    59,   500,    42,    49,   375,
     557,    -1,    37,    47,   249,    -1,    -1,    37,   559,   240,
      -1,   119,   561,   562,   151,   313,   120,    -1,    25,    -1,
      70,    -1,    79,    -1,   563,    -1,   564,    -1,   568,    -1,
     156,   567,   500,    -1,   156,   500,    -1,   565,   567,   500,
      -1,   565,   500,    -1,   159,   156,    -1,   565,   159,   156,
      -1,   500,    -1,   500,   147,   259,   148,    -1,   566,   156,
      -1,   567,   566,   156,    -1,   158,   375,    -1,   162,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   384,   384,   385,   386,   389,   391,   392,   395,   396,
     399,   400,   401,   402,   403,   406,   407,   409,   411,   412,
     414,   416,   417,   424,   426,   427,   429,   430,   431,   432,
     433,   434,   435,   438,   439,   442,   451,   466,   467,   473,
     475,   478,   488,   489,   491,   492,   494,   495,   498,   500,
     501,   501,   503,   504,   504,   505,   509,   510,   512,   520,
     521,   522,   523,   525,   526,   528,   530,   531,   531,   539,
     546,   547,   552,   553,   554,   555,   556,   558,   559,   560,
     574,   575,   576,   577,   579,   580,   581,   582,   584,   585,
     586,   587,   589,   590,   591,   598,   599,   600,   601,   603,
     604,   605,   612,   613,   614,   615,   618,   619,   620,   621,
     622,   623,   624,   626,   627,   628,   629,   630,   631,   632,
     633,   634,   635,   638,   639,   640,   641,   642,   643,   644,
     645,   646,   647,   648,   649,   650,   652,   653,   656,   657,
     658,   659,   660,   661,   662,   663,   664,   665,   666,   667,
     669,   670,   671,   672,   673,   674,   675,   676,   678,   679,
     680,   681,   682,   683,   684,   685,   687,   689,   690,   691,
     692,   697,   698,   700,   703,   702,   710,   709,   722,   721,
     735,   736,   739,   738,   742,   742,   746,   747,   748,   749,
     751,   754,   753,   767,   771,   772,   773,   774,   775,   776,
     777,   779,   781,   783,   789,   790,   791,   792,   793,   795,
     803,   815,   822,   842,   843,   844,   845,   846,   847,   848,
     849,   850,   852,   853,   854,   855,   856,   858,   859,   860,
     861,   863,   869,   870,   872,   873,   874,   876,   877,   878,
     879,   882,   883,   884,   886,   888,   889,   890,   896,   897,
     899,   900,   901,   902,   903,   904,   906,   907,   908,   909,
     910,   911,   912,   913,   914,   915,   916,   917,   918,   922,
     923,   924,   925,   926,   927,   928,   929,   933,   934,   935,
     936,   937,   938,   939,   940,   941,   942,   943,   944,   945,
     946,   947,   948,   949,   950,   951,   953,   954,   955,   956,
     959,   960,   961,   964,   965,   968,   969,   970,   971,   973,
     974,   975,   976,   978,   979,   980,   981,   982,   983,   985,
     986,   987,   988,   989,   990,   992,   993,   995,   997,   998,
     999,  1001,  1002,  1004,  1007,  1008,  1009,  1010,  1011,  1013,
    1014,  1016,  1017,  1019,  1020,  1022,  1023,  1024,  1025,  1026,
    1027,  1028,  1035,  1036,  1038,  1039,  1040,  1041,  1043,  1044,
    1045,  1050,  1051,  1057,  1059,  1060,  1062,  1063,  1064,  1065,
    1066,  1067,  1068,  1069,  1070,  1071,  1074,  1075,  1076,  1077,
    1079,  1088,  1089,  1091,  1092,  1093,  1095,  1097,  1099,  1108,
    1109,  1110,  1112,  1114,  1116,  1117,  1119,  1131,  1132,  1136,
    1138,  1140,  1142,  1148,  1152,  1153,  1154,  1155,  1156,  1158,
    1159,  1160,  1161,  1162,  1164,  1167,  1170,  1171,  1173,  1175,
    1176,  1178,  1179,  1181,  1182,  1184,  1185,  1191,  1200,  1201,
    1203,  1208,  1209,  1210,  1211,  1213,  1218,  1223,  1224,  1226,
    1227,  1228,  1229,  1230,  1231,  1233,  1234,  1236,  1244,  1246,
    1247,  1249,  1250,  1253,  1258,  1264,  1265,  1268,  1269,  1271,
    1274,  1275,  1276,  1277,  1278,  1279,  1285,  1291,  1298,  1300,
    1301,  1302,  1303,  1304,  1305,  1307,  1308,  1309,  1310,  1311,
    1312,  1313,  1314,  1315,  1316,  1317,  1318,  1319,  1320,  1321,
    1322,  1323,  1324,  1325,  1332,  1334,  1335,  1337,  1338,  1339,
    1340,  1341,  1342,  1343,  1345,  1347,  1348,  1350,  1363,  1370,
    1380,  1381,  1382,  1383,  1385,  1386,  1387,  1388,  1389,  1393,
    1394,  1396,  1396,  1403,  1404,  1405,  1406,  1407,  1408,  1409,
    1411,  1412,  1413,  1414,  1415,  1416,  1417,  1418,  1419,  1421,
    1422,  1425,  1426,  1428,  1430,  1431,  1432,  1434,  1434,  1438,
    1438,  1443,  1447,  1451,  1452,  1454,  1455,  1457,  1458,  1460,
    1461,  1463,  1464,  1466,  1467,  1469,  1470,  1472,  1473,  1475,
    1476,  1478,  1480,  1481,  1482,  1484,  1485,  1486,  1487,  1488,
    1490,  1491,  1492,  1493,  1494,  1495,  1497,  1498,  1500,  1502,
    1503,  1504,  1505,  1507,  1508,  1510,  1513,  1514,  1515,  1516,
    1518,  1519,  1520,  1526,  1529,  1528,  1534,  1535,  1538,  1537,
    1540,  1542,  1543,  1546,  1547,  1549,  1558,  1567,  1566,  1582,
    1584,  1585,  1587,  1588,  1590,  1591,  1593,  1594,  1595,  1596,
    1597,  1598,  1599,  1601,  1602,  1603,  1604,  1610,  1611,  1612,
    1613,  1614,  1615,  1616,  1617,  1618,  1619,  1620,  1621,  1622,
    1623,  1624,  1625,  1626,  1627,  1628,  1629,  1631,  1633,  1634,
    1635,  1636,  1637,  1639,  1640,  1642,  1643,  1644,  1648,  1647,
    1660,  1659,  1670,  1671,  1672,  1673,  1675,  1674,  1683,  1682,
    1695,  1697,  1696,  1706,  1707,  1709,  1708,  1714,  1722,  1723,
    1724,  1727,  1728,  1729,  1731,  1736,  1737,  1738,  1739,  1742,
    1748,  1749,  1750,  1751,  1753,  1755,  1760,  1761,  1762,  1764,
    1765,  1766,  1767,  1768,  1769,  1772,  1773,  1774,  1775,  1777,
    1778,  1779,  1781,  1786,  1787,  1788,  1789,  1790,  1791,  1797,
    1798,  1799,  1800,  1801,  1803,  1804,  1806,  1811,  1812,  1813,
    1814,  1816,  1816,  1820,  1821,  1822,  1823,  1824,  1825,  1826,
    1828,  1838,  1839,  1841,  1845,  1846,  1847,  1849,  1853,  1854,
    1859,  1863,  1868,  1871,  1875,  1880,  1886,  1887,  1888,  1890,
    1892,  1893,  1895,  1896,  1899,  1900,  1901,  1904,  1905,  1908,
    1909,  1912,  1919,  1925,  1928,  1930,  1931,  1933,  1934,  1938,
    1939,  1941,  1946,  1951,  1956,  1961,  1971,  1972,  1974,  1975,
    1976,  1977,  1978,  1980,  1981,  1982,  1983,  1985,  1986,  1988,
    1989,  1990,  1992,  1993,  1995,  2001,  2003,  2003,  2009,  2014,
    2015,  2017,  2018,  2020,  2021,  2022,  2024,  2032,  2037,  2039,
    2044,  2049,  2051,  2052,  2054,  2056,  2057,  2058,  2060,  2061,
    2062,  2064,  2065,  2066,  2068,  2069,  2070,  2071,  2073,  2074,
    2076,  2077,  2079,  2080,  2081,  2082,  2083,  2085,  2086,  2088,
    2089,  2091,  2092,  2094,  2097,  2098,  2100,  2101,  2103,  2105,
    2108,  2109,  2110,  2112,  2113,  2114,  2116,  2117,  2119,  2120,
    2121,  2123,  2125,  2126,  2128,  2130,  2131,  2133,  2134,  2136,
    2138,  2148,  2159,  2160,  2163,  2164,  2165,  2167,  2168,  2169,
    2169,  2173,  2175,  2180,  2186,  2189,  2188,  2199,  2206,  2207,
    2208,  2210,  2211,  2212,  2215,  2216,  2218,  2219,  2221,  2222,
    2224,  2225,  2228,  2229,  2231,  2233
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "t_ABSTRLIST", "t_CHARLIST", "t_DIGIT",
  "t_STRING", "t_LETTER", "t_ACCESS", "t_AFTER", "t_ALIAS", "t_ALL",
  "t_AND", "t_ARCHITECTURE", "t_ARRAY", "t_ASSERT", "t_ATTRIBUTE",
  "t_BEGIN", "t_BLOCK", "t_BODY", "t_BUFFER", "t_BUS", "t_CASE",
  "t_COMPONENT", "t_CONFIGURATION", "t_CONSTANT", "t_DISCONNECT",
  "t_DOWNTO", "t_ELSE", "t_ELSIF", "t_END", "t_ENTITY", "t_EXIT", "t_FILE",
  "t_FOR", "t_FUNCTION", "t_GENERATE", "t_GENERIC", "t_GUARDED", "t_IF",
  "t_IN", "t_INOUT", "t_IS", "t_LABEL", "t_LIBRARY", "t_LINKAGE", "t_LOOP",
  "t_MAP", "t_NAND", "t_NEW", "t_NEXT", "t_NOR", "t_NULL", "t_OF", "t_ON",
  "t_OPEN", "t_OR", "t_OTHERS", "t_OUT", "t_PACKAGE", "t_PORT",
  "t_PROCEDURE", "t_PROCESS", "t_RANGE", "t_RECORD", "t_REGISTER",
  "t_REPORT", "t_RETURN", "t_SELECT", "t_SEVERITY", "t_SIGNAL",
  "t_SUBTYPE", "t_THEN", "t_TO", "t_TRANSPORT", "t_TYPE", "t_UNITS",
  "t_UNTIL", "t_USE", "t_VARIABLE", "t_WAIT", "t_WHEN", "t_WHILE",
  "t_WITH", "t_XOR", "t_IMPURE", "t_PURE", "t_GROUP", "t_POSTPONED",
  "t_SHARED", "t_XNOR", "t_SLL", "t_SRA", "t_SLA", "t_SRL", "t_ROR",
  "t_ROL", "t_UNAFFECTED", "t_ASSUME_GUARANTEE", "t_ASSUME", "t_CONTEXT",
  "t_COVER", "t_DEFAULT", "t_FAIRNESS", "t_FORCE", "t_INERTIAL",
  "t_LITERAL", "t_PARAMETER", "t_PROTECTED", "t_PROPERTY", "t_REJECT",
  "t_RELEASE", "t_RESTRICT", "t_RESTRICT_GUARANTEE", "t_SEQUENCE",
  "t_STRONG", "t_VMODE", "t_VPROP", "t_VUNIT", "t_SLSL", "t_SRSR", "t_QQ",
  "t_QGT", "t_QLT", "t_QG", "t_QL", "t_QEQU", "t_QNEQU", "t_GESym",
  "t_GTSym", "t_LESym", "t_LTSym", "t_NESym", "t_EQSym", "t_Ampersand",
  "t_Minus", "t_Plus", "MED_PRECEDENCE", "t_REM", "t_MOD", "t_Slash",
  "t_Star", "MAX_PRECEDENCE", "t_NOT", "t_ABS", "t_DoubleStar",
  "t_Apostrophe", "t_LeftParen", "t_RightParen", "t_Comma", "t_VarAsgn",
  "t_Colon", "t_Semicolon", "t_Arrow", "t_Box", "t_Bar", "t_Dot", "t_Q",
  "t_At", "t_Neg", "t_LEFTBR", "t_RIGHTBR", "t_ToolDir", "$accept",
  "start", "design_file", "design_unit_list", "designator", "literal",
  "enumeration_literal", "physical_literal", "physical_literal_1",
  "physical_literal_no_default", "idf_list", "design_unit", "context_list",
  "lib_unit", "context_item", "lib_clause", "use_clause", "sel_list",
  "entity_decl", "entity_start", "entity_decl_5", "entity_decl_4",
  "entity_decl_3", "entity_decl_6", "entity_decl_2", "@1", "entity_decl_1",
  "@2", "arch_body", "arch_start", "arch_body_2", "arch_body_1",
  "arch_body_3", "config_decl", "@3", "config_start", "config_decl_2",
  "config_decl_1", "config_decl_3", "package_decl", "package_start",
  "package_decl_2", "package_decl_1", "package_decl_3", "package_decl_22",
  "package_body", "pack_body_start", "package_body_2", "package_body_1",
  "package_body_3", "common_decltve_item_1", "common_decltve_item",
  "entity_decltve_item", "block_decltve_item", "block_declarative_part",
  "package_decltve_item", "package_body_decltve_item",
  "subprog_decltve_item", "procs_decltve_item", "config_decltve_item",
  "func_prec", "subprog_decl", "subprog_spec", "@4", "@5", "@6",
  "subprog_spec_22", "subprog_spec_33", "@7", "@8", "subprog_spec_2",
  "subprog_spec_1", "subprog_body", "@9", "subprog_body_2",
  "subprog_body_1", "subprog_body_3", "interf_list", "interf_list_1",
  "interf_list_2", "interf_element", "interf_element_4",
  "interf_element_3", "interf_element_2", "interf_element_1", "mode",
  "association_list", "association_list_1", "association_list_2",
  "gen_association_list", "gen_association_list_1",
  "gen_association_list_2", "association_element",
  "gen_association_element", "formal_part", "actual_part", "expr",
  "shift_op", "and_relation", "relation", "simple_exp", "adding_op",
  "term", "multiplying_operator", "factor", "primary", "name", "name2",
  "mark", "sel_name", "suffix", "ifts_name", "sigma", "attribute_name",
  "aggregate", "element_association_list2", "qualified_expr", "allocator",
  "allocator_2", "allocator_1", "element_association", "choices",
  "choices_1", "choices_2", "choice", "type_decl", "type_decl_1",
  "type_definition", "enumeration_type_definition",
  "enumeration_type_definition_1", "enumeration_type_definition_2",
  "physical_type_definition", "unit_stat", "physical_type_definition_1",
  "physical_type_definition_2", "base_unit_decl", "secondary_unit_decl",
  "unconstrained_array_definition", "unconstrained_array_definition_1",
  "unconstrained_array_definition_2", "index_subtype_definition",
  "constrained_array_definition", "record_type_simple_name",
  "record_type_definition", "record_type_definition_1",
  "record_type_definition_2", "element_decl", "access_type_definition",
  "file_type_definition", "subtype_decl", "subtype_indic",
  "subtype_indic_1", "subtype_indic1", "subtype_indic1_1",
  "range_constraint", "index_constraint", "index_constraint_1",
  "index_constraint_2", "discrete_range", "discrete_range1", "range_spec",
  "direction", "constant_decl", "constant_decl_1", "signal_decl",
  "signal_decl_2", "signal_decl_1", "variable_decl", "variable_decl_1",
  "object_class", "signal_kind", "alias_decl", "alias_name_stat",
  "alias_spec", "file_decl", "fi_dec", "file_decl_1", "disconnection_spec",
  "signal_list", "signal_list_1", "signal_list_2", "attribute_decl",
  "attribute_spec", "entity_spec", "entity_name_list",
  "entity_name_list_1", "entity_name_list_2", "entity_class",
  "if_generation_scheme", "if_scheme", "if_scheme_2", "if_scheme_1",
  "if_scheme_3", "generation_scheme", "iteration_scheme", "for_scheme",
  "while_scheme", "concurrent_stats", "concurrent_stats_1",
  "concurrent_stats_2", "concurrent_stat", "block_stat", "@10",
  "block_stat_5", "block_stat_4", "block_stat_6", "block_stat_3",
  "block_stat_7", "block_stat_2", "block_stat_8", "block_stat_1",
  "block_stat_0", "dot_name", "mark_comp", "comp_1", "vcomp_stat",
  "comp_inst_stat", "@11", "@12", "comp_inst_stat_1",
  "concurrent_assertion_stat", "concurrent_procedure_call",
  "concurrent_signal_assign_stat", "condal_signal_assign",
  "condal_wavefrms", "wavefrm", "wavefrm_1", "wavefrm_2",
  "wavefrm_element", "wavefrm_element_1", "wavefrm_element_2", "target",
  "opts", "opts_2", "opts_1", "sel_signal_assign", "sel_wavefrms",
  "sel_wavefrms_1", "sel_wavefrms_2", "gen_stat1",
  "generate_statement_body", "generate_stat", "@13", "opstat", "@14",
  "generate_stat_1", "end_stats", "procs_stat", "procs_stat1", "@15",
  "procs_stat1_3", "procs_stat1_5", "procs_stat1_6", "procs_stat1_2",
  "procs_stat1_4", "procs_stat1_1", "sensitivity_list",
  "sensitivity_list_1", "sensitivity_list_2", "seq_stats", "seq_stats_1",
  "seq_stats_2", "seq_stat", "report_statement", "assertion_stat",
  "assertion_stat_2", "assertion_stat_1", "choice_stat", "choice_stat_1",
  "case_stat", "@16", "@17", "case_stat_1", "case_stat_2",
  "case_stat_alternative", "@18", "if_stat", "@19", "if_stat_2", "@20",
  "if_stat_1", "if_stat_3", "@21", "loop_stat", "loop_stat_3",
  "loop_stat_2", "loop_stat_1", "exit_stat", "exit_stat_2", "exit_stat_1",
  "next_stat", "next_stat_2", "next_stat_1", "null_stat",
  "procedure_call_stat", "return_stat", "return_stat_1",
  "signal_assign_stat", "variable_assign_stat", "lable",
  "variable_assign_stat_1", "wait_stat", "wait_stat_3", "wait_stat_2",
  "wait_stat_1", "comp_end_dec", "iss", "comp_decl", "comp_decl_2",
  "comp_decl_1", "block_config", "@22", "block_config_2", "block_config_3",
  "block_config_1", "block_config_4", "block_spec", "config_item",
  "comp_config", "comp_config_2", "comp_config_1", "config_spec",
  "comp_spec_stat", "comp_spec", "inst_list", "binding_indic",
  "binding_indic_2", "binding_indic_1", "entity_aspect",
  "group_constituent", "group_constituent_list", "group_declaration",
  "group_template_declaration", "entity_class_entry", "tbox",
  "entity_class_entry_list", "group_name", "t_Identifier",
  "t_BitStringLit", "t_StringLit", "t_AbstractLit", "t_CharacterLit",
  "protected_type_declaration", "protected_stats", "protected_stat_decl_1",
  "protected_stat_1", "protected_type_declaration_item",
  "protected_type_body", "protected_body_stats",
  "protected_body_stat_decl_1", "protected_body_stat_1",
  "protected_type_body_declaration_item", "context_ref", "context_decl",
  "@23", "context_stat_1", "libustcont_stats", "libustcont_stat",
  "package_instantiation_decl", "subprogram_instantiation_decl",
  "signature", "signature1", "mark_stats", "mark_stats_1", "case_scheme",
  "when_stats_1", "when_stats", "ttend", "conditional_signal_assignment",
  "conditional_waveform_assignment", "else_wave_list",
  "conditional_force_assignment", "selected_signal_assignment",
  "selected_waveform_assignment", "delay_stat", "sel_wave_list",
  "sel_wave_list_1", "selected_force_assignment", "inout_stat",
  "delay_mechanism", "conditional_variable_assignment", "else_stat",
  "selected_variable_assignment", "sel_var_list", "sel_var_list_1",
  "select_name", "interface_subprogram_decl", "iproc", "ifunc",
  "func_name", "return_is", "param", "@24", "interface_package_decl",
  "gen_assoc_list", "gen_interface_list", "@25", "external_name",
  "sig_stat", "external_pathname", "absolute_pathname",
  "relative_pathname", "neg_list", "pathname_element",
  "pathname_element_list", "package_path_name", "tool_directive", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,   364,
     365,   366,   367,   368,   369,   370,   371,   372,   373,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,   387,   388,   389,   390,   391,   392,   393,   394,
     395,   396,   397,   398,   399,   400,   401,   402,   403,   404,
     405,   406,   407,   408,   409,   410,   411,   412,   413,   414,
     415,   416,   417
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint16 yyr1[] =
{
       0,   163,   164,   164,   164,   165,   166,   166,   167,   167,
     168,   168,   168,   168,   168,   169,   169,   170,   171,   171,
     172,   173,   173,   174,   175,   175,   176,   176,   176,   176,
     176,   176,   176,   177,   177,   178,   179,   180,   180,   181,
     181,   182,   183,   183,   184,   184,   185,   185,   186,   187,
     188,   187,   189,   190,   189,   189,   191,   191,   192,   193,
     193,   193,   193,   194,   194,   195,   196,   197,   196,   198,
     199,   199,   199,   199,   200,   200,   201,   202,   202,   203,
     204,   204,   204,   204,   205,   205,   205,   206,   207,   207,
     207,   207,   208,   208,   209,   210,   210,   210,   210,   211,
     211,   212,   213,   213,   213,   213,   214,   214,   214,   214,
     214,   214,   214,   215,   215,   215,   215,   215,   215,   215,
     215,   215,   215,   216,   216,   216,   216,   216,   216,   216,
     216,   216,   216,   216,   216,   216,   217,   217,   218,   218,
     218,   218,   218,   218,   218,   218,   218,   218,   218,   218,
     219,   219,   219,   219,   219,   219,   219,   219,   220,   220,
     220,   220,   220,   220,   220,   220,   221,   222,   222,   222,
     222,   223,   223,   224,   226,   225,   227,   225,   228,   225,
     229,   229,   231,   230,   232,   230,   233,   233,   233,   233,
     234,   236,   235,   235,   237,   237,   237,   237,   237,   237,
     237,   238,   238,   239,   240,   240,   241,   241,   242,   243,
     243,   243,   243,   244,   244,   245,   245,   245,   246,   246,
     247,   247,   248,   248,   248,   248,   248,   249,   250,   250,
     251,   252,   252,   252,   253,   253,   254,   255,   255,   255,
     255,   256,   256,   256,   257,   258,   258,   258,   259,   259,
     260,   260,   260,   260,   260,   260,   261,   261,   261,   261,
     261,   261,   261,   261,   261,   261,   261,   261,   261,   262,
     262,   262,   262,   262,   262,   262,   262,   262,   262,   262,
     262,   262,   262,   262,   262,   262,   262,   262,   262,   262,
     262,   262,   262,   262,   262,   262,   263,   263,   263,   263,
     264,   264,   264,   265,   265,   266,   266,   266,   266,   267,
     267,   267,   267,   268,   268,   268,   268,   268,   268,   269,
     269,   269,   270,   270,   270,   271,   271,   272,   273,   273,
     273,   274,   274,   275,   276,   276,   276,   276,   276,   277,
     277,   278,   278,   279,   279,   280,   280,   280,   281,   281,
     282,   282,   283,   283,   284,   285,   285,   286,   287,   287,
     287,   288,   288,   288,   289,   289,   290,   290,   290,   290,
     290,   290,   290,   290,   290,   290,   291,   292,   292,   293,
     294,   295,   295,   296,   296,   297,   298,   299,   300,   301,
     301,   302,   303,   304,   305,   305,   306,   307,   307,   308,
     309,   310,   311,   312,   312,   313,   313,   314,   314,   315,
     315,   315,   316,   316,   317,   318,   319,   319,   320,   321,
     321,   322,   322,   323,   323,   324,   324,   325,   326,   326,
     327,   328,   328,   329,   329,   330,   330,   331,   331,   332,
     332,   332,   332,   332,   332,   333,   333,   334,   334,   335,
     335,   336,   336,   337,   337,   338,   338,   339,   339,   340,
     341,   341,   341,   342,   342,   343,   344,   345,   346,   347,
     347,   347,   348,   348,   349,   350,   350,   350,   350,   350,
     350,   350,   350,   350,   350,   350,   350,   350,   350,   350,
     350,   350,   350,   350,   351,   352,   352,   353,   353,   353,
     354,   354,   355,   355,   356,   357,   357,   358,   358,   359,
     360,   361,   361,   362,   363,   363,   363,   363,   363,   363,
     363,   365,   364,   366,   366,   367,   367,   368,   369,   369,
     370,   371,   371,   372,   372,   373,   373,   374,   374,   375,
     375,   376,   376,   377,   378,   378,   378,   380,   379,   381,
     379,   379,   379,   382,   382,   383,   383,   383,   383,   384,
     384,   384,   384,   385,   385,   385,   385,   385,   385,   385,
     385,   386,   387,   387,   387,   388,   388,   389,   389,   390,
     391,   392,   392,   392,   392,   393,   394,   394,   395,   396,
     396,   396,   396,   397,   397,   398,   399,   400,   400,   401,
     402,   402,   402,   403,   405,   404,   406,   406,   407,   404,
     404,   408,   408,   409,   409,   410,   410,   412,   411,   411,
     413,   413,   414,   414,   415,   415,   416,   416,   416,   417,
     418,   418,   418,   419,   420,   420,   421,   422,   423,   423,
     424,   425,   425,   425,   425,   425,   425,   425,   425,   425,
     425,   425,   425,   425,   425,   425,   425,   426,   427,   428,
     428,   429,   429,   430,   430,   431,   431,   431,   433,   432,
     434,   432,   432,   435,   435,   436,   438,   437,   440,   439,
     441,   442,   441,   443,   443,   445,   444,   446,   447,   447,
     448,   448,   449,   449,   450,   451,   451,   452,   452,   453,
     454,   454,   455,   455,   456,   457,   458,   459,   459,   460,
     460,   460,   460,   460,   460,   461,   461,   461,   461,   462,
     463,   463,   464,   465,   465,   466,   466,   467,   467,   468,
     468,   468,   468,   468,   469,   469,   470,   471,   471,   472,
     472,   474,   473,   473,   475,   475,   476,   477,   477,   478,
     479,   480,   480,   481,   482,   482,   483,   483,   483,   483,
     484,   484,   485,   485,   485,   486,   487,   487,   487,   488,
     489,   489,   490,   490,   491,   491,   491,   492,   492,   493,
     493,   494,   495,   495,   496,   497,   497,   498,   498,   499,
     499,   500,   501,   502,   503,   504,   505,   505,   506,   506,
     507,   508,   508,   509,   509,   509,   509,   510,   510,   511,
     511,   512,   513,   513,   514,   515,   517,   516,   516,   518,
     518,   519,   519,   520,   520,   520,   521,   521,   521,   522,
     522,   522,   523,   523,   523,   524,   524,   524,   525,   525,
     526,   527,   527,   527,   528,   528,   529,   529,   530,   530,
     531,   531,   532,   532,   532,   532,   532,   533,   533,   534,
     534,   535,   535,   536,   537,   537,   538,   538,   539,   540,
     541,   541,   541,   542,   542,   542,   543,   543,   544,   544,
     544,   545,   546,   546,   547,   548,   548,   549,   549,   550,
     551,   551,   552,   552,   553,   553,   553,   554,   554,   555,
     554,   554,   556,   556,   557,   559,   558,   560,   561,   561,
     561,   562,   562,   562,   563,   563,   564,   564,   565,   565,
     566,   566,   567,   567,   568,   569
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     1,     1,     1,     1,     2,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     2,     0,     1,
       2,     1,     3,     2,     0,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     3,     3,     1,     3,     4,
       7,     3,     0,     1,     0,     2,     0,     2,     1,     0,
       0,     4,     0,     0,     4,     3,     7,     5,     5,     0,
       1,     2,     1,     0,     2,     1,     5,     0,     7,     5,
       0,     1,     1,     2,     0,     2,     1,     5,     5,     3,
       0,     1,     2,     1,     0,     1,     2,     1,     2,     1,
       2,     3,     5,     5,     4,     0,     1,     2,     3,     0,
       2,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     2,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       4,     1,     1,     2,     0,     4,     0,     7,     0,     6,
       1,     2,     0,     3,     0,     2,     0,     2,     1,     1,
       1,     0,     9,     6,     0,     1,     1,     1,     2,     2,
       2,     0,     2,     1,     4,     3,     0,     2,     2,     1,
       1,     2,     7,     0,     2,     0,     1,     1,     0,     1,
       0,     1,     1,     1,     1,     1,     1,     4,     0,     2,
       2,     4,     3,     3,     0,     2,     2,     3,     1,     1,
       1,     1,     3,     1,     1,     1,     1,     2,     1,     1,
       1,     1,     1,     1,     1,     1,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     2,
       1,     2,     2,     2,     2,     3,     4,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     2,     2,     1,     3,
       1,     1,     1,     1,     3,     1,     1,     1,     1,     1,
       2,     2,     3,     1,     1,     1,     1,     1,     3,     1,
       1,     1,     1,     1,     1,     1,     1,     3,     1,     1,
       1,     2,     2,     1,     3,     4,     3,     3,     3,     2,
       5,     4,     3,     5,     3,     4,     3,     2,     0,     1,
       0,     1,     3,     1,     2,     0,     2,     2,     1,     1,
       1,     4,     4,     3,     0,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     4,     0,     2,     2,
       6,     2,     1,     0,     2,     1,     2,     4,     7,     0,
       2,     2,     3,     4,     0,     1,     6,     0,     2,     1,
       4,     2,     3,     5,     3,     2,     1,     0,     1,     3,
       2,     3,     0,     1,     2,     4,     0,     2,     2,     1,
       1,     1,     3,     1,     3,     1,     1,     6,     0,     2,
       7,     0,     2,     0,     1,     6,     7,     0,     2,     1,
       1,     1,     2,     1,     1,     1,     1,     7,     6,     1,
       1,     0,     2,     8,     6,     0,     4,     0,     1,     7,
       2,     1,     1,     0,     2,     2,     5,     7,     4,     2,
       1,     1,     0,     2,     2,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     6,     7,     0,     3,     4,
       0,     2,     4,     5,     1,     1,     1,     4,     5,     2,
       1,     0,     2,     1,     1,     1,     1,     1,     1,     1,
       1,     0,    15,     0,     1,     0,     2,     1,     0,     4,
       4,     0,     4,     0,     4,     0,     4,     0,     1,     1,
       3,     2,     1,     3,     1,     1,     1,     0,     9,     0,
       8,     8,     9,     0,     3,     3,     1,     4,     2,     3,
       1,     4,     2,     3,     1,     4,     2,     4,     2,     3,
       1,     5,     1,     3,     5,     2,     1,     0,     2,     2,
       2,     0,     2,     2,     1,     2,     1,     1,     2,     0,
       1,     3,     1,     0,     1,     8,     4,     0,     2,     4,
       0,     2,     1,     2,     0,     8,     4,     3,     0,     5,
       3,     1,     2,     2,     3,     3,     1,     0,    10,     4,
       0,     3,     0,     1,     0,     1,     0,     1,     2,     1,
       0,     3,     3,     2,     0,     2,     2,     1,     0,     2,
       1,     1,     2,     1,     1,     1,     1,     1,     1,     1,
       1,     2,     1,     1,     1,     2,     1,     5,     5,     0,
       2,     0,     2,     0,     1,     0,     1,     1,     0,    11,
       0,    12,     6,     0,     2,     1,     0,     5,     0,    10,
       0,     0,     3,     0,     2,     0,     5,     8,     0,     1,
       0,     1,     0,     2,     5,     0,     2,     0,     1,     5,
       0,     2,     0,     1,     2,     2,     3,     0,     1,     4,
       5,     6,     5,     1,     1,     2,     1,     2,     1,     2,
       3,     4,     5,     0,     2,     0,     2,     0,     2,     1,
       3,     3,     3,     2,     0,     1,     7,     0,     3,     0,
       3,     0,     8,     5,     0,     2,     1,     0,     2,     1,
       1,     1,     1,     7,     0,     1,     0,     3,     4,     3,
       4,     7,     2,     4,     2,     3,     1,     1,     1,     3,
       0,     3,     0,     3,     2,     2,     1,     1,     1,     1,
       3,     8,     7,     7,     2,     0,     1,     1,     3,     1,
       1,     1,     1,     1,     1,     1,     4,     4,     0,     2,
       1,     1,     2,     1,     1,     1,     1,     5,     5,     0,
       2,     1,     2,     3,     1,     3,     0,     8,     6,     1,
       2,     1,     2,     1,     1,     1,     7,     8,     6,     7,
       8,     6,     0,     3,     2,     2,     1,     3,     1,     2,
       2,     9,     8,     8,     5,     4,     2,     1,     2,     3,
       1,     1,     7,     8,     6,     7,     4,     4,     2,     9,
       8,     1,     1,     8,     0,     1,     5,     1,     4,     9,
       0,     1,     1,     1,     3,     1,     5,     4,     4,     5,
       2,     7,     5,     1,     4,     1,     1,     1,     1,     3,
       6,     7,     1,     1,     0,     2,     2,     0,     1,     0,
       6,     4,     5,     6,     3,     0,     3,     6,     1,     1,
       1,     1,     1,     1,     3,     2,     3,     2,     2,     3,
       1,     4,     2,     3,     2,     1
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       0,     0,   791,     0,     0,   172,   171,   623,     0,     2,
      24,     6,     0,     0,     0,     4,     3,   616,   617,     0,
     620,   793,   178,     8,     9,   174,     1,     7,     0,     0,
       0,     0,     0,     0,     0,    23,    25,    33,    34,    26,
       0,    29,     0,    27,     0,    28,     0,    30,     0,    31,
      32,     0,     0,     0,     0,     0,     0,   184,   186,     0,
       0,     0,     0,    21,     0,     0,     0,     0,     0,     0,
     320,   319,   326,   324,   323,   325,   322,   321,     0,     0,
       0,    49,     0,     0,     0,     0,     0,   905,     0,    85,
      89,     0,     0,   176,     0,   191,   630,   615,   619,   624,
     182,   189,   188,     0,     0,   180,   190,   175,     0,     0,
      41,     0,    35,     0,     0,    79,   908,   909,   910,     0,
       0,    36,     0,   333,     0,   332,     0,   331,     0,     0,
     816,   729,     0,     0,     0,    50,    46,    59,     0,     0,
     511,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   925,   112,    64,   102,   104,   134,   123,
      65,   111,     0,   124,   106,   107,   108,   130,   131,   110,
     109,   129,   126,   127,   125,   128,   133,   132,   103,   105,
     135,    70,     0,     0,     0,     0,   168,    75,    76,   167,
       0,   169,    80,     0,    80,     0,   147,    86,   138,    87,
       0,   143,   144,   142,   140,   141,   139,   146,   145,   148,
     149,     0,    88,    90,    95,    95,   100,   157,   150,   101,
     151,   152,   155,   156,   154,   153,   184,   194,   165,   158,
     203,   159,     0,   202,   162,   160,   161,   164,   163,     0,
     626,   621,   625,     0,   187,     0,   185,     0,   181,     0,
       0,    22,     0,    94,     0,     0,     0,     0,     0,   911,
     912,     0,   913,   326,   795,   330,   328,   327,   329,     0,
     794,   792,     0,    14,     0,   360,     0,     0,     0,     0,
       0,     0,   314,    13,   234,   241,   248,   249,   270,   313,
     319,   326,   315,     0,   316,   317,     0,   421,   243,    12,
      10,    11,   338,   336,   337,   334,     0,   319,     0,     0,
      42,    42,    42,   733,    39,    55,     0,     0,    44,    62,
       0,    60,   451,   449,   450,     0,     0,     0,   734,     0,
     462,   461,   463,     0,     0,   767,   768,   766,   772,     0,
       8,     0,     0,     0,     0,     0,     0,     0,     0,   173,
      72,     0,    71,     0,     0,   750,   747,     0,     0,    70,
      83,     0,    81,   906,     0,     0,    91,     0,     0,    96,
       0,     0,   196,   197,   195,     0,   638,     0,   634,     0,
     627,     0,   183,     0,   439,   443,     0,     0,     0,   440,
     444,   441,     0,     0,   206,     0,   221,   210,   887,   888,
     209,   179,    58,    69,     0,   832,   539,   915,     0,     0,
     924,   918,     0,     0,   917,     0,   232,   348,   347,   233,
     269,   272,   271,   274,   273,   358,     0,     0,   355,   359,
       0,   426,   425,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   250,   251,   252,   253,
     254,   255,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   333,   412,   410,   339,     0,     0,
      20,   335,   819,     0,     0,   824,   823,   825,     0,   821,
     731,    43,   730,   732,    54,     0,   511,     0,    47,   122,
     113,    48,   114,   118,   119,   117,   115,   116,   121,   120,
      61,    57,     0,     0,     0,     0,    59,     0,     0,   623,
       0,   586,   587,   512,   513,   514,   518,   515,   516,   517,
     564,     0,   570,   519,   520,   556,   560,   325,   735,   739,
       0,   460,     0,     0,     0,     0,     0,   770,     0,     0,
       0,   404,     0,   363,     0,     0,     0,     0,     0,     0,
       0,    73,    66,     0,   744,     0,     0,    82,    77,    78,
       0,   904,    97,    92,    93,     0,   200,   199,   198,   193,
       0,   692,   631,   633,   632,   638,   166,   629,   628,   205,
     892,   893,   897,     0,   897,   442,     0,     0,     0,    21,
     828,     0,     0,     0,     0,   922,   914,     0,   407,     0,
     406,   919,   916,   349,   350,   346,     0,   318,     0,     0,
     354,   231,     0,   235,   422,   266,   263,   264,   267,   268,
     265,   257,   262,   260,   259,   258,   261,   295,   294,   293,
     292,   291,   290,   284,   286,   283,   285,   288,   287,   279,
     282,   281,   278,   277,   289,   280,   256,   275,     0,     0,
       0,     0,     0,   298,   303,   309,   423,   414,     0,   344,
     413,   411,   409,   353,   342,     0,   242,   820,   818,     0,
       0,   822,    51,    45,     0,   452,     0,   471,   470,   472,
       0,   832,   319,     0,   661,     0,   566,   568,   558,   562,
     705,   593,     0,     0,   737,   428,     0,   464,   319,     0,
     325,     0,     0,     0,   776,     0,   762,   772,   760,     0,
     764,   765,     0,   433,     0,   361,     0,     0,     0,     0,
       0,     0,   365,   366,   368,   369,   370,   371,   372,   373,
     367,   374,   375,   362,   437,     0,     0,   789,   790,     0,
       0,   749,   741,   748,   170,    67,   246,   240,     0,   239,
     228,     0,   238,   245,   313,    98,   177,   194,     0,     0,
       0,   707,   727,     0,     0,   639,   640,   656,   641,   643,
     645,   646,   690,   644,   647,   648,   649,   650,   652,   653,
       0,     0,   654,   325,   714,   850,   851,   713,   861,   862,
     716,   718,     0,   635,     0,   898,   220,     0,     0,   889,
     897,   204,   220,   207,   218,   540,     0,   834,   838,     0,
     836,   826,     0,     0,   923,   331,   405,   907,   351,   345,
     276,   341,   352,     0,   356,   236,   296,   297,   311,   310,
     300,   301,   302,     0,     0,   306,   307,   308,   305,     0,
       0,   358,     0,   815,     0,    40,     0,   832,   469,     0,
       0,   466,    56,     0,   659,     0,   594,     0,   589,   521,
       0,   546,   544,   545,   623,   547,     0,   563,   569,     0,
       0,   555,   559,   610,     0,     0,     0,     0,     0,   465,
       0,   457,     0,     0,   773,   775,   774,     0,   770,     0,
       0,     0,   832,   445,   446,   431,   434,   403,   401,     0,
       0,     0,     0,   397,     0,     0,     0,   377,    16,    15,
       0,     0,     0,     0,   476,   479,   478,   487,   475,   489,
     484,   480,   477,   483,   485,   482,   481,   490,   486,   488,
     491,   493,   492,   785,   787,     0,     0,   437,   743,     0,
     751,     0,   745,   746,   752,    68,   247,     0,     0,     0,
       0,   664,     0,     0,   704,   708,     0,     0,   725,     0,
       0,     0,   697,     0,   702,     0,     0,   691,   505,   506,
       0,   663,   586,     0,   642,   651,   655,   717,     0,   715,
     719,   636,   620,     0,   206,     0,     0,     0,   208,   225,
     222,   224,   226,   223,     0,   219,   319,   833,     0,     0,
     839,   827,   921,   340,   358,   357,   299,   424,   304,   312,
     343,   352,   817,   448,     0,     0,   473,     0,     0,   662,
       0,     0,     0,   576,   581,     0,   572,   577,   590,   592,
       0,   588,   537,     0,     0,   565,   567,   557,   561,     0,
       0,   542,     0,     0,   504,     0,     0,   494,   740,     0,
       0,   429,   427,     0,   458,     0,     0,   454,   763,   769,
       0,   771,   831,     0,     0,     0,   319,   389,   419,   416,
     420,     0,   319,     0,     0,     0,     0,     0,     0,   803,
     805,   804,   799,   800,   806,     0,   383,     0,   438,   435,
       0,   786,   784,     0,     0,   779,     0,   777,   778,     0,
     756,   325,     0,   227,     0,   229,   237,   192,     0,   668,
     678,   706,   728,     0,   723,   663,     0,   873,   870,   875,
       0,   870,     0,   577,     0,   720,   695,   698,     0,     0,
     700,   703,   659,   509,   638,     0,     0,     0,     0,   220,
       0,   894,   902,     0,   215,   319,   840,   447,   474,   467,
     468,   660,   658,   593,     0,   584,   580,   571,     0,   575,
       0,   538,   535,     0,     0,     0,     0,     0,   541,     0,
       0,   600,     0,     0,   325,     0,   609,     0,   738,   736,
     459,     0,     0,   761,   829,     0,   432,   430,     0,     0,
       0,   393,     0,     0,   398,   399,   801,   797,     0,     0,
     814,   810,   811,   796,   376,     0,   378,     0,   386,   783,
     782,   788,     0,     0,   436,     0,   754,   770,     0,   230,
     665,     0,   638,   726,     0,     0,     0,   856,   871,   872,
       0,     0,     0,   709,     0,     0,   577,     0,     0,     0,
       0,   719,     0,     0,     0,     0,   670,   721,     0,   877,
       0,   618,   206,   901,     0,   890,   903,   894,   216,   217,
     213,   597,   582,     0,   583,   573,     0,   578,   591,     0,
     531,     0,     0,   847,     0,     0,     0,     0,     0,     0,
     602,   136,     0,   511,   600,     0,   611,   613,     0,     0,
       0,   453,   456,   830,   392,     0,     0,   390,   415,     0,
     417,   400,   394,   802,     0,   808,   807,   379,     0,   384,
     385,     0,   781,   780,     0,     0,   755,     0,     0,   742,
     666,     0,   667,     0,   683,   724,   722,   586,   587,     0,
       0,     0,   874,   712,     0,   710,     0,   696,   694,     0,
     319,   507,   701,   699,   657,     0,     0,   880,     0,   876,
       0,   896,   895,   891,     0,   212,     0,     0,   585,     0,
     579,     0,     0,   528,     0,     0,     0,     0,   846,     0,
     553,     0,   543,   553,     0,   601,   137,     0,   511,   500,
     600,   612,   607,   614,     0,     0,   319,   391,   418,   396,
     395,   812,   382,   380,    18,     0,   759,     0,   757,   672,
       0,   673,   680,   864,     0,     0,   711,     0,   854,     0,
       0,   508,   688,     0,     0,     0,   900,   214,   595,     0,
     598,   574,   537,     0,     0,   525,     0,   600,     0,     0,
     848,     0,     0,     0,     0,   550,     0,   551,   605,   603,
     497,   500,   606,   388,     0,   813,   381,     0,     0,    19,
     758,     0,     0,     0,   681,     0,     0,   684,   870,     0,
     865,     0,   881,   883,     0,   858,   852,   855,     0,     0,
     689,   673,   878,     0,     0,   536,   533,     0,     0,     0,
     845,   600,     0,   849,     0,     0,   548,   552,     0,     0,
     495,   501,   497,   387,    17,   753,   676,     0,   674,   675,
     638,     0,     0,     0,     0,   863,   867,     0,   860,     0,
       0,   853,   687,     0,   879,   596,     0,   532,     0,   511,
     527,   526,   843,   844,   842,     0,   554,   600,     0,     0,
       0,     0,   496,   638,   665,   682,   685,     0,   869,     0,
       0,   859,   857,     0,   599,     0,     0,   529,     0,   841,
     498,   600,   600,     0,   677,     0,   638,   679,     0,     0,
     884,   665,     0,     0,     0,   499,   502,   600,   669,   686,
       0,   868,   882,     0,   534,     0,   523,   503,   866,   671,
     530,     0,   524,   522
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     8,     9,    10,    22,   282,   917,  1457,  1458,   283,
     337,    11,    12,    35,    36,   485,   154,    68,    39,    40,
     490,   497,   318,   498,   136,   317,    81,   134,    41,    42,
     320,    83,   155,    43,   955,    44,   351,    85,   187,   156,
      46,   361,    88,   197,    89,   157,    48,   368,    92,   216,
     158,   159,   501,  1291,  1292,   199,   219,   230,   587,   188,
      13,   161,   162,    58,   226,    57,   101,   102,   243,   103,
     104,   107,   163,   232,   375,    95,   233,   246,   597,   813,
     394,  1365,  1270,  1004,   395,  1005,   571,   957,  1115,   127,
     430,   623,   760,   284,   761,   762,  1034,   471,   286,   287,
     662,   843,   663,   849,   664,   288,   289,    70,   307,   291,
     267,    73,   128,    74,   292,   293,   294,   295,   615,   829,
     426,   427,   620,   834,   428,   164,   556,   732,   733,  1095,
    1216,   734,  1403,  1217,  1319,  1096,  1320,   735,  1199,  1307,
    1077,   736,  1399,   737,  1084,  1204,   913,   738,   739,   165,
    1078,   826,   610,   671,   476,   910,  1200,  1310,  1079,   429,
    1080,   433,   166,   888,   167,  1075,   905,   168,   922,   396,
     906,   169,   322,   513,   170,   893,  1065,   171,   333,   541,
     707,   172,   173,   690,   691,   858,  1026,   943,  1056,  1057,
    1500,  1450,  1501,  1053,   977,   978,   979,   326,   327,   523,
     524,   525,  1042,  1591,  1488,  1531,  1435,  1557,  1373,  1527,
    1280,  1172,   405,  1052,  1178,   876,   526,  1049,  1050,  1444,
     527,   528,   529,   530,  1035,  1036,  1169,  1277,  1037,  1166,
    1274,   531,   867,  1041,   868,   532,  1366,  1367,  1430,  1388,
    1389,   533,   879,  1186,   880,  1298,  1187,    16,    17,    53,
      55,    18,   241,   381,   588,   240,   379,   583,   803,   580,
     581,   775,   776,   777,   535,  1031,   864,   962,  1331,   779,
    1231,  1356,  1463,  1508,  1509,  1543,   780,  1232,  1466,  1510,
    1412,  1467,  1566,   781,  1479,   980,   782,   783,  1248,  1136,
     784,  1253,  1140,   785,   536,   787,   966,   788,   789,   790,
     791,   792,  1235,  1124,   968,   132,   539,   174,   886,   704,
     190,   951,   752,   952,   564,   753,   356,   953,   954,  1327,
    1226,   175,   546,   338,   339,   716,   720,   547,   717,  1105,
    1106,   176,   177,   944,  1102,   945,   746,    75,   299,    76,
     300,   301,   741,   916,  1092,  1207,  1093,   742,  1087,  1211,
    1315,  1212,   487,    49,   309,   483,   488,   489,   178,   179,
     603,   819,   820,  1010,   883,  1283,  1284,  1379,   794,   795,
    1419,   796,   797,   798,  1469,  1515,  1516,   799,  1240,  1134,
     800,  1260,   801,  1472,  1473,  1340,   397,   398,   399,   592,
    1265,   807,   993,   400,   213,   105,   193,    77,   119,   258,
     259,   260,   261,   408,   409,   262,   180
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -1258
static const yytype_int16 yypact[] =
{
    1528,   104, -1258,   652,   191, -1258, -1258, -1258,   368, -1258,
     476, -1258,   810,   174,   546, -1258, -1258, -1258, -1258,   228,
     438, -1258, -1258, -1258, -1258, -1258, -1258, -1258,   191,   191,
     191,   191,   765,   216,   191, -1258, -1258, -1258, -1258, -1258,
    2319, -1258,  1157, -1258,   566, -1258,  2358, -1258,  2391, -1258,
   -1258,   652,  2424,   548,   405,   469,   587,   490,   326,   672,
     706,   670,   453, -1258,   191,   191,   675,   401,   527,   620,
     801,   801,   637, -1258,   693, -1258, -1258, -1258,   757,   800,
     119,   793,   847,  1436,   856,   627,   861, -1258,  2496, -1258,
      80,   866,  2568, -1258,   871,  2667,   711, -1258, -1258,   191,
   -1258,    29, -1258,   762,   862,   876, -1258, -1258,   191,   191,
   -1258,   191, -1258,   873,   893,   905, -1258, -1258, -1258,   820,
     216, -1258,   886, -1258,  1826, -1258,   335, -1258,   423,  2011,
     912,   751,   807,   809,   762, -1258, -1258,   719,   652,   191,
   -1258,   191,   191,   360,   191,   667,   652,   191,   750,   761,
     191,   191,   884, -1258, -1258, -1258, -1258, -1258, -1258, -1258,
   -1258, -1258,   137, -1258, -1258, -1258, -1258, -1258, -1258, -1258,
   -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258,
   -1258,   397,   191,   206,   516,   191, -1258, -1258, -1258, -1258,
     963, -1258,   128,   762,   128,   778, -1258, -1258, -1258, -1258,
     823, -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258,
   -1258,   956, -1258,   854,   176,   176, -1258, -1258, -1258, -1258,
   -1258, -1258, -1258, -1258, -1258, -1258,   490,   662, -1258, -1258,
   -1258, -1258,   992, -1258, -1258, -1258, -1258, -1258, -1258,   441,
     974, -1258, -1258,   762, -1258,  1204, -1258,   216, -1258,   978,
     982, -1258,   981, -1258,   191,   191,   191,   909,   889, -1258,
   -1258,    82, -1258,   655, -1258, -1258, -1258, -1258, -1258,   896,
   -1258, -1258,   216, -1258,   924, -1258,  1029,  1029,  1029,  1029,
    1029,  1980, -1258, -1258, -1258,    98,   665,  2088,   923,   620,
     337, -1258, -1258,   832, -1258, -1258,   922, -1258,   926, -1258,
     191, -1258, -1258, -1258, -1258, -1258,   943,   903,   997,   512,
     191,   191,   191, -1258, -1258, -1258,   949,   762,  2535,   191,
     952, -1258,   961, -1258, -1258,    51,  1084,   618,  1078,   353,
   -1258, -1258,   620,   971,   412, -1258, -1258,   994,   462,   976,
    1103,   549,   999,  1110,  1001,    87,   721,   157,   191, -1258,
     191,  1002, -1258,  1107,  1126,   620, -1258,   191,  1010,   397,
     191,  1011, -1258, -1258,  1013,  1015, -1258,  1149,  1018, -1258,
    1023,  1112,  1055,   191, -1258,  1026, -1258,  1033,   620,  1036,
   -1258,  2601, -1258,  1038, -1258, -1258,   652,   191,   191, -1258,
   -1258, -1258,  1109,  1154, -1258,   191, -1258, -1258, -1258, -1258,
   -1258,   563, -1258, -1258,  1041,   402, -1258,   471,  1043,   191,
    1044, -1258,   216,  1045,   471,   191, -1258,   243, -1258, -1258,
   -1258,  1057, -1258, -1258, -1258,   343,  1054,  1051, -1258, -1258,
     937, -1258, -1258,  2011,  2011,  2011,  2011,  2011,  2011,  2011,
    2011,  2011,  2011,  2011,  2011,  2011, -1258, -1258, -1258, -1258,
   -1258, -1258,  2011,  2011,  2011,  2011,  2011,  2011,  2011,  2011,
    2011,  2011,  2011,  2011,  2011,  2011,  2011,  2011,  2011,  2011,
    2011,  2011,  1029,   875,  1061,   448, -1258, -1258,  1980,  2011,
   -1258, -1258,   191,  1060,   216, -1258, -1258, -1258,   473, -1258,
   -1258, -1258, -1258, -1258, -1258,  1062, -1258,   800, -1258, -1258,
   -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258,
   -1258, -1258,   216,  1167,   684,   216,   719,  2011,  2011,   204,
    1980,   598, -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258,
   -1258,  1083, -1258, -1258, -1258, -1258, -1258,  1069, -1258,  1184,
     216,  1073,   216,   216,  1177,   388,  1074,  1171,  2011,  1185,
     216, -1258,   216, -1258,  1081,   456,  1089,   216,  1093,   652,
     872, -1258, -1258,  1213,  1172,   668,  1099, -1258, -1258, -1258,
    1753, -1258,   191, -1258, -1258,   216, -1258, -1258, -1258, -1258,
    1222,  2029, -1258,  1105, -1258, -1258, -1258, -1258, -1258, -1258,
   -1258, -1258,   211,  1215,   211, -1258,   652,   683,   888,   735,
   -1258,   191,    86,   141,  2011, -1258,   471,  1102,   331,  1135,
   -1258, -1258,   471,   728,   563, -1258,  1029, -1258,  1980,  2011,
    1104, -1258,  1980, -1258, -1258,  2063,  2063,  2063,  2063,  2063,
    2063,  2063,  2063,  2063,  2063,  2063,  2063,  2673,  2673,  2673,
    2673,  2673,  2673,  2673,  2673,  2673,  2673,  2673,  2673,   812,
     812,   812, -1258, -1258, -1258, -1258,  2063, -1258,   933,   933,
    1029,  1029,   599, -1258,   828,  1115,   990, -1258,  1980, -1258,
     728, -1258, -1258,   130, -1258,  1108, -1258, -1258, -1258,   779,
     997, -1258, -1258, -1258,  1116, -1258,   390, -1258, -1258, -1258,
    1227,  1117,   699,  1119,  1206,  1207, -1258, -1258, -1258, -1258,
   -1258,  1242,  1957,   762,  1221,  1137,   216, -1258,   118,  1243,
     117,  1015,   216,   216, -1258,   191, -1258,  1251,  1262,  1247,
   -1258, -1258,   780,   319,  1143, -1258,   216,  1150,  1246,   191,
    1086,   910, -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258,
    1224, -1258, -1258, -1258,  1151,  2224,  1155, -1258, -1258,   216,
    1152, -1258,  1269, -1258, -1258, -1258, -1258, -1258,  2011, -1258,
   -1258,  1153, -1258, -1258,   802, -1258,   563,   662,   659,  2011,
    1156,  2011,  1255,  2011,   253, -1258, -1258, -1258, -1258, -1258,
   -1258, -1258,   777, -1258, -1258, -1258, -1258, -1258, -1258, -1258,
     459,    49, -1258,  1160, -1258, -1258, -1258, -1258, -1258, -1258,
   -1258, -1258,   216, -1258,  1275,  1166,  1708,  1248,  1265, -1258,
     211, -1258,  1708, -1258,   698, -1258,   216, -1258,   563,  1159,
     203, -1258,  1165,  1170, -1258,  1046, -1258, -1258,   728, -1258,
   -1258, -1258,  1173,  1980, -1258, -1258, -1258, -1258, -1258, -1258,
   -1258, -1258, -1258,   933,   875, -1258, -1258, -1258, -1258,   933,
    1029,   347,  2011, -1258,  1174, -1258,  1175,   742,  1179,  2011,
    1178, -1258, -1258,  2011,  1253,   156, -1258,  1998,   583, -1258,
    1346, -1258, -1258, -1258,   204,   342,   191, -1258, -1258,  1289,
    1291, -1258, -1258, -1258,  1180,   762,   800,  2011,  1181,   620,
    2011,   698,  2011,  1183, -1258,   563,   620,   840,  1171,  1297,
    1015,  1186,   402, -1258, -1258,  1187, -1258, -1258, -1258,   875,
    1283,   216,   908, -1258,  1312,  2457,   833, -1258, -1258, -1258,
     191,  2011,  1193,  1194, -1258, -1258, -1258, -1258, -1258, -1258,
   -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258,
   -1258, -1258, -1258,  1200, -1258,   941,   910,  1151, -1258,   433,
   -1258,  1325, -1258, -1258, -1258, -1258, -1258,   945,  1887,  1208,
    1326, -1258,  2011,  1286, -1258, -1258,  1211,   216,  1282,  1296,
    1813,  2011,   191,   191,   191,  2011,  2011, -1258, -1258, -1258,
    1319,  1209,   620,   358, -1258, -1258, -1258, -1258,  2011, -1258,
     839,   620,   438,  1220, -1258,   216,   191,  1301, -1258, -1258,
   -1258, -1258, -1258, -1258,   216, -1258,   484, -1258,   216,   216,
   -1258, -1258, -1258, -1258,   502, -1258, -1258,   892, -1258, -1258,
   -1258, -1258, -1258, -1258,  1217,   652, -1258,  1218,  2237, -1258,
    2011,  1219,  1245, -1258,   409,  1226,  1292, -1258, -1258, -1258,
    2011, -1258,  1334,  1343,  1344, -1258, -1258, -1258, -1258,  1345,
    1321,   540,   487,  1349, -1258,  2011,  1356, -1258, -1258,  1235,
    1236, -1258, -1258,  1237, -1258,  2011,  1348, -1258, -1258, -1258,
    1239, -1258, -1258,   169,  2011,  1240,   644, -1258, -1258, -1258,
   -1258,   216,   710,   216,   609,  1285,  1364,  2634,  1285, -1258,
   -1258, -1258, -1258, -1258, -1258,   951, -1258,  1244, -1258, -1258,
    1249, -1258, -1258,  1252,  2237, -1258,   958, -1258, -1258,  1256,
     376,   920,  1366, -1258,  1753, -1258, -1258, -1258,  1381, -1258,
   -1258, -1258, -1258,  2011,  1371,  1209,  1257, -1258,   126, -1258,
    2011,   126,  1260,  1332,  1998, -1258,  1333, -1258,   191,    75,
    1336, -1258,  1253, -1258, -1258,  2011,  2011,   136,  1263,  1708,
     764,   229,    60,   216,  1088,   691,   563, -1258, -1258, -1258,
   -1258, -1258, -1258,  1242,  2011,  1398, -1258, -1258,  2011,  1270,
    1313, -1258,  1273,  1420,  1342,  1377,  1378,   191, -1258,  1380,
    1383,  1532,  1392,  2011,  1280,   116, -1258,  1403, -1258, -1258,
   -1258,  1284,  2011, -1258, -1258,  1287, -1258, -1258,   678,   970,
     985, -1258,  1288,  1370, -1258, -1258,   191, -1258,  1327,  1327,
   -1258, -1258, -1258, -1258, -1258,   910, -1258,   664, -1258, -1258,
   -1258, -1258,  1290,   910, -1258,   414,  1404,  1171,  1293, -1258,
     105,  1395, -1258, -1258,  2011,  1295,   156, -1258, -1258, -1258,
    2011,  1338,  1298, -1258,  2011,  1302,  1367,  2011,  1303,  1409,
     875, -1258,  2011,  1304,  1305,  1433, -1258, -1258,  2011, -1258,
     142, -1258, -1258, -1258,    89, -1258, -1258,   229, -1258, -1258,
    1316, -1258, -1258,  2011, -1258,  1440,  2011, -1258, -1258,  2011,
    1435,  1443,  1980, -1258,   265,  1015,  1015,  1328,  1015,  1015,
   -1258, -1258,  1629, -1258,  1532,  1438,   191, -1258,  1323,  1331,
    1441, -1258, -1258, -1258, -1258,  1425,   216, -1258, -1258,   875,
   -1258, -1258,   191, -1258,  1460, -1258, -1258, -1258,  1408, -1258,
   -1258,  1347, -1258, -1258,   191,  1335, -1258,  1455,  1339, -1258,
   -1258,  1340, -1258,  1405, -1258, -1258, -1258,   692,  1351,  1358,
    1352,   379, -1258, -1258,   145, -1258,  2011, -1258, -1258,   875,
     422, -1258, -1258, -1258, -1258,  1450,  1461,  1423,  2011, -1258,
     774, -1258, -1258, -1258,  2011, -1258,  1353,  1998, -1258,  1998,
   -1258,  1360,   762,  1452,  1474,  1373,  1980,   161, -1258,  1483,
    1457,  1368, -1258,  1457,  1372, -1258, -1258,  1356, -1258, -1258,
    1532, -1258, -1258, -1258,  1375,   216,   209, -1258, -1258, -1258,
   -1258,   191,   191, -1258,  1516,   846, -1258,  1494, -1258, -1258,
    1980, -1258,  1111,   518,  2011,  2011, -1258,  2011, -1258,  1382,
     146, -1258,   191,  1405,  2011,  1449, -1258, -1258, -1258,  1456,
   -1258, -1258,  1334,  1384,   762, -1258,  1441,  1532,  1385,  1441,
   -1258,  1387,  1497,  1493,  1391, -1258,  1393, -1258, -1258, -1258,
    1113, -1258, -1258, -1258,  1399, -1258, -1258,  1394,   191, -1258,
   -1258,  1410,  1407,   296, -1258,  2011,  1517, -1258,   126,  2011,
   -1258,  1475, -1258, -1258,   147,  1480, -1258, -1258,  1416,  1418,
   -1258, -1258, -1258,  2011,  1980, -1258,  1536,  1422,  1650,  1424,
   -1258,  1532,  1427, -1258,  1441,  1015, -1258, -1258,   153,  2011,
   -1258, -1258,  1113, -1258, -1258, -1258, -1258,  1553, -1258, -1258,
   -1258,  1505,  1541,  2011,  1500, -1258, -1258,  1980, -1258,   162,
    2011, -1258, -1258,   300, -1258,  1439,  1535, -1258,  1524, -1258,
   -1258, -1258, -1258, -1258, -1258,  1442, -1258,  1532,  1549,  1280,
    1556,  2011, -1258, -1258,   105, -1258, -1258,  1444, -1258,  1980,
     848, -1258, -1258,  1573, -1258,  1015,  1550, -1258,  1569, -1258,
   -1258,  1532,  1532,  1564, -1258,  1453, -1258, -1258,   850,  2011,
   -1258,   105,  1463,  1015,  1583, -1258, -1258,  1532, -1258, -1258,
    2011, -1258, -1258,  1470, -1258,  1471,   191, -1258, -1258, -1258,
   -1258,  1472, -1258, -1258
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
   -1258, -1258, -1258, -1258,   -39, -1258,   389, -1258, -1258, -1258,
     -26,  1599, -1258, -1258, -1258,  1600,    25,  1141, -1258, -1258,
     838, -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258,
    1118, -1258, -1258, -1258, -1258, -1258,  1268, -1258, -1258,   120,
   -1258,  1437, -1258, -1258, -1258,  1617, -1258,  1417, -1258, -1258,
     -36,   -74, -1258,   -82, -1258, -1258, -1258,  -334, -1258, -1258,
    -219,   720,    17, -1258, -1258, -1258, -1258,  1534, -1258, -1258,
      37, -1258,    11, -1258,   870, -1258, -1258,  -124,  -913, -1258,
    -722, -1258, -1258, -1258, -1258,   749,  -648, -1258, -1258,   -64,
   -1258, -1258,   528,  1019, -1258,   685,   386, -1258, -1258,  2323,
     803, -1258,  -557, -1258,   799,  -236,   258, -1258,    34,    41,
   -1258, -1258,  1579,  -454,  -245, -1258,  1379, -1258, -1258, -1258,
    -365,  -453, -1258, -1258,   -88, -1258, -1258, -1258, -1258, -1258,
   -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258,
     344, -1258, -1258, -1258, -1258, -1258,   572, -1258, -1258, -1258,
    -312, -1258,   -85, -1258,  -335, -1258, -1258, -1258, -1017,   -67,
    -446,   995, -1258, -1258,    -2, -1258, -1258,   -42,   714, -1258,
   -1258, -1258, -1258, -1258, -1258, -1258, -1258,    -1, -1258, -1258,
   -1258,   -34,   -72, -1258, -1258, -1258, -1258,   630, -1258, -1258,
     167,   219, -1258, -1258, -1258,   792, -1258,  -488, -1258, -1258,
   -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258,
   -1258,   240,  -221, -1258, -1258, -1258, -1258, -1258, -1258,   291,
   -1258, -1258, -1258,  -443,   308,  -904, -1258, -1258,  -948, -1258,
   -1258,  -532,   515, -1258, -1258,  -442, -1258, -1258, -1258,   498,
   -1257, -1258, -1258,   293, -1258, -1215, -1258,  1354,   -16, -1258,
     690,    -5, -1258, -1258, -1258, -1258,   722, -1258, -1258,  -578,
   -1258, -1258, -1258, -1258,  -425,   544, -1258,  -883, -1006, -1258,
   -1258, -1258,   210, -1258, -1219, -1258, -1258, -1258, -1258, -1258,
   -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258,
   -1258, -1258, -1258, -1258,  -412, -1258, -1258,   897, -1258,  -900,
   -1258,   902, -1258, -1258, -1258,  -427, -1258,  1605, -1258, -1258,
    -690, -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258, -1258,
   -1258, -1258, -1258,   746, -1258,   472,  -819,  -657, -1258,   475,
   -1258,   -40,   -17,   592, -1258, -1258, -1258,     0, -1258,    21,
     297,  -120, -1258, -1258, -1258,   614, -1258, -1258, -1258, -1258,
     494, -1258, -1258, -1258, -1258,  1025, -1258,  1225,   179,   -55,
    -600, -1258, -1258, -1258, -1258,   426, -1258, -1258, -1258, -1258,
     286, -1258, -1258, -1258, -1258,   132, -1258, -1258, -1063,   304,
   -1258,   245,   932, -1159, -1258, -1258, -1258, -1258, -1258,  1127,
     457,  -514, -1258, -1258,   -96,  1680, -1258, -1258, -1258, -1258,
   -1258, -1258, -1258,   403,  1466, -1258, -1258
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -921
static const yytype_int16 yytable[] =
{
      19,   160,   268,    23,    25,    62,   125,   804,   683,   248,
     316,    15,    93,   189,   198,    56,   205,    14,   218,   666,
     223,   229,  1133,   236,    24,   675,   393,   667,    59,    60,
      61,    63,    66,   210,    78,   410,   296,    38,    97,   297,
     420,   421,   422,   423,   424,   191,   202,   586,   207,   774,
     221,    23,   224,   234,   204,   237,   217,   298,   222,   228,
     898,   235,   950,   894,   113,   114,  1132,    71,  1242,   363,
     684,   208,    24,  1138,    72,   225,   696,   697,   238,  1069,
     809,  1150,   522,   266,   994,  1394,   201,   203,   554,     2,
     998,   860,    21,     2,   698,   106,     2,   211,  1145,   242,
     609,   836,   837,   220,   514,   200,   231,   699,   249,   250,
     186,   251,     2,   674,  1411,  1250,   329,   211,   334,   382,
     133,   341,    23,     2,   346,   431,   303,   890,   305,   555,
     988,   313,    45,  1451,    20,     2,   100,   321,   323,   325,
     672,   328,    63,    24,    63,    63,   340,    63,   343,   345,
      63,   347,  1296,   816,    71,  1183,   778,   431,   290,   324,
       2,   263,    21,     2,  1258,   675,  1238,    24,     2,   786,
    1358,   432,   892,  1417,  1417,  1258,  -184,    71,   211,    52,
    1490,   352,   353,     2,  1239,   358,  1246,   360,   374,  1537,
    1358,    50,   362,   495,   362,    66,   297,  1439,     2,   558,
     685,   989,   515,   432,  1481,    67,   211,   354,   196,    51,
      21,     2,    21,     2,   369,   369,   601,    71,    71,   517,
     740,  1489,    21,     2,  1492,    72,  1251,    23,   705,   669,
    1245,   709,   212,  1351,  1533,   367,   657,   665,   723,  -364,
     724,   413,  1236,  1361,   500,   744,   507,   817,    24,    21,
       2,  -358,  1071,   831,   406,   407,   406,  1024,   983,   877,
     878,   414,  1330,   371,   123,   124,   -53,   209,  1297,  -455,
    1008,  1264,  1454,    71,   522,    67,   504,   881,   508,  1535,
    1560,   401,   499,  -358,   506,  -358,  1016,   518,  1259,   349,
     882,    69,  1398,   821,  1359,  1377,   997,  1418,  1477,  1518,
     480,   509,  1073,   520,  1575,  1576,   417,   229,   559,   236,
     491,   491,   491,  1440,  1551,   290,   503,   505,   805,   510,
    1587,  1194,   560,    67,   475,    67,  1507,   537,  1370,   502,
    1553,   565,  1421,  1032,   486,    67,   522,    21,     2,   234,
     903,   237,     2,    21,     2,   228,  1282,   235,    63,  1360,
     561,   520,  1009,   613,  1548,   123,   124,    63,   806,   352,
     567,    71,    67,    87,   238,   984,    21,     2,    26,   598,
     431,   330,   577,   578,   431,   123,   124,  1410,    69,    54,
     830,  1410,  1376,   970,   904,  -319,   590,   593,   594,   474,
     124,   856,   231,   297,   473,   599,    21,     2,   302,  -319,
     473,   332,  -549,   971,     2,  1513,     1,   591,  1328,   606,
    1582,   670,   712,   544,   908,   612,   432,   331,  1164,   713,
     432,   350,   665,   665,   838,   839,   116,  1262,    21,     2,
       2,  1045,  1046,   100,   354,   297,  -772,   947,   712,    21,
       2,   355,    69,   714,   335,   713,   608,    21,     2,  1047,
      67,   614,   377,  1227,  1225,   666,    67,   522,  -407,  1060,
    1415,  1165,  1048,  1429,   726,    21,     2,  -622,  -407,   714,
     727,   117,  -586,  -184,   517,   689,    -5,   123,   124,    67,
     118,   981,   677,   474,   124,   473,   304,  -319,   970,   728,
     336,   617,  -353,     7,   700,  1020,  -353,   378,   122,   544,
    -622,   902,   111,   680,   540,    69,   715,   822,  1146,    67,
     285,   473,   290,   486,    23,   306,   321,    31,    71,   473,
     729,  1514,    21,     2,  1179,    72,     7,    87,  -772,   431,
      69,  1416,  1324,   297,   296,    24,  1326,   297,  1565,   772,
     545,    67,   773,   710,   825,   522,   608,  1180,    69,   692,
     828,    33,    67,    71,   290,   298,    31,  -186,   601,   747,
      67,   111,   602,   543,   730,  1583,  1255,    84,   474,   124,
    -407,  -407,   765,   484,   608,   432,   708,   608,    67,   884,
     748,   793,   -74,   297,   608,   521,   608,   393,    52,   751,
      33,   608,  1127,   393,   123,   124,   590,   100,  1538,  1541,
     -74,   815,   111,   731,  -319,   112,   520,   665,   665,   766,
      96,   919,   484,   665,  1019,    71,     2,   591,   604,     1,
     522,    98,  1468,  1129,    21,     2,   431,  -920,  1130,   522,
     123,   124,  1514,   517,   357,    67,   818,  1380,  1381,  1203,
    1383,  1384,   475,   182,   -74,  -835,  -510,  -510,  -510,    99,
      21,     2,   290,   -74,  1334,  1051,   290,  1038,    21,     2,
     960,   183,  -663,  -663,  -663,  -663,  -663,   425,    21,     2,
      69,     2,   432,   665,     2,    69,   120,   434,   335,   121,
    -622,   270,   264,   271,    21,     2,    97,  1177,  1039,   897,
      21,     2,  1154,  1040,  1318,   687,   601,   372,   111,  -510,
     550,   518,   290,   912,  1339,   184,   519,  1198,  -663,   123,
     124,  -663,   110,   435,   185,    63,   436,   115,   999,  -319,
      71,   437,   406,   373,   336,   108,     2,   272,   374,    63,
     273,   918,   319,   840,   841,   842,    71,    67,  1000,  1001,
      71,   688,    69,  1002,   666,  1015,   895,    71,   297,   438,
     700,   342,   667,  1210,   122,   439,  1003,     2,     2,   109,
     608,  1059,   344,    67,   310,   520,    64,    23,     2,  1201,
      69,  1202,     2,    69,   311,  1152,   122,   521,  -663,    64,
    -663,   901,   312,   608,    65,     2,   -37,     2,    24,   -37,
     474,   124,  -407,  -407,  -663,  -663,   666,    67,    69,   130,
      69,    69,  -663,  -663,   -38,  1387,  -663,   -38,    69,   972,
      69,   973,   607,   658,   659,    69,   961,   111,   607,   624,
     754,   660,   661,    28,    71,   281,  1108,   974,   764,  1375,
     131,   811,  1304,    69,    29,   812,    71,   123,   124,   521,
     129,    30,  -885,   975,  1091,   123,   124,  1536,   122,   182,
    1006,   861,  -837,   135,    31,   666,   123,   124,   239,   976,
      69,  1094,  -402,  1088,   673,   676,    69,   290,   146,    32,
     111,  -693,   557,  -693,  -331,  -331,   406,   137,   270,   264,
     271,    21,     2,  -211,  -331,  -693,   181,  -211,    33,  -693,
     264,   192,    21,     2,     4,   666,   214,   265,   122,    71,
    1449,   227,   602,   694,   695,  -693,   673,  1572,    71,   245,
      34,    33,  1263,   211,   264,   252,   812,     2,     5,     6,
    1097,  -693,  1426,  1438,   272,  1585,   812,   273,   120,   247,
     393,   853,  1545,   200,   721,   253,   270,   264,   271,    21,
       2,  1089,   308,  1076,   857,  1082,  1107,   123,   124,  1111,
     467,   468,   469,   470,   254,  -244,   763,  1462,   122,   314,
     875,   315,   665,   348,   889,  1564,   845,   846,   847,   848,
      69,   896,  1137,  1139,  1141,   349,   255,  1195,   256,   257,
     477,   478,   272,    71,    69,   273,  1158,    56,  1579,   111,
     823,  1338,  1068,   359,    67,   111,   406,  1569,  1460,  1580,
    1570,    71,  1581,   365,   673,   832,   366,    69,   285,   376,
     658,   659,   825,   229,   665,   236,   380,  -323,   660,   661,
     402,   111,   281,   749,   403,    23,   840,   841,   842,  1151,
     404,  1525,   270,   264,   271,    21,     2,   111,   608,   814,
     412,  1558,  1155,  1156,   416,   234,    24,   237,   982,   474,
     124,   228,    67,   235,   851,  1184,  1266,   111,   912,  1083,
     991,   576,     2,  -323,  1550,   411,  -408,  -408,   472,   -21,
     238,   -21,   419,   665,    69,   479,   660,   661,   272,  -359,
     281,   273,  -408,  1453,    63,   621,   622,   914,  -408,  1103,
    1104,   481,  -408,  1113,  1114,   919,  1568,   482,   231,  1214,
    1215,   494,  -798,  1108,   511,   915,  1222,  1223,  1268,  1269,
     475,  -408,   512,   665,   516,   608,  -798,   608,  1305,  1306,
     538,  -798,   542,   982,  -323,  -323,  -323,   548,  -323,  -323,
    -323,  -323,   521,  1308,  1309,  -323,  -323,   129,  1249,  1464,
    1465,  1498,  1499,   111,   956,   549,  -323,  -798,    67,   492,
     493,   551,   552,   553,   562,   963,   563,   965,    82,   969,
     514,   559,   570,   568,  -798,   569,  -408,   -63,   572,    69,
     573,  -798,  -798,   -63,   -63,   574,   281,  1287,   579,   575,
     -63,   582,   -63,   -63,   584,  1299,   589,  1267,   595,   596,
     -63,   -63,   -63,   600,  -408,  -408,  -408,   297,  -408,   605,
     601,   611,   616,   618,   619,   383,  1313,   355,   668,   686,
    1386,  -220,   678,   701,   682,   918,   -63,  1321,   -63,  1014,
     702,   703,   706,  1107,   711,   378,   718,   -63,   -63,   384,
    1332,   719,   -63,   725,   722,   -63,   -63,   385,  1021,   386,
     745,   743,   -63,   -63,   -63,  1027,   -63,   750,  1433,  1029,
      33,   755,   767,    69,   802,   827,  1044,   808,   824,   833,
     850,   852,    69,   387,  1362,   388,    69,    69,   855,   859,
      71,   862,   863,  1061,   389,   865,  1063,   602,  1066,   390,
     866,   885,  1184,   391,  1350,   891,   825,   887,   544,     5,
       6,   297,   899,   392,   900,   907,  1391,   909,  1405,   911,
     920,   921,   946,   949,   948,   992,   958,  1098,   964,   967,
    1487,   990,  1400,  -899,   996,   995,   290,  1011,  1012,   -63,
    1007,  1013,  1030,   973,    63,   297,  1022,  1023,  1025,  1028,
    1055,  1070,  1058,  1062,    69,  1067,  1081,  1074,  1072,    69,
    1396,    69,  1085,  1350,   763,  1099,  1100,  1043,  1119,   270,
     264,   271,    21,     2,  1101,  1112,  1118,  1135,  1120,  1123,
    1117,  1142,  1143,  1121,  1125,  1144,   961,  1149,  1153,  1157,
    1159,  1162,   764,  1168,  1147,  1163,  1171,  1441,  1167,  1173,
    1174,  1176,  1175,  1350,   475,  1181,  1185,  1188,  1189,  1190,
    1192,  1193,  1197,  1206,  1208,   272,  1218,  1219,   273,   297,
    1228,  1455,  1456,  1230,  1220,  1234,  1530,  1273,  1224,  1237,
     290,    69,  1243,  1244,  1247,  1261,  1161,  1252,  1278,  1276,
    1279,  1281,  1480,  1282,  1285,  1286,  1170,  1288,  1294,   608,
    1289,  1251,   297,  1300,  1312,  1314,  1301,  1333,   183,  1303,
    1311,  1182,  1322,  1342,   290,  1329,   138,  1336,  1346,  1349,
    1343,  1191,   139,   140,  1345,  1348,  1353,  1354,  1504,   141,
    1196,   142,   143,  1355,   297,    67,  1364,   276,  1369,   144,
     145,   146,  1372,  1374,  1390,  1392,  1382,  1296,  1395,  1401,
    1404,   277,   278,  1393,  1402,  1407,  1410,  1406,  1413,   279,
     280,  1408,  1409,   281,  1337,    32,  1422,     4,  1539,  1184,
     763,  -886,  1414,  1423,  1424,  1428,   147,   148,  1432,  1233,
    1436,   149,  1434,  1442,    33,   150,  1241,  1443,   290,   270,
    1445,     5,     6,   151,  1447,   152,  1437,  1452,  1461,     1,
    1483,  1256,  1257,  1494,  1476,     2,  1486,  1484,  1491,  1493,
    1495,   -24,   138,  1496,  1332,  1497,  1503,  1512,   139,  1290,
    1272,   290,   -24,  1304,  1275,   141,  1517,   142,   143,   -24,
    1506,  1520,  1505,     3,    69,   144,   145,   146,  1521,  1295,
    1522,  1332,   -24,  1526,  1528,  1544,  1532,  1546,  1302,  1534,
    1547,  1549,  1555,   290,  1556,  1561,  1592,   -24,  1554,     4,
    -622,    32,  1562,     4,  1559,  1571,  1567,  1573,   153,  1574,
    1577,  1586,   147,   148,  1317,  1578,   -24,   149,    69,    27,
      33,   150,    37,     5,     6,  1584,     7,     5,     6,   151,
    1335,   152,  1589,  1590,  1593,   679,  1341,   566,   -24,    47,
    1344,   364,   370,  1347,   693,   244,  1090,   959,  1352,   138,
    1064,   835,  1229,  1116,  1357,   139,  1385,  1017,  1018,   126,
    1397,   418,   141,    69,   142,   143,  1205,   844,  1160,  1368,
     138,  1109,   144,   145,   146,  1371,   139,  1529,  1014,  1542,
    1502,  1054,  1485,   141,  1446,   142,   143,  1431,  1271,  1293,
    1448,   534,  1148,   144,   145,   146,  1254,   985,    32,  1122,
       4,  1523,   986,   206,   153,  1110,  1221,  1325,  1323,   147,
     148,  1459,  1213,  1316,   149,   854,  1478,    33,   150,    32,
    1378,     4,  1588,   681,     5,     6,   151,  1470,   152,  1519,
     147,   148,   987,   810,  1363,   149,    90,   415,    33,   150,
       0,     0,  1420,   384,     0,     5,     6,   151,     0,   152,
       0,   385,     0,   386,  1425,     0,     0,     0,     0,     0,
    1427,     0,     0,     0,     0,     0,   270,   264,   271,    21,
       2,     0,  1014,     0,     0,     0,     0,   387,     0,   388,
       0,     0,     0,     0,     0,     0,     0,     0,   389,     0,
       0,     0,     0,   390,     0,     0,     0,   391,     0,     0,
       0,   153,     0,     5,     6,     0,  1014,   392,     0,     0,
    1471,  1474,   272,  1475,     0,   273,     0,     0,   756,     0,
    1482,     0,   153,     0,  1126,     0,   270,   264,   271,    21,
       2,     0,     0,     0,     0,     0,     0,   269,     0,   270,
     264,   271,    21,     2,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,  1511,     0,     0,     0,   757,     0,     0,   758,     0,
       0,     0,   272,     0,     0,   273,     0,     0,     0,  1524,
    1014,     0,    67,     0,   276,   272,     0,     0,   273,     0,
       0,   274,     0,   275,     0,  1540,     0,  1127,   277,   278,
     270,   264,   271,    21,     2,     0,   279,   280,     0,  1471,
     281,     0,     0,  1014,     0,     0,  1552,   759,     0,     0,
    1033,     0,     0,     0,     0,     0,     0,  1128,  1129,     0,
       0,     0,     0,  1130,  1131,     0,     0,  1563,     0,     0,
       0,     0,    67,     0,   276,  1014,   272,     0,     0,   273,
       0,     0,   756,     0,     0,    67,     0,   276,   277,   278,
       0,     0,     0,     0,     0,  1471,   279,   280,     1,     0,
     281,   277,   278,    21,     2,     0,     0,     0,     0,   279,
     280,     0,   517,   281,     0,   869,     0,     0,     0,   870,
     871,   872,     0,   270,   264,   271,    21,     2,   873,     0,
       0,  -604,   758,     0,     0,     0,  -608,     0,     0,     0,
       0,   270,   264,   271,    21,     2,    67,     0,   276,     0,
       0,     0,     0,     0,   270,   264,   271,    21,     2,  -622,
       0,     0,   277,   278,     0,     0,     0,     0,     0,   272,
     279,   280,   273,     0,   281,    21,     2,   275,     0,     0,
     518,     0,     0,     0,   517,   874,     0,   272,     0,     0,
     273,   768,     0,     0,     0,     0,     0,  -637,  -637,  -637,
     272,     0,     0,   273,     0,     0,     0,     0,   769,     0,
       0,     0,     0,     0,     0,     0,    67,     0,     0,     0,
       0,   770,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  1033,   771,     0,     0,    67,
     440,   276,     0,     0,   520,     0,     0,     0,     0,   772,
    -637,     0,   773,     0,     0,   277,   278,    67,     0,   276,
       0,     0,     0,   279,   280,     0,     0,   281,     0,     0,
      67,     0,   276,   277,   278,     0,   441,     0,     0,   442,
       0,   279,   280,     0,   443,   281,   277,   278,    67,     0,
       0,     0,     0,     0,   279,   280,     0,     0,   281,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   444,     0,     0,     0,   520,     0,   445,   446,
     447,   448,   449,   450,   451,   452,   453,   454,   455,   456,
     457,   458,   459,   460,   461,   462,   463,   464,   465,   466,
       0,   467,   468,   469,   470,     0,     0,     0,     0,     0,
     452,   453,   454,   455,   456,   457,   458,   459,   460,   461,
     462,   463,   464,   465,   466,   923,   467,   468,   469,   470,
       0,     0,     0,     0,     0,     0,     0,   924,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   925,   926,   927,
     924,     0,     0,     0,     0,   928,     0,   929,     0,   930,
     925,   926,   927,     0,     0,     0,     0,   931,   928,     0,
     929,     0,   930,     0,     0,     0,     0,     0,     0,     0,
     931,     0,     0,   932,     0,   933,     0,     0,     0,     0,
       0,     0,     0,     0,   934,   935,   932,     0,   933,   936,
     937,     0,     0,   938,     0,     0,     0,   934,   935,     0,
       0,   939,   936,   937,     0,     0,   938,     0,     0,     0,
      79,     0,     0,     0,   939,     0,     0,     0,     0,   -52,
     940,     0,     0,   941,     0,   -52,   -52,     0,   942,     0,
       0,     0,     0,   940,   -52,   -52,   941,     0,     0,   -52,
       0,   942,   -52,     0,   -52,     0,    80,     0,     0,    86,
       0,     0,     0,     0,     0,     0,     0,     0,   -84,     0,
       0,     0,     0,     0,   -84,     0,     0,     0,   -52,   -52,
     -52,   -84,     0,   -84,   -84,     0,     0,     0,   -84,   -52,
     -52,   -84,    91,   -84,   -52,    87,     0,   -52,   -52,     0,
       0,   -99,     0,     0,   -52,   -52,   -52,   -99,   -52,     0,
       0,     0,     0,     0,     0,     0,   -99,   -84,     0,   -84,
       0,   -99,     0,     0,   -99,    94,   -99,     0,   -84,   -84,
       0,     0,     0,   -84,  -201,     0,   -84,   -84,     0,     0,
    -201,  -201,     0,   -84,   -84,   -84,     0,   -84,     0,  -201,
     -99,     0,   -99,     0,     0,     0,     0,  -201,  1086,  -201,
       0,     0,   -99,     0,     0,     0,   -99,  -809,     0,   -99,
     -99,     0,     0,  -809,     0,     0,   -99,   -99,   -99,     0,
     -99,     0,  -809,  -201,     0,  -201,     0,  -809,     0,     0,
    -809,     0,  -809,     0,     0,  -201,     0,     0,     0,  -201,
       0,     0,  -201,  -201,     0,     0,   138,     0,     0,  -201,
    -201,  -201,   139,  -201,     0,     0,  -809,     0,  -809,   141,
       0,   142,   143,     0,     0,     0,   194,     0,  -809,   144,
       0,   146,  -809,     0,     0,  -809,  -809,     0,     0,     0,
       0,     0,  -809,  -809,  -809,   138,  -809,     0,     0,     0,
       0,   139,   496,     0,     0,   195,     0,     4,     0,     0,
     142,   143,     0,     0,     0,     0,   147,   148,   144,     0,
     146,   149,     0,     0,    33,   150,     0,     0,   138,     0,
       0,     5,     6,   151,   139,   152,     0,     0,     0,     0,
       0,     0,     0,   142,    32,     0,     4,     0,   215,     0,
       0,   144,     0,   146,     0,   147,   148,     0,     0,     0,
     149,   138,     0,    33,   150,     0,     0,   139,   585,     0,
       5,     6,   151,     0,   152,     0,   142,    32,     0,     4,
       0,     0,     0,     0,   144,     0,   146,     0,     0,   148,
       0,     0,     0,   149,   138,     0,    33,   150,     0,     0,
     139,     0,     0,     5,     6,   151,     0,   152,     0,   142,
      32,     0,     4,     0,  1209,     0,     0,   144,     0,   146,
       0,     0,   148,     0,     0,     0,   149,   138,     0,    33,
     150,     0,     0,   139,     0,     0,     5,     6,   151,     0,
     152,     0,   142,    32,     0,     4,     0,     0,     0,     0,
     144,     0,   146,     0,     0,   148,     0,     0,     0,   149,
       0,     0,    33,   150,     0,     0,     0,     0,     0,     5,
       6,   151,     0,   152,     0,     0,    32,     0,     4,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   148,     0,
       0,     0,   149,     0,     0,    33,   150,     0,     0,     0,
       0,     0,     5,     6,   151,     0,   152,   625,   626,   627,
     628,   629,   630,   631,   632,   633,   634,   635,   636,     0,
       0,     0,     0,     0,     0,   637,   638,   639,   640,   641,
     642,   643,   644,   645,   646,   647,   648,   649,   650,   651,
     652,   653,   654,   655,   656,  -921,  -921,  -921,  -921,  -921,
    -921,  -921,  -921,  -921,  -921,  -921,  -921,   464,   465,   466,
       0,   467,   468,   469,   470
};

static const yytype_int16 yycheck[] =
{
       0,    83,   122,     3,     4,    31,    70,   585,   496,   105,
     134,     0,    51,    85,    88,    20,    88,     0,    92,   473,
      92,    95,   970,    95,     3,   478,   245,   473,    28,    29,
      30,    31,    32,    88,    34,   256,   124,    12,    54,   124,
     276,   277,   278,   279,   280,    85,    88,   381,    88,   581,
      92,    51,    92,    95,    88,    95,    92,   124,    92,    95,
     717,    95,   752,   711,    64,    65,   970,    33,  1131,   193,
     497,    88,    51,   973,    33,    92,   519,   519,    95,   898,
     594,   994,   327,   122,   806,  1300,    88,    88,     1,     7,
     812,   691,     6,     7,   519,    58,     7,    37,   981,    99,
     412,   658,   659,    92,    53,    88,    95,   519,   108,   109,
      85,   111,     7,   478,  1333,    40,   142,    37,   144,   243,
       1,   147,   122,     7,   150,    27,   126,     9,   128,    42,
      81,   131,    12,  1390,    30,     7,   107,   137,   138,   139,
     475,   141,   142,   122,   144,   145,   146,   147,   148,   149,
     150,   151,    36,    67,   120,  1055,   581,    27,   124,   138,
       7,   120,     6,     7,    28,   618,    40,   146,     7,   581,
      28,    73,    55,    28,    28,    28,   147,   143,    37,    42,
    1437,   181,   182,     7,    58,   185,  1134,    59,   227,    36,
      28,    12,   192,   317,   194,   195,   281,    36,     7,    42,
     512,   152,   151,    73,  1423,   119,    37,     1,    88,    35,
       6,     7,     6,     7,   214,   215,   156,   183,   184,    15,
     555,  1436,     6,     7,  1439,   184,   151,   227,   540,   474,
    1134,   543,   152,  1250,  1491,    59,   472,   473,   550,   152,
     552,   159,  1125,   154,   318,   557,   318,   161,   227,     6,
       7,   153,   900,   618,   254,   255,   256,   857,   790,   702,
     702,   261,   157,   226,   146,   147,   147,    88,   152,   152,
      67,    42,    63,   239,   519,   119,   318,   702,   318,  1494,
    1537,   247,   318,   153,   318,   155,   843,    83,   152,   152,
     702,    33,  1309,   152,   152,    30,   810,   152,   152,   152,
     300,   318,   902,   147,  1561,  1562,   272,   381,   151,   381,
     310,   311,   312,   152,   152,   281,   318,   318,   107,   319,
    1577,   152,   348,   119,   290,   119,    30,   327,  1276,   318,
      30,   357,  1349,   865,   309,   119,   581,     6,     7,   381,
      21,   381,     7,     6,     7,   381,    81,   381,   348,  1262,
     350,   147,   149,   417,  1513,   146,   147,   357,   147,   359,
     360,   327,   119,    37,   381,   790,     6,     7,     0,   395,
      27,    11,   372,   373,    27,   146,   147,    81,   120,   151,
     616,    81,  1282,   130,    65,   156,   386,   387,   388,   146,
     147,     1,   381,   478,    63,   395,     6,     7,    63,   156,
      63,   143,    60,   150,     7,  1468,     1,   386,  1227,   409,
    1569,   475,    24,    37,   726,   415,    73,    57,     9,    31,
      73,    24,   658,   659,   660,   661,    25,  1149,     6,     7,
       7,   874,   874,   107,     1,   520,    60,   749,    24,     6,
       7,   183,   184,    55,    11,    31,   412,     6,     7,   874,
     119,   417,    11,  1110,    78,   909,   119,   702,    36,   886,
      81,    52,   874,  1367,     8,     6,     7,    62,    46,    55,
      14,    70,   130,   147,    15,   514,     0,   146,   147,   119,
      79,    22,   482,   146,   147,    63,    63,   156,   130,    33,
      57,   148,   149,    88,   152,   148,   149,   239,   156,    37,
      62,   722,   149,    30,   151,   247,   118,   603,   150,   119,
     124,    63,   478,   488,   514,   129,   516,    44,   484,    63,
      64,  1469,     6,     7,    37,   484,    88,    37,   152,    27,
     272,   152,   118,   618,   622,   514,  1226,   622,  1544,    80,
      78,   119,    83,   543,   608,   790,   512,    60,   290,   515,
     614,    78,   119,   519,   520,   622,    44,    67,   156,   559,
     119,   149,   160,   151,   108,  1571,  1144,     1,   146,   147,
     148,   149,   572,   100,   540,    73,   542,   543,   119,   703,
     559,   581,    16,   668,   550,   327,   552,   806,    42,   564,
      78,   557,    74,   812,   146,   147,   596,   107,  1498,  1499,
      34,   601,   149,   147,   156,   152,   147,   843,   844,   575,
      62,   731,   100,   849,   850,   581,     7,   596,   147,     1,
     865,   152,   104,   105,     6,     7,    27,   156,   110,   874,
     146,   147,  1580,    15,   118,   119,   602,  1285,  1286,    30,
    1288,  1289,   608,    16,    78,   161,    28,    29,    30,    62,
       6,     7,   618,    87,  1232,   876,   622,    74,     6,     7,
       1,    34,     3,     4,     5,     6,     7,   281,     6,     7,
     412,     7,    73,   909,     7,   417,   149,    12,    11,   152,
      62,     3,     4,     5,     6,     7,   702,   147,   105,   715,
       6,     7,  1004,   110,    30,    11,   156,    35,   149,    81,
     151,    83,   668,   729,  1236,    78,    88,    63,    49,   146,
     147,    52,    42,    48,    87,   715,    51,    42,    20,   156,
     686,    56,   722,    61,    57,    53,     7,    49,   767,   729,
      52,   731,    13,   134,   135,   136,   702,   119,    40,    41,
     706,    57,   484,    45,  1198,   833,   712,   713,   833,    84,
     152,     1,  1198,  1087,   156,    90,    58,     7,     7,    53,
     726,   885,     1,   119,    13,   147,     1,   767,     7,  1081,
     512,  1083,     7,   515,    23,   996,   156,   519,   119,     1,
     121,     1,    31,   749,    19,     7,   149,     7,   767,   152,
     146,   147,   148,   149,   135,   136,  1250,   119,   540,    42,
     542,   543,   143,   144,   149,  1293,   147,   152,   550,    32,
     552,    34,   409,   135,   136,   557,   157,   149,   415,   433,
     152,   143,   144,    13,   790,   147,   946,    50,   570,  1282,
      30,   148,   154,   575,    24,   152,   802,   146,   147,   581,
     147,    31,   150,    66,   916,   146,   147,  1495,   156,    16,
     816,   152,   161,    60,    44,  1309,   146,   147,   147,    82,
     602,   916,   152,    30,   478,   479,   608,   833,    35,    59,
     149,    32,   151,    34,   146,   147,   876,    30,     3,     4,
       5,     6,     7,   148,   156,    46,    30,   152,    78,    50,
       4,    30,     6,     7,    61,  1349,    30,    11,   156,   865,
    1388,    30,   160,   517,   518,    66,   520,  1555,   874,   147,
     100,    78,   148,    37,     4,    42,   152,     7,    85,    86,
     920,    82,   148,  1376,    49,  1573,   152,    52,   149,    67,
    1149,   152,  1510,   916,   548,    42,     3,     4,     5,     6,
       7,   916,    30,   909,   686,   911,   946,   146,   147,   949,
     138,   139,   140,   141,    49,   153,   570,  1410,   156,   152,
     702,   152,  1198,    79,   706,  1543,   138,   139,   140,   141,
     712,   713,   972,   973,   974,   152,   156,  1073,   158,   159,
     148,   149,    49,   949,   726,    52,  1025,   992,  1566,   149,
     604,  1236,   152,    30,   119,   149,   996,   149,   152,   149,
     152,   967,   152,    47,   618,   619,   152,   749,   622,    17,
     135,   136,  1076,  1087,  1250,  1087,    42,    27,   143,   144,
      42,   149,   147,   151,    42,  1025,   134,   135,   136,   995,
      49,  1484,     3,     4,     5,     6,     7,   149,  1004,   151,
     151,  1529,  1008,  1009,   148,  1087,  1025,  1087,   790,   146,
     147,  1087,   119,  1087,   668,  1055,  1152,   149,  1084,   151,
     802,     6,     7,    73,  1517,   156,    20,    21,   145,   149,
    1087,   151,   148,  1309,   816,   153,   143,   144,    49,   153,
     147,    52,    36,  1395,  1084,   148,   149,     1,    42,   148,
     149,   148,    46,   148,   149,  1215,  1549,   100,  1087,   148,
     149,   152,    16,  1223,   152,    19,   148,   149,    20,    21,
    1076,    65,   151,  1349,    30,  1081,    30,  1083,   148,   149,
      42,    35,   151,   865,   134,   135,   136,   151,   138,   139,
     140,   141,   874,   148,   149,   145,   146,   147,  1138,    28,
      29,    28,    29,   149,   758,    42,   156,    61,   119,   311,
     312,   152,    42,   152,   152,   769,    30,   771,     1,   773,
      53,   151,   147,   152,    78,   152,   120,    10,    19,   911,
     152,    85,    86,    16,    17,   152,   147,  1177,   152,    67,
      23,   148,    25,    26,   148,  1185,   148,  1153,    79,    35,
      33,    34,    35,   152,   148,   149,   150,  1282,   152,   156,
     156,   156,   145,   149,   153,     1,  1206,   949,   147,    42,
    1292,     7,   152,   130,   152,  1215,    59,  1217,    61,   833,
     151,    37,   149,  1223,    47,   967,   152,    70,    71,    25,
    1230,    60,    75,   152,    49,    78,    79,    33,   852,    35,
     147,   152,    85,    86,    87,   859,    89,    34,  1372,   863,
      78,   152,    30,   995,   149,   120,   870,    42,   156,   155,
     145,   153,  1004,    59,  1264,    61,  1008,  1009,   152,    42,
    1236,   152,    66,   887,    70,    68,   890,   160,   892,    75,
      38,    60,  1282,    79,  1250,    42,  1350,   150,    37,    85,
      86,  1376,    30,    89,    47,   152,  1296,   147,  1324,    53,
      76,   150,   147,    34,   152,    30,   153,   921,   152,    54,
    1434,   151,  1312,   147,    49,    67,  1282,   152,   148,   162,
     161,   148,    69,    34,  1324,  1410,   152,   152,   149,   151,
      39,    34,   152,   152,  1076,   152,    53,   150,   152,  1081,
    1306,  1083,    30,  1309,   958,   152,   152,     1,   962,     3,
       4,     5,     6,     7,   154,    30,    30,   971,    72,    77,
     152,   975,   976,   152,    68,    46,   157,   147,    67,   152,
     152,   152,  1114,    81,   988,   130,    42,  1377,   152,    36,
      36,    60,    37,  1349,  1350,    36,    30,   152,   152,   152,
      42,   152,   152,   108,    30,    49,   152,   148,    52,  1484,
      34,  1401,  1402,    22,   152,    34,  1488,     9,   152,   152,
    1376,  1153,   152,    81,    81,   152,  1030,    81,   105,   149,
     147,     1,  1422,    81,    47,    47,  1040,    47,    36,  1395,
      47,   151,  1517,    30,    64,   108,   152,    42,    34,   152,
     152,  1055,   152,   105,  1410,   152,    10,   152,    81,    40,
     152,  1065,    16,    17,   152,   152,   152,   152,  1458,    23,
    1074,    25,    26,    30,  1549,   119,   150,   121,    28,    33,
      34,    35,    37,    30,    36,   152,   148,    36,    53,    19,
     133,   135,   136,   152,    76,    30,    81,   152,   130,   143,
     144,   152,   152,   147,  1236,    59,    46,    61,  1498,  1499,
    1114,   150,   150,    42,    81,   152,    70,    71,   148,  1123,
      36,    75,    60,    30,    78,    79,  1130,    60,  1484,     3,
     152,    85,    86,    87,   152,    89,   153,   152,    34,     1,
      81,  1145,  1146,    36,   152,     7,   152,    81,   153,   152,
      47,    13,    10,   152,  1544,   152,   152,    30,    16,    17,
    1164,  1517,    24,   154,  1168,    23,    81,    25,    26,    31,
     153,    81,   152,    35,  1306,    33,    34,    35,   152,  1183,
     152,  1571,    44,    37,   152,    22,   152,    72,  1192,   152,
      39,    81,    47,  1549,    60,    36,  1586,    59,   149,    61,
      62,    59,    36,    61,   152,    22,   152,    47,   162,    30,
      36,    18,    70,    71,  1215,   152,    78,    75,  1350,    10,
      78,    79,    12,    85,    86,   152,    88,    85,    86,    87,
    1234,    89,   152,   152,   152,   484,  1240,   359,   100,    12,
    1244,   194,   215,  1247,   516,   101,   916,   767,  1252,    10,
     891,   622,  1114,   958,  1258,    16,    17,   844,   849,    70,
    1306,   272,    23,  1395,    25,    26,  1084,   662,  1028,  1273,
      10,   947,    33,    34,    35,  1279,    16,    17,  1282,  1502,
    1451,   879,  1432,    23,  1383,    25,    26,  1369,  1163,  1181,
    1387,   327,   992,    33,    34,    35,  1142,   790,    59,   967,
      61,  1481,   790,    88,   162,   949,  1104,  1225,  1223,    70,
      71,  1404,  1088,  1209,    75,   680,  1420,    78,    79,    59,
    1284,    61,  1580,   488,    85,    86,    87,  1413,    89,  1474,
      70,    71,   790,   596,  1267,    75,    46,   261,    78,    79,
      -1,    -1,  1346,    25,    -1,    85,    86,    87,    -1,    89,
      -1,    33,    -1,    35,  1358,    -1,    -1,    -1,    -1,    -1,
    1364,    -1,    -1,    -1,    -1,    -1,     3,     4,     5,     6,
       7,    -1,  1376,    -1,    -1,    -1,    -1,    59,    -1,    61,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    70,    -1,
      -1,    -1,    -1,    75,    -1,    -1,    -1,    79,    -1,    -1,
      -1,   162,    -1,    85,    86,    -1,  1410,    89,    -1,    -1,
    1414,  1415,    49,  1417,    -1,    52,    -1,    -1,    55,    -1,
    1424,    -1,   162,    -1,     1,    -1,     3,     4,     5,     6,
       7,    -1,    -1,    -1,    -1,    -1,    -1,     1,    -1,     3,
       4,     5,     6,     7,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,  1465,    -1,    -1,    -1,   102,    -1,    -1,   105,    -1,
      -1,    -1,    49,    -1,    -1,    52,    -1,    -1,    -1,  1483,
    1484,    -1,   119,    -1,   121,    49,    -1,    -1,    52,    -1,
      -1,    55,    -1,    57,    -1,  1499,    -1,    74,   135,   136,
       3,     4,     5,     6,     7,    -1,   143,   144,    -1,  1513,
     147,    -1,    -1,  1517,    -1,    -1,  1520,   154,    -1,    -1,
      97,    -1,    -1,    -1,    -1,    -1,    -1,   104,   105,    -1,
      -1,    -1,    -1,   110,   111,    -1,    -1,  1541,    -1,    -1,
      -1,    -1,   119,    -1,   121,  1549,    49,    -1,    -1,    52,
      -1,    -1,    55,    -1,    -1,   119,    -1,   121,   135,   136,
      -1,    -1,    -1,    -1,    -1,  1569,   143,   144,     1,    -1,
     147,   135,   136,     6,     7,    -1,    -1,    -1,    -1,   143,
     144,    -1,    15,   147,    -1,    18,    -1,    -1,    -1,    22,
      23,    24,    -1,     3,     4,     5,     6,     7,    31,    -1,
      -1,    34,   105,    -1,    -1,    -1,    39,    -1,    -1,    -1,
      -1,     3,     4,     5,     6,     7,   119,    -1,   121,    -1,
      -1,    -1,    -1,    -1,     3,     4,     5,     6,     7,    62,
      -1,    -1,   135,   136,    -1,    -1,    -1,    -1,    -1,    49,
     143,   144,    52,    -1,   147,     6,     7,    57,    -1,    -1,
      83,    -1,    -1,    -1,    15,    88,    -1,    49,    -1,    -1,
      52,    22,    -1,    -1,    -1,    -1,    -1,    28,    29,    30,
      49,    -1,    -1,    52,    -1,    -1,    -1,    -1,    39,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   119,    -1,    -1,    -1,
      -1,    52,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    97,    67,    -1,    -1,   119,
      12,   121,    -1,    -1,   147,    -1,    -1,    -1,    -1,    80,
      81,    -1,    83,    -1,    -1,   135,   136,   119,    -1,   121,
      -1,    -1,    -1,   143,   144,    -1,    -1,   147,    -1,    -1,
     119,    -1,   121,   135,   136,    -1,    48,    -1,    -1,    51,
      -1,   143,   144,    -1,    56,   147,   135,   136,   119,    -1,
      -1,    -1,    -1,    -1,   143,   144,    -1,    -1,   147,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    84,    -1,    -1,    -1,   147,    -1,    90,    91,
      92,    93,    94,    95,    96,   122,   123,   124,   125,   126,
     127,   128,   129,   130,   131,   132,   133,   134,   135,   136,
      -1,   138,   139,   140,   141,    -1,    -1,    -1,    -1,    -1,
     122,   123,   124,   125,   126,   127,   128,   129,   130,   131,
     132,   133,   134,   135,   136,     1,   138,   139,   140,   141,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    13,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    23,    24,    25,
      13,    -1,    -1,    -1,    -1,    31,    -1,    33,    -1,    35,
      23,    24,    25,    -1,    -1,    -1,    -1,    43,    31,    -1,
      33,    -1,    35,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      43,    -1,    -1,    59,    -1,    61,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    70,    71,    59,    -1,    61,    75,
      76,    -1,    -1,    79,    -1,    -1,    -1,    70,    71,    -1,
      -1,    87,    75,    76,    -1,    -1,    79,    -1,    -1,    -1,
       1,    -1,    -1,    -1,    87,    -1,    -1,    -1,    -1,    10,
     106,    -1,    -1,   109,    -1,    16,    17,    -1,   114,    -1,
      -1,    -1,    -1,   106,    25,    26,   109,    -1,    -1,    30,
      -1,   114,    33,    -1,    35,    -1,    37,    -1,    -1,     1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    10,    -1,
      -1,    -1,    -1,    -1,    16,    -1,    -1,    -1,    59,    60,
      61,    23,    -1,    25,    26,    -1,    -1,    -1,    30,    70,
      71,    33,     1,    35,    75,    37,    -1,    78,    79,    -1,
      -1,    10,    -1,    -1,    85,    86,    87,    16,    89,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    25,    59,    -1,    61,
      -1,    30,    -1,    -1,    33,     1,    35,    -1,    70,    71,
      -1,    -1,    -1,    75,    10,    -1,    78,    79,    -1,    -1,
      16,    17,    -1,    85,    86,    87,    -1,    89,    -1,    25,
      59,    -1,    61,    -1,    -1,    -1,    -1,    33,     1,    35,
      -1,    -1,    71,    -1,    -1,    -1,    75,    10,    -1,    78,
      79,    -1,    -1,    16,    -1,    -1,    85,    86,    87,    -1,
      89,    -1,    25,    59,    -1,    61,    -1,    30,    -1,    -1,
      33,    -1,    35,    -1,    -1,    71,    -1,    -1,    -1,    75,
      -1,    -1,    78,    79,    -1,    -1,    10,    -1,    -1,    85,
      86,    87,    16,    89,    -1,    -1,    59,    -1,    61,    23,
      -1,    25,    26,    -1,    -1,    -1,    30,    -1,    71,    33,
      -1,    35,    75,    -1,    -1,    78,    79,    -1,    -1,    -1,
      -1,    -1,    85,    86,    87,    10,    89,    -1,    -1,    -1,
      -1,    16,    17,    -1,    -1,    59,    -1,    61,    -1,    -1,
      25,    26,    -1,    -1,    -1,    -1,    70,    71,    33,    -1,
      35,    75,    -1,    -1,    78,    79,    -1,    -1,    10,    -1,
      -1,    85,    86,    87,    16,    89,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    25,    59,    -1,    61,    -1,    30,    -1,
      -1,    33,    -1,    35,    -1,    70,    71,    -1,    -1,    -1,
      75,    10,    -1,    78,    79,    -1,    -1,    16,    17,    -1,
      85,    86,    87,    -1,    89,    -1,    25,    59,    -1,    61,
      -1,    -1,    -1,    -1,    33,    -1,    35,    -1,    -1,    71,
      -1,    -1,    -1,    75,    10,    -1,    78,    79,    -1,    -1,
      16,    -1,    -1,    85,    86,    87,    -1,    89,    -1,    25,
      59,    -1,    61,    -1,    30,    -1,    -1,    33,    -1,    35,
      -1,    -1,    71,    -1,    -1,    -1,    75,    10,    -1,    78,
      79,    -1,    -1,    16,    -1,    -1,    85,    86,    87,    -1,
      89,    -1,    25,    59,    -1,    61,    -1,    -1,    -1,    -1,
      33,    -1,    35,    -1,    -1,    71,    -1,    -1,    -1,    75,
      -1,    -1,    78,    79,    -1,    -1,    -1,    -1,    -1,    85,
      86,    87,    -1,    89,    -1,    -1,    59,    -1,    61,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    71,    -1,
      -1,    -1,    75,    -1,    -1,    78,    79,    -1,    -1,    -1,
      -1,    -1,    85,    86,    87,    -1,    89,   434,   435,   436,
     437,   438,   439,   440,   441,   442,   443,   444,   445,    -1,
      -1,    -1,    -1,    -1,    -1,   452,   453,   454,   455,   456,
     457,   458,   459,   460,   461,   462,   463,   464,   465,   466,
     467,   468,   469,   470,   471,   122,   123,   124,   125,   126,
     127,   128,   129,   130,   131,   132,   133,   134,   135,   136,
      -1,   138,   139,   140,   141
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint16 yystos[] =
{
       0,     1,     7,    35,    61,    85,    86,    88,   164,   165,
     166,   174,   175,   223,   225,   235,   410,   411,   414,   500,
      30,     6,   167,   500,   502,   500,     0,   174,    13,    24,
      31,    44,    59,    78,   100,   176,   177,   178,   179,   181,
     182,   191,   192,   196,   198,   202,   203,   208,   209,   516,
     521,    35,    42,   412,   151,   413,   414,   228,   226,   500,
     500,   500,   173,   500,     1,    19,   500,   119,   180,   269,
     270,   271,   272,   274,   276,   500,   502,   560,   500,     1,
      37,   189,     1,   194,     1,   200,     1,    37,   205,   207,
     558,     1,   211,   167,     1,   238,    62,   411,   152,    62,
     107,   229,   230,   232,   233,   558,   233,   234,    53,    53,
      42,   149,   152,   500,   500,    42,    25,    70,    79,   561,
     149,   152,   156,   146,   147,   252,   275,   252,   275,   147,
      42,    30,   468,     1,   190,    60,   187,    30,    10,    16,
      17,    23,    25,    26,    33,    34,    35,    70,    71,    75,
      79,    87,    89,   162,   179,   195,   202,   208,   213,   214,
     216,   224,   225,   235,   288,   312,   325,   327,   330,   334,
     337,   340,   344,   345,   470,   484,   494,   495,   521,   522,
     569,    30,    16,    34,    78,    87,   179,   201,   222,   345,
     473,   494,    30,   559,    30,    59,   202,   206,   214,   218,
     225,   327,   330,   340,   344,   345,   470,   494,   495,   521,
     522,    37,   152,   557,    30,    30,   212,   213,   214,   219,
     235,   330,   344,   345,   494,   495,   227,    30,   213,   214,
     220,   235,   236,   239,   330,   344,   345,   494,   495,   147,
     418,   415,   500,   231,   230,   147,   240,    67,   557,   500,
     500,   500,    42,    42,    49,   156,   158,   159,   562,   563,
     564,   565,   568,   272,     4,    11,   167,   273,   504,     1,
       3,     5,    49,    52,    55,    57,   121,   135,   136,   143,
     144,   147,   168,   172,   256,   259,   261,   262,   268,   269,
     271,   272,   277,   278,   279,   280,   287,   315,   322,   501,
     503,   504,    63,   500,    63,   500,   259,   271,    30,   517,
      13,    23,    31,   500,   152,   152,   240,   188,   185,    13,
     193,   500,   335,   500,   502,   500,   360,   361,   500,   173,
      11,    57,   269,   341,   173,    11,    57,   173,   486,   487,
     500,   173,     1,   500,     1,   500,   173,   500,    79,   152,
      24,   199,   500,   500,     1,   269,   479,   118,   500,    30,
      59,   204,   500,   240,   204,    47,   152,    59,   210,   500,
     210,   233,    35,    61,   167,   237,    17,    11,   269,   419,
      42,   416,   240,     1,    25,    33,    35,    59,    61,    70,
      75,    79,    89,   223,   243,   247,   332,   549,   550,   551,
     556,   271,    42,    42,    49,   375,   500,   500,   566,   567,
     375,   156,   151,   159,   500,   567,   148,   271,   279,   148,
     268,   268,   268,   268,   268,   259,   283,   284,   287,   322,
     253,    27,    73,   324,    12,    48,    51,    56,    84,    90,
      12,    48,    51,    56,    84,    90,    91,    92,    93,    94,
      95,    96,   122,   123,   124,   125,   126,   127,   128,   129,
     130,   131,   132,   133,   134,   135,   136,   138,   139,   140,
     141,   260,   145,    63,   146,   271,   317,   148,   149,   153,
     500,   148,   100,   518,   100,   178,   179,   515,   519,   520,
     183,   500,   183,   183,   152,   240,    17,   184,   186,   213,
     214,   215,   235,   327,   330,   340,   344,   345,   494,   495,
     500,   152,   151,   336,    53,   151,    30,    15,    83,    88,
     147,   269,   277,   362,   363,   364,   379,   383,   384,   385,
     386,   394,   398,   404,   410,   427,   457,   500,    42,   469,
     151,   342,   151,   151,    37,    78,   485,   490,   151,    42,
     151,   152,    42,   152,     1,    42,   289,   151,    42,   151,
     173,   500,   152,    30,   477,   173,   199,   500,   152,   152,
     147,   249,    19,   152,   152,    67,     6,   500,   500,   152,
     422,   423,   148,   420,   148,    17,   220,   221,   417,   148,
     500,   502,   552,   500,   500,    79,    35,   241,   173,   500,
     152,   156,   160,   523,   147,   156,   500,   566,   271,   313,
     315,   156,   500,   252,   271,   281,   145,   148,   149,   153,
     285,   148,   149,   254,   259,   262,   262,   262,   262,   262,
     262,   262,   262,   262,   262,   262,   262,   262,   262,   262,
     262,   262,   262,   262,   262,   262,   262,   262,   262,   262,
     262,   262,   262,   262,   262,   262,   262,   268,   135,   136,
     143,   144,   263,   265,   267,   268,   276,   323,   147,   277,
     252,   316,   317,   259,   283,   284,   259,   500,   152,   180,
      30,   520,   152,   360,   468,   313,    42,    11,    57,   167,
     346,   347,   271,   193,   259,   259,   386,   398,   427,   457,
     152,   130,   151,    37,   472,   313,   149,   343,   271,   313,
     500,    47,    24,    31,    55,   118,   488,   491,   152,    60,
     489,   259,    49,   313,   313,   152,     8,    14,    33,    64,
     108,   147,   290,   291,   294,   300,   304,   306,   310,   311,
     317,   505,   510,   152,   313,   147,   499,   500,   502,   151,
      34,   179,   475,   478,   152,   152,    55,   102,   105,   154,
     255,   257,   258,   259,   269,   500,   271,    30,    22,    39,
      52,    67,    80,    83,   394,   424,   425,   426,   427,   432,
     439,   446,   449,   450,   453,   456,   457,   458,   460,   461,
     462,   463,   464,   500,   531,   532,   534,   535,   536,   540,
     543,   545,   149,   421,   422,   107,   147,   554,    42,   554,
     552,   148,   152,   242,   151,   500,    67,   161,   271,   524,
     525,   152,   557,   259,   156,   252,   314,   120,   252,   282,
     268,   283,   259,   155,   286,   256,   265,   265,   268,   268,
     134,   135,   136,   264,   324,   138,   139,   140,   141,   266,
     145,   259,   153,   152,   518,   152,     1,   269,   348,    42,
     523,   152,   152,    66,   429,    68,    38,   395,   397,    18,
      22,    23,    24,    31,    88,   269,   378,   386,   398,   405,
     407,   427,   457,   527,   240,    60,   471,   150,   326,   269,
       9,    42,    55,   338,   249,   271,   269,   173,   490,    30,
      47,     1,   375,    21,    65,   329,   333,   152,   313,   147,
     318,    53,   173,   309,     1,    19,   506,   169,   500,   504,
      76,   150,   331,     1,    13,    23,    24,    25,    31,    33,
      35,    43,    59,    61,    70,    71,    75,    76,    79,    87,
     106,   109,   114,   350,   496,   498,   147,   313,   152,    34,
     473,   474,   476,   480,   481,   197,   259,   250,   153,   237,
       1,   157,   430,   259,   152,   259,   459,    54,   467,   259,
     130,   150,    32,    34,    50,    66,    82,   357,   358,   359,
     448,    22,   269,   394,   427,   460,   464,   545,    81,   152,
     151,   269,    30,   555,   243,    67,    49,   554,   243,    20,
      40,    41,    45,    58,   246,   248,   271,   161,    67,   149,
     526,   152,   148,   148,   259,   287,   265,   263,   267,   268,
     148,   259,   152,   152,   523,   149,   349,   259,   151,   259,
      69,   428,   394,    97,   259,   387,   388,   391,    74,   105,
     110,   396,   365,     1,   259,   386,   398,   427,   457,   380,
     381,   375,   376,   356,   358,    39,   351,   352,   152,   240,
     468,   259,   152,   259,   248,   339,   259,   152,   152,   489,
      34,   249,   152,   523,   150,   328,   271,   303,   313,   321,
     323,    53,   271,   151,   307,    30,     1,   511,    30,   179,
     224,   345,   507,   509,   522,   292,   298,   500,   259,   152,
     152,   154,   497,   148,   149,   492,   493,   500,   504,   331,
     486,   500,    30,   148,   149,   251,   258,   152,    30,   259,
      72,   152,   419,    77,   466,    68,     1,    74,   104,   105,
     110,   111,   388,   391,   542,   259,   452,   500,   462,   500,
     455,   500,   259,   259,    46,   430,   150,   259,   413,   147,
     241,   271,   375,    67,   313,   271,   271,   152,   167,   152,
     350,   259,   152,   130,     9,    52,   392,   152,    81,   389,
     259,    42,   374,    36,    36,    37,    60,   147,   377,    37,
      60,    36,   259,   462,   500,    30,   406,   409,   152,   152,
     152,   259,    42,   152,   152,   557,   259,   152,    63,   301,
     319,   313,   313,    30,   308,   309,   108,   508,    30,    30,
     220,   512,   514,   508,   148,   149,   293,   296,   152,   148,
     152,   496,   148,   149,   152,    78,   483,   490,    34,   255,
      22,   433,   440,   259,    34,   465,   430,   152,    40,    58,
     541,   259,   541,   152,    81,   388,   391,    81,   451,   500,
      40,   151,    81,   454,   428,   422,   259,   259,    28,   152,
     544,   152,   243,   148,    42,   553,   557,   271,    20,    21,
     245,   395,   259,     9,   393,   259,   149,   390,   105,   147,
     373,     1,    81,   528,   529,    47,    47,   500,    47,    47,
      17,   216,   217,   402,    36,   259,    36,   152,   408,   500,
      30,   152,   259,   152,   154,   148,   149,   302,   148,   149,
     320,   152,    64,   500,   108,   513,   513,   169,    30,   297,
     299,   500,   152,   492,   118,   488,   473,   482,   489,   152,
     157,   431,   500,    42,   422,   259,   152,   269,   277,   394,
     548,   259,   105,   152,   259,   152,    81,   259,   152,    40,
     271,   321,   259,   152,   152,    30,   434,   259,    28,   152,
     241,   154,   500,   553,   150,   244,   399,   400,   259,    28,
     391,   259,    37,   371,    30,   284,   462,    30,   528,   530,
     249,   249,   148,   249,   249,    17,   216,   360,   402,   403,
      36,   500,   152,   152,   408,    53,   271,   303,   321,   305,
     500,    19,    76,   295,   133,   173,   152,    30,   152,   152,
      81,   437,   443,   130,   150,    81,   152,    28,   152,   533,
     259,   321,    46,    42,    81,   259,   148,   259,   152,   388,
     401,   387,   148,   240,    60,   369,    36,   153,   284,    36,
     152,   500,    30,    60,   382,   152,   382,   152,   406,   360,
     354,   403,   152,   313,    63,   500,   500,   170,   171,   503,
     152,    34,   284,   435,    28,    29,   441,   444,   104,   537,
     542,   259,   546,   547,   259,   259,   152,   152,   533,   447,
     500,   437,   259,    81,    81,   374,   152,   240,   367,   408,
     403,   153,   408,   152,    36,    47,   152,   152,    28,    29,
     353,   355,   354,   152,   500,   152,   153,    30,   436,   437,
     442,   259,    30,   541,   391,   538,   539,    81,   152,   544,
      81,   152,   152,   435,   259,   284,    37,   372,   152,    17,
     216,   368,   152,   403,   152,   408,   249,    36,   462,   500,
     259,   462,   353,   438,    22,   422,    72,    39,   546,    81,
     284,   152,   259,    30,   149,    47,    60,   370,   360,   152,
     403,    36,    36,   259,   422,   431,   445,   152,   284,   149,
     152,    22,   249,    47,    30,   403,   403,    36,   152,   422,
     149,   152,   546,   431,   152,   249,    18,   403,   538,   152,
     152,   366,   500,   152
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;


  /* User initialization code.  */

{ yydebug=0; }
/* Line 1078 of yacc.c.  */

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 8:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 9:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 10:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 11:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 12:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 13:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 14:

    { (yyval.qstr)="null"; ;}
    break;

  case 15:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 16:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 17:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 18:

    { (yyval.qstr)=""; ;}
    break;

  case 19:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 20:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 21:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 22:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+","+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 35:

    {
                   if ( parse_sec == 0)
                   {
                    addVhdlType((yyvsp[(2) - (3)].qstr),getParsedLine(t_LIBRARY),Entry::VARIABLE_SEC,VhdlDocGen::LIBRARY,(yyvsp[(2) - (3)].qstr).data(),"_library_");
                   }
                   (yyval.qstr)="library "+(yyvsp[(2) - (3)].qstr);
                 ;}
    break;

  case 36:

    {
                   QStringList ql1=QStringList::split(",",(yyvsp[(2) - (3)].qstr),FALSE);
                   for (uint j=0;j<ql1.count();j++)
                   {
                     QStringList ql=QStringList::split(".",ql1[j],FALSE);
                     QCString it=ql[1].utf8();
                     if ( parse_sec == 0 )
                     {
                       addVhdlType(it,getParsedLine(t_USE),Entry::VARIABLE_SEC,VhdlDocGen::USE,it.data(),"_use_");
                     }
                   }
                   (yyval.qstr)="use "+(yyvsp[(2) - (3)].qstr);
                 ;}
    break;

  case 37:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 38:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+","+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 41:

    {
                (yyval.qstr)=(yyvsp[(2) - (3)].qstr);
                lastEntity=current;
                lastCompound=0;
                 getParsedLine(t_ENTITY);
                addVhdlType((yyval.qstr),getParsedLine(t_ENTITY),Entry::CLASS_SEC,VhdlDocGen::ENTITY,0,0,Public);
               ;}
    break;

  case 49:

    { (yyval.qstr)=""; ;}
    break;

  case 50:

    { currP=VhdlDocGen::PORT; ;}
    break;

  case 51:

    { currP=0; ;}
    break;

  case 52:

    { (yyval.qstr)=""; ;}
    break;

  case 53:

    { currP=VhdlDocGen::GENERIC;parse_sec=GEN_SEC; ;}
    break;

  case 54:

    { currP=0;parse_sec=0; ;}
    break;

  case 55:

    { currP=0; ;}
    break;

  case 58:

    {
                  (yyval.qstr)=(yyvsp[(4) - (5)].qstr)+"::"+(yyvsp[(2) - (5)].qstr);
                  genLabels.resize(0);
                  pushLabel(genLabels,(yyvsp[(2) - (5)].qstr));
                  lastCompound=current;
                  addVhdlType((yyval.qstr),getParsedLine(t_ARCHITECTURE),Entry::CLASS_SEC,VhdlDocGen::ARCHITECTURE,0,0,Private);
                ;}
    break;

  case 63:

    { (yyval.qstr)=""; ;}
    break;

  case 66:

    { genLabels.resize(0); ;}
    break;

  case 67:

    { genLabels.resize(0); ;}
    break;

  case 68:

    {
                  QCString k=(yyvsp[(3) - (7)].qstr);
                  QCString k2=(yyvsp[(2) - (7)].qstr);        
                  confName="";
                ;}
    break;

  case 69:

    {
                  forL.resize(0);
                  confName=(yyvsp[(2) - (5)].qstr)+"::"+(yyvsp[(4) - (5)].qstr);
                  addVhdlType((yyvsp[(2) - (5)].qstr).data(),getParsedLine(t_CONFIGURATION),Entry::VARIABLE_SEC,VhdlDocGen::CONFIG,"configuration",(yyvsp[(4) - (5)].qstr).data());
                ;}
    break;

  case 70:

    { (yyval.qstr)=""; ;}
    break;

  case 71:

    { 
                  QCString l=(yyvsp[(1) - (1)].qstr);
                  (yyval.qstr)=(yyvsp[(1) - (1)].qstr); 
                ;}
    break;

  case 72:

    { (yyval.qstr)="configuration"; ;}
    break;

  case 73:

    { (yyval.qstr)=(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 74:

    { (yyval.qstr)=""; ;}
    break;

  case 75:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 76:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 79:

    {
                          lastCompound=current;
                          Entry *clone=new Entry(*current);
                         clone->section=Entry::NAMESPACE_SEC;
                         clone->spec=VhdlDocGen::PACKAGE;
                         clone->name=(yyvsp[(2) - (3)].qstr);
                         clone->startLine=s_str.iLine;
                         clone->bodyLine=s_str.iLine;
                         clone->protection=Package;
                         current_root->addSubEntry(clone);
                         addVhdlType((yyvsp[(2) - (3)].qstr),s_str.iLine,Entry::CLASS_SEC,VhdlDocGen::PACKAGE,0,0,Package);
                       ;}
    break;

  case 81:

    { lastCompound=0; ;}
    break;

  case 82:

    { lastCompound=0; ;}
    break;

  case 83:

    { lastCompound=0; ;}
    break;

  case 94:

    {
                        (yyval.qstr)=(yyvsp[(3) - (4)].qstr);
                        lastCompound=current;
                        (yyval.qstr).prepend("_");
                        addVhdlType((yyval.qstr),getParsedLine(t_PACKAGE) ,Entry::CLASS_SEC,VhdlDocGen::PACKAGE_BODY,0,0,Protected);
                      ;}
    break;

  case 95:

    { (yyval.qstr)="";lastCompound=0; ;}
    break;

  case 96:

    { lastCompound=0; ;}
    break;

  case 97:

    { lastCompound=0; ;}
    break;

  case 98:

    { lastCompound=0; ;}
    break;

  case 99:

    { (yyval.qstr)=""; ;}
    break;

  case 106:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 107:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 108:

    {  (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 109:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 110:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 111:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 112:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 113:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 114:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 115:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 116:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 117:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 118:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 119:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 120:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 121:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 122:

    { (yyval.qstr)=""; ;}
    break;

  case 134:

    { (yyval.qstr)=""; ;}
    break;

  case 135:

    { (yyval.qstr)=""; ;}
    break;

  case 158:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 159:

    { (yyval.qstr)=""; ;}
    break;

  case 160:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 161:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 162:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 164:

    { (yyval.qstr)=""; ;}
    break;

  case 165:

    { (yyval.qstr)=""; ;}
    break;

  case 166:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 167:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 168:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 169:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 170:

    { (yyval.qstr)=(yyvsp[(3) - (4)].qstr); ;}
    break;

  case 171:

    { (yyval.qstr)="pure"; ;}
    break;

  case 172:

    { (yyval.qstr)="impure"; ;}
    break;

  case 173:

    { currP=0; ;}
    break;

  case 174:

    { 
              currP=VhdlDocGen::PROCEDURE; 
              createFunction((yyvsp[(2) - (2)].qstr),currP,0); 
              tempEntry=current;
             ;}
    break;

  case 175:

    {  newEntry(); ;}
    break;

  case 176:

    {
                currP=VhdlDocGen::FUNCTION;
                createFunction((yyvsp[(1) - (3)].qstr),currP,(yyvsp[(3) - (3)].qstr).data());
              ;}
    break;

  case 177:

    {
                tempEntry=current;
                current->type=(yyvsp[(7) - (7)].qstr);
                newEntry();
              ;}
    break;

  case 178:

    {
                currP=VhdlDocGen::FUNCTION;
                createFunction(0,currP,(yyvsp[(2) - (2)].qstr).data());
              ;}
    break;

  case 179:

    {
                tempEntry=current;
                current->bodyLine=getParsedLine(t_FUNCTION);
                current->type=(yyvsp[(6) - (6)].qstr);
                newEntry();

              ;}
    break;

  case 182:

    { param_sec=PARAM_SEC; ;}
    break;

  case 183:

    { param_sec= 0; ;}
    break;

  case 184:

    { param_sec=PARAM_SEC; ;}
    break;

  case 185:

    { param_sec= 0; ;}
    break;

  case 191:

    {
      if ((yyvsp[(3) - (3)].qstr).data())
      {
        FlowChart::addFlowChart(FlowChart::VARIABLE_NO,(yyvsp[(3) - (3)].qstr),0);
      }
      FlowChart::addFlowChart(FlowChart::BEGIN_NO,"BEGIN",0);
    ;}
    break;

  case 192:

    {
      tempEntry->endBodyLine=s_str.yyLineNr;
      createFlow();    
      currP=0;
    ;}
    break;

  case 193:

    {
      currP=0;
    ;}
    break;

  case 201:

    { (yyval.qstr)=""; ;}
    break;

  case 202:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 203:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 204:

    { (yyval.qstr)=""; ;}
    break;

  case 205:

    { (yyval.qstr)=""; ;}
    break;

  case 209:

    {
                    // adding generic :  [ package foo  is new bar]
                    if (parse_sec==GEN_SEC)
                    {
                       addVhdlType(current->name.data(),getParsedLine(t_PACKAGE),Entry::VARIABLE_SEC,VhdlDocGen::GENERIC,(yyvsp[(1) - (1)].qstr).data(),0);
                    }
                  ;}
    break;

  case 210:

    {
                    if (parse_sec==GEN_SEC)
                    {
                      int a=getParsedLine(t_FUNCTION);
                      int b=getParsedLine(t_PROCEDURE);

                      if (a>b) b=a;

                      addVhdlType(current->name.data(),b,Entry::VARIABLE_SEC,VhdlDocGen::GENERIC,(yyvsp[(1) - (1)].qstr).data(),0);
                    }
                  ;}
    break;

  case 211:

    {
                    if (parse_sec==GEN_SEC)
                    {
                        addVhdlType((yyvsp[(2) - (2)].qstr),s_str.iLine,Entry::VARIABLE_SEC,currP,(yyvsp[(1) - (2)].qstr).data(),0);
                    }
                  ;}
    break;

  case 212:

    {
                    (yyval.qstr)=(yyvsp[(2) - (7)].qstr)+":"+(yyvsp[(4) - (7)].qstr)+(yyvsp[(5) - (7)].qstr)+(yyvsp[(6) - (7)].qstr)+(yyvsp[(7) - (7)].qstr);
                    if (currP!=VhdlDocGen::COMPONENT)
                    {
                      if (currP==VhdlDocGen::FUNCTION || currP==VhdlDocGen::PROCEDURE)
                      {
                        addProto((yyvsp[(1) - (7)].qstr).data(),(yyvsp[(2) - (7)].qstr).data(),(yyvsp[(4) - (7)].qstr).data(),(yyvsp[(5) - (7)].qstr).data(),(yyvsp[(6) - (7)].qstr).data(),(yyvsp[(7) - (7)].qstr).data());
                      }
                      else
                      {
                        QCString i=(yyvsp[(5) - (7)].qstr)+(yyvsp[(6) - (7)].qstr)+(yyvsp[(7) - (7)].qstr);
                        if (currP==VhdlDocGen::GENERIC)
                          addVhdlType((yyvsp[(2) - (7)].qstr),s_str.iLine,Entry::VARIABLE_SEC,currP,i.data(),(yyvsp[(4) - (7)].qstr).data());
                        else if(parse_sec != GEN_SEC)
                          addVhdlType((yyvsp[(2) - (7)].qstr),s_str.iLine,Entry::VARIABLE_SEC,currP,i.data(),(yyvsp[(4) - (7)].qstr).data());
                      }
                      //   fprintf(stderr,"\n\n <<port  %s  >>\n",$$.data());
                    } // if component
                  ;}
    break;

  case 213:

    { (yyval.qstr)=""; ;}
    break;

  case 214:

    { (yyval.qstr)=":="+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 215:

    { (yyval.qstr)=""; ;}
    break;

  case 216:

    { (yyval.qstr)="buffer"; ;}
    break;

  case 217:

    { (yyval.qstr)="bus"; ;}
    break;

  case 218:

    { (yyval.qstr)=""; ;}
    break;

  case 219:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 220:

    { (yyval.qstr)=""; ;}
    break;

  case 221:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 222:

    { (yyval.qstr)="in"; ;}
    break;

  case 223:

    { (yyval.qstr)="out"; ;}
    break;

  case 224:

    { (yyval.qstr)="inout"; ;}
    break;

  case 225:

    { (yyval.qstr)="buffer"; ;}
    break;

  case 226:

    { (yyval.qstr)="link"; ;}
    break;

  case 227:

    { (yyval.qstr)="("+(yyvsp[(2) - (4)].qstr)+")"; ;}
    break;

  case 228:

    { (yyval.qstr)=""; ;}
    break;

  case 229:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 230:

    { (yyval.qstr)=", "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 231:

    {
      QCString str="( "+(yyvsp[(2) - (4)].qstr)+(yyvsp[(3) - (4)].qstr);
      str.append(" )");
      (yyval.qstr)=str;
    ;}
    break;

  case 232:

    { (yyval.qstr)=""; ;}
    break;

  case 233:

    { (yyval.qstr)=" ( open ) "; ;}
    break;

  case 234:

    { (yyval.qstr)=""; ;}
    break;

  case 235:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 236:

    { (yyval.qstr)=","+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 237:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"=>"+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 238:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 239:

    { (yyval.qstr)="<>"; ;}
    break;

  case 240:

    { (yyval.qstr)="default"; ;}
    break;

  case 241:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 242:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"=>"+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 243:

    {  (yyval.qstr)=(yyvsp[(1) - (1)].qstr) ; ;}
    break;

  case 244:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 245:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 246:

    { (yyval.qstr)="open"; ;}
    break;

  case 247:

    { (yyval.qstr)="inertial"; ;}
    break;

  case 248:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 249:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 250:

    { (yyval.qstr)="sll"; ;}
    break;

  case 251:

    { (yyval.qstr)="sra"; ;}
    break;

  case 252:

    { (yyval.qstr)="sla"; ;}
    break;

  case 253:

    { (yyval.qstr)="srl"; ;}
    break;

  case 254:

    { (yyval.qstr)="ror"; ;}
    break;

  case 255:

    { (yyval.qstr)="rol"; ;}
    break;

  case 256:

    { (yyval.qstr)= (yyvsp[(1) - (3)].qstr)+(yyvsp[(2) - (3)].qstr)+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 257:

    { (yyval.qstr)= (yyvsp[(1) - (3)].qstr)+" and "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 258:

    { (yyval.qstr)= (yyvsp[(1) - (3)].qstr)+" xor "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 259:

    { (yyval.qstr)= (yyvsp[(1) - (3)].qstr)+" or "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 260:

    { (yyval.qstr)= (yyvsp[(1) - (3)].qstr)+" nor "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 261:

    { (yyval.qstr)= (yyvsp[(1) - (3)].qstr)+"xnor"+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 262:

    { (yyval.qstr)= (yyvsp[(1) - (3)].qstr)+"nand"+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 263:

    { (yyval.qstr)= (yyvsp[(1) - (3)].qstr)+"nand"+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 264:

    { (yyval.qstr)= (yyvsp[(1) - (3)].qstr)+"nor"+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 265:

    { (yyval.qstr)= (yyvsp[(1) - (3)].qstr)+"nand"+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 266:

    { (yyval.qstr)= (yyvsp[(1) - (3)].qstr)+" and "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 267:

    { (yyval.qstr)= (yyvsp[(1) - (3)].qstr)+" or "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 268:

    { (yyval.qstr)= (yyvsp[(1) - (3)].qstr)+" xor "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 269:

    { (yyval.qstr)=" ?? "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 270:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 271:

    { (yyval.qstr)="+"+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 272:

    { (yyval.qstr)="-"+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 273:

    { (yyval.qstr)="abs"+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 274:

    { (yyval.qstr)="not "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 275:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" ** "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 276:

    { (yyval.qstr)=(yyvsp[(2) - (4)].qstr)+" ** "+(yyvsp[(4) - (4)].qstr); ;}
    break;

  case 277:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" mod "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 278:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" rem "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 279:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" & "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 280:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" * "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 281:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" + "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 282:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" - "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 283:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" <= "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 284:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" >= "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 285:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" < "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 286:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" > "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 287:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" == "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 288:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" != "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 289:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" / "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 290:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" ?/= "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 291:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" ?= "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 292:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" ?< "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 293:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" ?> "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 294:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" ?<= "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 295:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" ?>= "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 296:

    { (yyval.qstr) = "-"+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 297:

    { (yyval.qstr) = "+"+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 298:

    { (yyval.qstr) = (yyvsp[(1) - (1)].qstr); ;}
    break;

  case 299:

    { (yyval.qstr) = (yyvsp[(1) - (3)].qstr)+" "+(yyvsp[(2) - (3)].qstr)+" "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 300:

    { (yyval.qstr) = "&"; ;}
    break;

  case 301:

    { (yyval.qstr) = "-"; ;}
    break;

  case 302:

    { (yyval.qstr) = "+"; ;}
    break;

  case 303:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 304:

    { (yyval.qstr) = (yyvsp[(1) - (3)].qstr)+" "+(yyvsp[(2) - (3)].qstr)+" "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 305:

    { (yyval.qstr) = "*";   ;}
    break;

  case 306:

    { (yyval.qstr) = "rem"; ;}
    break;

  case 307:

    { (yyval.qstr) = "mod"; ;}
    break;

  case 308:

    { (yyval.qstr) = "/";   ;}
    break;

  case 309:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 310:

    { (yyval.qstr)="abs "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 311:

    { (yyval.qstr)="not  "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 312:

    { (yyval.qstr) = (yyvsp[(1) - (3)].qstr)+" ** "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 313:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 314:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 315:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 316:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 317:

    { (yyval.qstr)=""; ;}
    break;

  case 318:

    { (yyval.qstr)="("+(yyvsp[(2) - (3)].qstr)+")"; ;}
    break;

  case 319:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 320:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 321:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 322:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 323:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 324:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 325:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 326:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 327:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"."+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 328:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 329:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 330:

    { (yyval.qstr)="all"; ;}
    break;

  case 331:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 332:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 333:

    { (yyval.qstr)="'"; ;}
    break;

  case 334:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"' "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 336:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" '"+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 337:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"' range "; ;}
    break;

  case 338:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"' range "; ;}
    break;

  case 339:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" ) "; ;}
    break;

  case 340:

    { (yyval.qstr)="( "+(yyvsp[(2) - (5)].qstr)+ "=>"+(yyvsp[(4) - (5)].qstr)+" ) "; ;}
    break;

  case 341:

    { (yyval.qstr)=" ( "+(yyvsp[(2) - (4)].qstr)+","+(yyvsp[(4) - (4)].qstr); ;}
    break;

  case 342:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+","+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 343:

    { (yyval.qstr)=(yyvsp[(1) - (5)].qstr)+"'("+(yyvsp[(4) - (5)].qstr)+" ) "; ;}
    break;

  case 344:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"'"+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 352:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"=> "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 353:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 354:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 355:

    { (yyval.qstr)="";        ;}
    break;

  case 356:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 357:

    { (yyval.qstr)=" | "+(yyvsp[(2) - (2)].qstr);  ;}
    break;

  case 358:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 359:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 360:

    { (yyval.qstr)="others"; ;}
    break;

  case 361:

    { (yyval.qstr)=""; ;}
    break;

  case 362:

    {
             addVhdlType((yyvsp[(2) - (4)].qstr),getParsedLine(t_TYPE),Entry::VARIABLE_SEC,VhdlDocGen::TYPE,0,(yyvsp[(3) - (4)].qstr).data());
            (yyval.qstr)="type ";
            (yyval.qstr)+=(yyvsp[(2) - (4)].qstr)+(yyvsp[(3) - (4)].qstr)+";";
           ;}
    break;

  case 363:

    { (yyval.qstr)=""; ;}
    break;

  case 364:

    { (yyval.qstr)=""; ;}
    break;

  case 365:

    { (yyval.qstr)=" is "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 366:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 367:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 368:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 369:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 370:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 371:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 372:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 373:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 374:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 375:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 376:

    { (yyval.qstr)="( "+(yyvsp[(2) - (4)].qstr)+" "+(yyvsp[(3) - (4)].qstr)+" )"; ;}
    break;

  case 377:

    { (yyval.qstr)=""; ;}
    break;

  case 378:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 379:

    { (yyval.qstr)=","+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 380:

    {
                             (yyval.qstr)=(yyvsp[(1) - (6)].qstr);
                             current->args=(yyvsp[(3) - (6)].qstr)+"#"+(yyvsp[(4) - (6)].qstr);
                             current->args.prepend("units");
                             current->spec=VhdlDocGen::UNITS;
                           ;}
    break;

  case 383:

    { (yyval.qstr)=""; ;}
    break;

  case 384:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 385:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr)+"#"; ;}
    break;

  case 386:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr); ;}
    break;

  case 387:

    { (yyval.qstr)=(yyvsp[(1) - (4)].qstr)+"="+(yyvsp[(3) - (4)].qstr); ;}
    break;

  case 388:

    {
      QCString sr1=" array ( "+(yyvsp[(3) - (7)].qstr)+" "+(yyvsp[(4) - (7)].qstr);
      QCString sr2=" ) of "+(yyvsp[(7) - (7)].qstr);
      (yyval.qstr)=sr1+sr2;
    ;}
    break;

  case 389:

    { (yyval.qstr)=""; ;}
    break;

  case 390:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+"  "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 391:

    { (yyval.qstr)=", "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 392:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" range<> "; ;}
    break;

  case 393:

    { (yyval.qstr)=" array "+(yyvsp[(2) - (4)].qstr)+" of "+(yyvsp[(4) - (4)].qstr); ;}
    break;

  case 394:

    { (yyval.qstr)=""; ;}
    break;

  case 395:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 396:

    {
      QRegExp reg("[\\s]");
      QCString oo=(yyvsp[(2) - (6)].qstr)+" "+(yyvsp[(3) - (6)].qstr);
      current->spec=VhdlDocGen::RECORD;
      current->args=oo;
      current->args.replace(reg,"%");
      current->args.prepend("record");
      (yyval.qstr)=(yyvsp[(2) - (6)].qstr)+" "+(yyvsp[(3) - (6)].qstr);
    ;}
    break;

  case 397:

    { (yyval.qstr)=""; ;}
    break;

  case 398:

    {
      (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr);
    ;}
    break;

  case 399:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 400:

    { (yyval.qstr)=(yyvsp[(1) - (4)].qstr)+":"+(yyvsp[(3) - (4)].qstr)+"#"; ;}
    break;

  case 401:

    { (yyval.qstr)="access "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 402:

    { (yyval.qstr)="file of "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 403:

    {
      addVhdlType((yyvsp[(2) - (5)].qstr),getParsedLine(t_SUBTYPE),Entry::VARIABLE_SEC,VhdlDocGen::SUBTYPE,0,(yyvsp[(4) - (5)].qstr).data());
    ;}
    break;

  case 404:

    { (yyval.qstr)=""; ;}
    break;

  case 405:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 406:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 407:

    { (yyval.qstr)=""; ;}
    break;

  case 408:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 409:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" "+(yyvsp[(2) - (3)].qstr)+" "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 410:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 411:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" "+(yyvsp[(2) - (3)].qstr)+" "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 412:

    { (yyval.qstr)=""; ;}
    break;

  case 413:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 414:

    { (yyval.qstr)="range "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 415:

    { (yyval.qstr)="("+(yyvsp[(2) - (4)].qstr)+" "+(yyvsp[(3) - (4)].qstr)+")"; ;}
    break;

  case 416:

    { (yyval.qstr)=""; ;}
    break;

  case 417:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 418:

    { (yyval.qstr)=","+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 419:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 420:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 421:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 422:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"  "+(yyvsp[(2) - (3)].qstr)+"  "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 423:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 424:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"  "+(yyvsp[(2) - (3)].qstr)+"  "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 425:

    { (yyval.qstr)=" to "; ;}
    break;

  case 426:

    { (yyval.qstr)=" downto "; ;}
    break;

  case 427:

    {
                                    QCString it=(yyvsp[(4) - (6)].qstr)+" "+(yyvsp[(5) - (6)].qstr);
                                    //  fprintf(stderr,"\n currP %d \n",currP);
                                    addVhdlType((yyvsp[(2) - (6)].qstr),getParsedLine(t_CONSTANT),Entry::VARIABLE_SEC,VhdlDocGen::CONSTANT,0,it.data());
                                    (yyval.qstr)="constant "+(yyvsp[(2) - (6)].qstr);
                                    (yyval.qstr)+=": ";
                                    (yyval.qstr)+=it+";";
                                  ;}
    break;

  case 428:

    { (yyval.qstr)="";      ;}
    break;

  case 429:

    { (yyval.qstr)=":="+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 430:

    {
                                    QCString s=(yyvsp[(4) - (7)].qstr)+" "+(yyvsp[(6) - (7)].qstr);
                                    addVhdlType((yyvsp[(2) - (7)].qstr),getParsedLine(t_SIGNAL),Entry::VARIABLE_SEC,VhdlDocGen::SIGNAL,0,s.data());
                                  ;}
    break;

  case 431:

    { (yyval.qstr)=""; ;}
    break;

  case 432:

    { (yyval.qstr)=":="+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 433:

    { (yyval.qstr)=""; ;}
    break;

  case 434:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 435:

    {
                                    (yyval.qstr)=(yyvsp[(2) - (6)].qstr)+":"+(yyvsp[(4) - (6)].qstr)+" "+(yyvsp[(5) - (6)].qstr)+";";
                                    (yyval.qstr).prepend("variable: ");
                                  ;}
    break;

  case 436:

    {
                                    (yyval.qstr)=(yyvsp[(5) - (7)].qstr)+" "+(yyvsp[(6) - (7)].qstr);
                                    addVhdlType((yyvsp[(3) - (7)].qstr),getParsedLine(t_VARIABLE),Entry::VARIABLE_SEC,VhdlDocGen::SHAREDVARIABLE,0,(yyval.qstr).data());
                                  ;}
    break;

  case 437:

    { (yyval.qstr)=""; ;}
    break;

  case 438:

    { (yyval.qstr)=":="+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 439:

    { (yyval.qstr)="constant"; ;}
    break;

  case 440:

    { (yyval.qstr)="signal"; ;}
    break;

  case 441:

    { (yyval.qstr)="variable"; ;}
    break;

  case 442:

    { (yyval.qstr)="shared"; ;}
    break;

  case 443:

    { (yyval.qstr)="file"; ;}
    break;

  case 444:

    { (yyval.qstr)="type"; ;}
    break;

  case 445:

    { (yyval.qstr)="bus"; ;}
    break;

  case 446:

    { (yyval.qstr)="register"; ;}
    break;

  case 447:

    {
                                    QCString s=(yyvsp[(3) - (7)].qstr)+" is "+(yyvsp[(5) - (7)].qstr)+(yyvsp[(6) - (7)].qstr);
                                    addVhdlType((yyvsp[(2) - (7)].qstr),getParsedLine(t_ALIAS),Entry::VARIABLE_SEC,VhdlDocGen::ALIAS,0,s.data());
                                   (yyval.qstr)="alias "+(yyvsp[(2) - (7)].qstr);
                                   (yyval.qstr)+=": ";
                                   (yyval.qstr)+=s+";";
                                  ;}
    break;

  case 448:

    { (yyval.qstr)=""; ;}
    break;

  case 449:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 450:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 451:

    { (yyval.qstr)=""; ;}
    break;

  case 452:

    { (yyval.qstr)=(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 453:

    {
             addVhdlType((yyvsp[(2) - (8)].qstr),getParsedLine(t_FILE),Entry::VARIABLE_SEC,VhdlDocGen::VFILE,0,(yyvsp[(4) - (8)].qstr).data());
           ;}
    break;

  case 454:

    {
             QCString s=(yyvsp[(4) - (6)].qstr)+" "+(yyvsp[(5) - (6)].qstr);
             addVhdlType((yyvsp[(2) - (6)].qstr),getParsedLine(t_FILE),Entry::VARIABLE_SEC,VhdlDocGen::VFILE,0,s.data());
           ;}
    break;

  case 455:

    { (yyval.qstr)=""; ;}
    break;

  case 456:

    { (yyval.qstr)="open "+(yyvsp[(2) - (4)].qstr)+" is "+s_str.qstr; ;}
    break;

  case 457:

    { (yyval.qstr)=""; ;}
    break;

  case 458:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 459:

    { (yyval.qstr)="disconnect "+(yyvsp[(2) - (7)].qstr)+":"+(yyvsp[(4) - (7)].qstr)+" after "+(yyvsp[(6) - (7)].qstr); ;}
    break;

  case 460:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 461:

    { (yyval.qstr)="others"; ;}
    break;

  case 462:

    { (yyval.qstr)="all"; ;}
    break;

  case 463:

    { (yyval.qstr)=""; ;}
    break;

  case 464:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 465:

    { (yyval.qstr)=" , "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 466:

    {
                  addVhdlType((yyvsp[(2) - (5)].qstr),getParsedLine(t_ATTRIBUTE),Entry::VARIABLE_SEC,VhdlDocGen::ATTRIBUTE,0,(yyvsp[(4) - (5)].qstr).data());
                 (yyval.qstr)= "attribute "+(yyvsp[(2) - (5)].qstr)+ " : "+(yyvsp[(4) - (5)].qstr);
                ;}
    break;

  case 467:

    {
                  QCString att=(yyvsp[(4) - (7)].qstr)+" is "+(yyvsp[(6) - (7)].qstr);
                  addVhdlType((yyvsp[(2) - (7)].qstr),getParsedLine(t_ATTRIBUTE),Entry::VARIABLE_SEC,VhdlDocGen::ATTRIBUTE,0,att.data());
                  (yyval.qstr)="attribute "+att+";";
                ;}
    break;

  case 468:

    { (yyval.qstr)=(yyvsp[(1) - (4)].qstr)+(yyvsp[(2) - (4)].qstr)+":"+(yyvsp[(4) - (4)].qstr); ;}
    break;

  case 469:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 470:

    { (yyval.qstr)="others";  ;}
    break;

  case 471:

    { (yyval.qstr)="all";     ;}
    break;

  case 472:

    { (yyval.qstr)="";        ;}
    break;

  case 473:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 474:

    { (yyval.qstr)=","+(yyvsp[(2) - (2)].qstr);    ;}
    break;

  case 475:

    { (yyval.qstr)="entity";        ;}
    break;

  case 476:

    { (yyval.qstr)="architecture";  ;}
    break;

  case 477:

    { (yyval.qstr)="package";       ;}
    break;

  case 478:

    { (yyval.qstr)="configuration"; ;}
    break;

  case 479:

    { (yyval.qstr)="component";     ;}
    break;

  case 480:

    { (yyval.qstr)="label";         ;}
    break;

  case 481:

    { (yyval.qstr)="type";          ;}
    break;

  case 482:

    { (yyval.qstr)="subtype";       ;}
    break;

  case 483:

    { (yyval.qstr)="procedure";     ;}
    break;

  case 484:

    { (yyval.qstr)="function";              ;}
    break;

  case 485:

    { (yyval.qstr)="signal";        ;}
    break;

  case 486:

    { (yyval.qstr)="variable";      ;}
    break;

  case 487:

    { (yyval.qstr)="constant";      ;}
    break;

  case 488:

    { (yyval.qstr)="group";         ;}
    break;

  case 489:

    { (yyval.qstr)="file";          ;}
    break;

  case 490:

    { (yyval.qstr)="units";         ;}
    break;

  case 491:

    { (yyval.qstr)="literal";       ;}
    break;

  case 492:

    { (yyval.qstr)="sequence";      ;}
    break;

  case 493:

    { (yyval.qstr)="property";      ;}
    break;

  case 494:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 495:

    { (yyval.qstr)=""; ;}
    break;

  case 496:

    { (yyval.qstr)=""; ;}
    break;

  case 497:

    { (yyval.qstr)=""; ;}
    break;

  case 498:

    { (yyval.qstr)="else generate "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 499:

    { (yyval.qstr)="else "+(yyvsp[(2) - (4)].qstr)+" generate "+(yyvsp[(4) - (4)].qstr); ;}
    break;

  case 500:

    { (yyval.qstr)=""; ;}
    break;

  case 501:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 502:

    { (yyval.qstr)="elsif "+(yyvsp[(2) - (4)].qstr)+" generate "+(yyvsp[(4) - (4)].qstr); ;}
    break;

  case 503:

    { (yyval.qstr)="elsif "+(yyvsp[(2) - (5)].qstr)+(yyvsp[(3) - (5)].qstr)+" generate "+(yyvsp[(5) - (5)].qstr); ;}
    break;

  case 504:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 505:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 506:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 507:

    {
    if (!lab.isEmpty())
    {
      (yyval.qstr)=lab+" :for "+(yyvsp[(2) - (4)].qstr)+" in "+(yyvsp[(4) - (4)].qstr);
    }
    else
    {
      (yyval.qstr)=" for "+(yyvsp[(2) - (4)].qstr)+" in "+(yyvsp[(4) - (4)].qstr);
    }
    FlowChart::addFlowChart(FlowChart::FOR_NO,0,(yyval.qstr),lab.data());
    lab.resize(0);
  ;}
    break;

  case 508:

    {
    (yyval.qstr)=lab+" for "+(yyvsp[(2) - (5)].qstr)+(yyvsp[(3) - (5)].qstr)+" in "+(yyvsp[(5) - (5)].qstr);
    FlowChart::addFlowChart(FlowChart::FOR_NO,0,(yyval.qstr),lab.data());
    lab="";
  ;}
    break;

  case 509:

    {
                             (yyval.qstr)=" while "+(yyvsp[(2) - (2)].qstr);
                             FlowChart::addFlowChart(FlowChart::WHILE_NO,0,(yyval.qstr),lab.data());
                             lab="";
                           ;}
    break;

  case 510:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 511:

    { (yyval.qstr)=""; ;}
    break;

  case 512:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 513:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 514:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 515:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 516:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 517:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 518:

    {
                                              QCString li=(yyvsp[(1) - (1)].qstr);
                                              (yyval.qstr)=(yyvsp[(1) - (1)].qstr);
                                            ;}
    break;

  case 519:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 521:

    { pushLabel(genLabels,(yyvsp[(1) - (3)].qstr)); ;}
    break;

  case 522:

    {
              (yyval.qstr)=(yyvsp[(1) - (15)].qstr)+":block"; //+$4+$5+$6+$7+$8+"begin "+$10+" block "+$13;
              genLabels=popLabel(genLabels);
            ;}
    break;

  case 523:

    { (yyval.qstr)=""; ;}
    break;

  case 524:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 525:

    { (yyval.qstr)=""; ;}
    break;

  case 526:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 527:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 528:

    { (yyval.qstr)=""; ;}
    break;

  case 529:

    { (yyval.qstr)="port "+(yyvsp[(2) - (4)].qstr)+";"+(yyvsp[(4) - (4)].qstr); ;}
    break;

  case 530:

    { (yyval.qstr)="port map "+(yyvsp[(3) - (4)].qstr); ;}
    break;

  case 531:

    { (yyval.qstr)=""; ;}
    break;

  case 532:

    { (yyval.qstr)="generic "+(yyvsp[(2) - (4)].qstr)+";"+(yyvsp[(4) - (4)].qstr); ;}
    break;

  case 533:

    { (yyval.qstr)=""; ;}
    break;

  case 534:

    { (yyval.qstr)="generic map "+(yyvsp[(3) - (4)].qstr); ;}
    break;

  case 535:

    { (yyval.qstr)=""; ;}
    break;

  case 536:

    { (yyval.qstr)="("+(yyvsp[(2) - (4)].qstr)+")"+(yyvsp[(4) - (4)].qstr); ;}
    break;

  case 537:

    { (yyval.qstr)=""; ;}
    break;

  case 538:

    { (yyval.qstr)=" is "; ;}
    break;

  case 539:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 540:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"."+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 541:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 542:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 543:

    { (yyval.qstr)="("+(yyvsp[(2) - (3)].qstr)+")"; ;}
    break;

  case 544:

    { (yyval.qstr)="configur�tion";yyLineNr=s_str.iLine; ;}
    break;

  case 545:

    { (yyval.qstr)="entity";yyLineNr=s_str.iLine; ;}
    break;

  case 546:

    { (yyval.qstr)="component";yyLineNr=s_str.iLine; ;}
    break;

  case 547:

    { yyLineNr=s_str.iLine; ;}
    break;

  case 548:

    {
                                 addCompInst((yyvsp[(1) - (9)].qstr).lower().data(),(yyvsp[(3) - (9)].qstr).lower().data(),0,yyLineNr);(yyval.qstr)="";
                               ;}
    break;

  case 549:

    { yyLineNr=s_str.iLine; ;}
    break;

  case 550:

    {
                                 addCompInst((yyvsp[(1) - (8)].qstr).lower().data(),(yyvsp[(3) - (8)].qstr).lower().data(),0,yyLineNr);(yyval.qstr)="222";
                               ;}
    break;

  case 551:

    {
                                 addCompInst((yyvsp[(1) - (8)].qstr).lower().data(),(yyvsp[(4) - (8)].qstr).lower().data(),(yyvsp[(3) - (8)].qstr).data(),yyLineNr);(yyval.qstr)="";
                               ;}
    break;

  case 552:

    {
                                 addCompInst((yyvsp[(1) - (9)].qstr).lower().data(),(yyvsp[(4) - (9)].qstr).lower().data(),(yyvsp[(3) - (9)].qstr).lower().data(),yyLineNr);(yyval.qstr)="";
                               ;}
    break;

  case 555:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+":"+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 556:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 557:

    { (yyval.qstr)=(yyvsp[(1) - (4)].qstr)+":"+"postponed "+(yyvsp[(4) - (4)].qstr); ;}
    break;

  case 558:

    { (yyval.qstr)="postponed "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 559:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+":"+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 560:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 561:

    { (yyval.qstr)=(yyvsp[(1) - (4)].qstr)+":"+"postponed "+(yyvsp[(4) - (4)].qstr); ;}
    break;

  case 562:

    { (yyval.qstr)="postponed "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 563:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+":"+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 564:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 565:

    { (yyval.qstr)=(yyvsp[(1) - (4)].qstr)+":"+"postponed "+(yyvsp[(4) - (4)].qstr); ;}
    break;

  case 566:

    { (yyval.qstr)="postponed "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 567:

    { (yyval.qstr)=(yyvsp[(1) - (4)].qstr)+":"+"postponed "+(yyvsp[(4) - (4)].qstr); ;}
    break;

  case 568:

    { (yyval.qstr)="postponed "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 569:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+":"+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 570:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 571:

    { (yyval.qstr)=(yyvsp[(1) - (5)].qstr)+"<="+(yyvsp[(3) - (5)].qstr)+(yyvsp[(4) - (5)].qstr); ;}
    break;

  case 572:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 573:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" when "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 574:

    { (yyval.qstr)=(yyvsp[(1) - (5)].qstr)+" when "+(yyvsp[(3) - (5)].qstr)+"else"+(yyvsp[(5) - (5)].qstr); ;}
    break;

  case 575:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 576:

    { (yyval.qstr)="unaffected"; ;}
    break;

  case 577:

    { (yyval.qstr)=""; ;}
    break;

  case 578:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 579:

    { (yyval.qstr)=","+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 580:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 581:

    { (yyval.qstr)=""; ;}
    break;

  case 582:

    { (yyval.qstr)="after "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 583:

    { (yyval.qstr)=" null "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 584:

    { (yyval.qstr)=" null "; ;}
    break;

  case 585:

    { (yyval.qstr)="after "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 586:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 587:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 588:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 589:

    { (yyval.qstr)=""; ;}
    break;

  case 590:

    { (yyval.qstr)="transport "; ;}
    break;

  case 591:

    { (yyval.qstr)="transport"+(yyvsp[(2) - (3)].qstr)+" intertial "; ;}
    break;

  case 592:

    { (yyval.qstr)=" intertial "; ;}
    break;

  case 593:

    { (yyval.qstr)=""; ;}
    break;

  case 594:

    { (yyval.qstr)=" guarded "; ;}
    break;

  case 595:

    { (yyval.qstr)="with "+(yyvsp[(2) - (8)].qstr)+" select "+(yyvsp[(4) - (8)].qstr)+"<="+(yyvsp[(6) - (8)].qstr)+(yyvsp[(7) - (8)].qstr); ;}
    break;

  case 596:

    { (yyval.qstr)=(yyvsp[(1) - (4)].qstr)+(yyvsp[(2) - (4)].qstr); ;}
    break;

  case 597:

    { (yyval.qstr)=""; ;}
    break;

  case 598:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 599:

    { (yyval.qstr)=(yyvsp[(1) - (4)].qstr)+" when "+(yyvsp[(3) - (4)].qstr); ;}
    break;

  case 600:

    { (yyval.qstr)=""; ;}
    break;

  case 601:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" begin "; ;}
    break;

  case 602:

    { (yyval.qstr)="begin "; ;}
    break;

  case 604:

    { pushLabel(genLabels,(yyvsp[(1) - (2)].qstr)); ;}
    break;

  case 606:

    { genLabels=popLabel(genLabels); ;}
    break;

  case 607:

    {genLabels=popLabel(genLabels); ;}
    break;

  case 608:

    { pushLabel(genLabels,(yyvsp[(1) - (2)].qstr)); ;}
    break;

  case 611:

    { (yyval.qstr)=""; ;}
    break;

  case 612:

    { (yyval.qstr)=(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 613:

    { (yyval.qstr)="end"; ;}
    break;

  case 614:

    { (yyval.qstr)="end "+(yyvsp[(2) - (3)].qstr); ;}
    break;

  case 615:

    {  
                 current->name=(yyvsp[(1) - (3)].qstr);
                 tempEntry=current;
                 current->endBodyLine=s_str.yyLineNr;
                 newEntry();
                 currName=(yyvsp[(1) - (3)].qstr);
               ;}
    break;

  case 616:

    {
                 current->name=VhdlDocGen::getProcessNumber();
                 current->endBodyLine=s_str.yyLineNr;
                 tempEntry=current;
                 newEntry();
               ;}
    break;

  case 617:

    {  
               currP=VhdlDocGen::PROCESS; 
               current->startLine=s_str.yyLineNr;
               current->bodyLine=s_str.yyLineNr;
               ;}
    break;

  case 618:

    { 
                (yyvsp[(5) - (10)].qstr).stripPrefix((yyvsp[(4) - (10)].qstr).data());
                tempEntry=current;
                currP=0;
                createFunction(currName,VhdlDocGen::PROCESS,(yyvsp[(4) - (10)].qstr).data());
                createFlow();
                currName="";
               ;}
    break;

  case 619:

    { currP=0; ;}
    break;

  case 622:

    { (yyval.qstr)=""; ;}
    break;

  case 623:

    { (yyval.qstr)="postponed"; ;}
    break;

  case 624:

    { (yyval.qstr)=""; ;}
    break;

  case 625:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 626:

    { (yyval.qstr)=""; ;}
    break;

  case 627:

    { (yyval.qstr)=""; ;}
    break;

  case 628:

    { (yyval.qstr)+=(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 629:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 630:

    { (yyval.qstr)=""; ;}
    break;

  case 631:

    { (yyval.qstr)="all"; ;}
    break;

  case 632:

    { (yyval.qstr)=(yyvsp[(2) - (3)].qstr); ;}
    break;

  case 633:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 634:

    { (yyval.qstr)=""; ;}
    break;

  case 635:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 636:

    { (yyval.qstr)=","+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 637:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 638:

    { (yyval.qstr)=""; ;}
    break;

  case 639:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 640:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 641:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr);    FlowChart::addFlowChart(FlowChart::TEXT_NO,(yyval.qstr).data(),0); ;}
    break;

  case 642:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+(yyvsp[(2) - (2)].qstr); FlowChart::addFlowChart(FlowChart::TEXT_NO,(yyval.qstr).data(),0); ;}
    break;

  case 643:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 644:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 645:

    { (yyval.qstr)=""; ;}
    break;

  case 646:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 647:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 648:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); FlowChart::addFlowChart(FlowChart::TEXT_NO,(yyval.qstr).data(),0); ;}
    break;

  case 649:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); FlowChart::addFlowChart(FlowChart::TEXT_NO,(yyval.qstr).data(),0); ;}
    break;

  case 650:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); FlowChart::addFlowChart(FlowChart::RETURN_NO,(yyval.qstr).data(),0); ;}
    break;

  case 651:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 652:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); FlowChart::addFlowChart(FlowChart::TEXT_NO,(yyval.qstr).data(),0); ;}
    break;

  case 653:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); FlowChart::addFlowChart(FlowChart::TEXT_NO,(yyval.qstr).data(),0); ;}
    break;

  case 654:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); FlowChart::addFlowChart(FlowChart::TEXT_NO,(yyval.qstr).data(),0); ;}
    break;

  case 655:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+(yyvsp[(2) - (2)].qstr); FlowChart::addFlowChart(FlowChart::TEXT_NO,(yyval.qstr).data(),0); ;}
    break;

  case 656:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); FlowChart::addFlowChart(FlowChart::TEXT_NO,(yyval.qstr).data(),0); ;}
    break;

  case 657:

    { (yyval.qstr)=(yyvsp[(1) - (5)].qstr)+"report "+(yyvsp[(3) - (5)].qstr)+(yyvsp[(4) - (5)].qstr)+";";  ;}
    break;

  case 658:

    { (yyval.qstr)="assert "+(yyvsp[(2) - (5)].qstr)+(yyvsp[(3) - (5)].qstr)+(yyvsp[(4) - (5)].qstr)+";"; ;}
    break;

  case 659:

    { (yyval.qstr)=""; ;}
    break;

  case 660:

    { (yyval.qstr)=" serverity "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 661:

    { (yyval.qstr)=""; ;}
    break;

  case 662:

    { (yyval.qstr)=" report "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 663:

    { (yyval.qstr)=""; ;}
    break;

  case 664:

    { (yyval.qstr)="?"; ;}
    break;

  case 665:

    { (yyval.qstr)=""; ;}
    break;

  case 666:

    { (yyval.qstr)="?"; ;}
    break;

  case 667:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 668:

    {
                     QCString ca="case "+(yyvsp[(2) - (3)].qstr)+(yyvsp[(3) - (3)].qstr);
                     FlowChart::addFlowChart(FlowChart::CASE_NO,0,ca);
                   ;}
    break;

  case 669:

    { 
                     FlowChart::moveToPrevLevel();
                     FlowChart::addFlowChart(FlowChart::END_CASE,"end case",0);
                   ;}
    break;

  case 670:

    {
                     QCString ca="case "+(yyvsp[(3) - (4)].qstr)+(yyvsp[(4) - (4)].qstr);
                     FlowChart::addFlowChart(FlowChart::CASE_NO,0,ca);
                   ;}
    break;

  case 671:

    {
                     FlowChart::addFlowChart(FlowChart::END_CASE,0,0);
                     FlowChart::moveToPrevLevel();
                   ;}
    break;

  case 672:

    { (yyval.qstr)=""; ;}
    break;

  case 673:

    { (yyval.qstr)=""; ;}
    break;

  case 674:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 675:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 676:

    { 
    QCString t="when ";
    t+=(yyvsp[(2) - (3)].qstr)+"=> ";
    FlowChart::addFlowChart(FlowChart::WHEN_NO,0,t);
  ;}
    break;

  case 677:

    { (yyval.qstr)=""; FlowChart::moveToPrevLevel(); ;}
    break;

  case 678:

    {
    (yyvsp[(2) - (3)].qstr).prepend("if ");
    FlowChart::addFlowChart(FlowChart::IF_NO,0,(yyvsp[(2) - (3)].qstr));
  ;}
    break;

  case 679:

    {
    FlowChart::moveToPrevLevel();
    FlowChart::addFlowChart(FlowChart::ENDIF_NO,0,0);
  ;}
    break;

  case 680:

    { (yyval.qstr)=""; ;}
    break;

  case 681:

    {
    FlowChart::addFlowChart(FlowChart::ELSE_NO,0,0);
  ;}
    break;

  case 682:

    { 
    (yyval.qstr)=""; FlowChart::moveToPrevLevel();
  ;}
    break;

  case 683:

    { (yyval.qstr)=""; ;}
    break;

  case 684:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 685:

    { 
    (yyvsp[(2) - (3)].qstr).prepend("elsif ");
    FlowChart::addFlowChart(FlowChart::ELSIF_NO,0,(yyvsp[(2) - (3)].qstr).data());
  ;}
    break;

  case 686:

    { (yyval.qstr)=""; ;}
    break;

  case 687:

    {
    (yyval.qstr)=(yyvsp[(1) - (8)].qstr)+(yyvsp[(2) - (8)].qstr)+" loop "+(yyvsp[(4) - (8)].qstr)+" end loop" +(yyvsp[(7) - (8)].qstr);
    QCString endLoop="end loop" + (yyvsp[(7) - (8)].qstr);
    FlowChart::moveToPrevLevel();
    FlowChart::addFlowChart(FlowChart::END_LOOP,endLoop.data(),0);
  ;}
    break;

  case 688:

    { (yyval.qstr)=""; ;}
    break;

  case 689:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 690:

    { (yyval.qstr)=""; 
                           FlowChart::addFlowChart(FlowChart::LOOP_NO,0,"infinite loop");
                         ;}
    break;

  case 692:

    { (yyval.qstr)=""; ;}
    break;

  case 693:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+":";lab=(yyvsp[(1) - (2)].qstr); ;}
    break;

  case 694:

    {
                         FlowChart::addFlowChart(FlowChart::EXIT_NO,"exit",(yyvsp[(4) - (5)].qstr).data(),(yyvsp[(3) - (5)].qstr).data()); 
                         lab.resize(0);
                       ;}
    break;

  case 695:

    { (yyval.qstr)=""; ;}
    break;

  case 696:

    { (yyval.qstr)="when "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 697:

    { (yyval.qstr)=""; ;}
    break;

  case 698:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr);lab=(yyval.qstr); ;}
    break;

  case 699:

    {
                         FlowChart::addFlowChart(FlowChart::NEXT_NO,"next ",(yyvsp[(4) - (5)].qstr).data(),(yyvsp[(3) - (5)].qstr).data()); 
                         lab.resize(0);
                       ;}
    break;

  case 700:

    { (yyval.qstr)=""; ;}
    break;

  case 701:

    { (yyval.qstr)="when "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 702:

    { (yyval.qstr)=""; ;}
    break;

  case 703:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr);lab=(yyval.qstr); ;}
    break;

  case 704:

    { (yyval.qstr)="null"; (yyval.qstr)+=";"; ;}
    break;

  case 705:

    {
   (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+";"; 
 ;}
    break;

  case 706:

    { (yyval.qstr)="return "+(yyvsp[(2) - (3)].qstr)+";"  ; ;}
    break;

  case 707:

    { (yyval.qstr)=""; ;}
    break;

  case 708:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 709:

    { (yyval.qstr)=(yyvsp[(1) - (4)].qstr)+" <="+(yyvsp[(3) - (4)].qstr)+";"  ; ;}
    break;

  case 710:

    { (yyval.qstr)=(yyvsp[(1) - (5)].qstr)+ "<= "+(yyvsp[(3) - (5)].qstr)+(yyvsp[(4) - (5)].qstr) +";"; ;}
    break;

  case 711:

    { (yyval.qstr)=(yyvsp[(1) - (6)].qstr)+ "<= "+ " force  "+(yyvsp[(4) - (6)].qstr)+";" ; ;}
    break;

  case 712:

    { (yyval.qstr)=(yyvsp[(1) - (5)].qstr)+ "<= "+" release "+(yyvsp[(4) - (5)].qstr) +";"; ;}
    break;

  case 713:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 714:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 715:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+";"; ;}
    break;

  case 716:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 717:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr); ;}
    break;

  case 718:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 719:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+":"; ;}
    break;

  case 720:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+":="+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 721:

    { (yyval.qstr)=(yyvsp[(1) - (4)].qstr)+(yyvsp[(2) - (4)].qstr)+":="+(yyvsp[(4) - (4)].qstr); ;}
    break;

  case 722:

    {
                     (yyval.qstr)="wait "+(yyvsp[(2) - (5)].qstr)+(yyvsp[(3) - (5)].qstr)+(yyvsp[(4) - (5)].qstr)+";";
                  ;}
    break;

  case 723:

    { (yyval.qstr)=""; ;}
    break;

  case 724:

    { (yyval.qstr)="for "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 725:

    { (yyval.qstr)=""; ;}
    break;

  case 726:

    { (yyval.qstr)=" until "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 727:

    { (yyval.qstr)=""; ;}
    break;

  case 728:

    { (yyval.qstr)=" on "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 729:

    { lastEntity=0; lastCompound=0; genLabels.resize(0); ;}
    break;

  case 731:

    { lastCompound=0; genLabels.resize(0); ;}
    break;

  case 732:

    { lastEntity=0; genLabels.resize(0); ;}
    break;

  case 733:

    { lastEntity=0; lastCompound=0; genLabels.resize(0); ;}
    break;

  case 734:

    { currP=VhdlDocGen::COMPONENT; ;}
    break;

  case 735:

    { currP=VhdlDocGen::COMPONENT; ;}
    break;

  case 736:

    {
             addVhdlType((yyvsp[(2) - (7)].qstr),getParsedLine(t_COMPONENT),Entry::VARIABLE_SEC,VhdlDocGen::COMPONENT,0,0);
             currP=0;
           ;}
    break;

  case 737:

    { (yyval.qstr)=""; ;}
    break;

  case 738:

    { (yyval.qstr)=(yyvsp[(2) - (3)].qstr); ;}
    break;

  case 739:

    { (yyval.qstr)=""; ;}
    break;

  case 740:

    { (yyval.qstr)=(yyvsp[(2) - (3)].qstr); ;}
    break;

  case 741:

    { levelCounter--; ;}
    break;

  case 742:

    {
          ;}
    break;

  case 743:

    { (yyval.qstr)=""; ;}
    break;

  case 744:

    { (yyval.qstr)=""; ;}
    break;

  case 745:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+"  "; ;}
    break;

  case 746:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 747:

    { (yyval.qstr)=""; ;}
    break;

  case 748:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr); ;}
    break;

  case 749:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 750:

    {
      (yyval.qstr)=(yyvsp[(1) - (1)].qstr);
      if (levelCounter==0)
        addConfigureNode((yyvsp[(1) - (1)].qstr).data(),NULL,TRUE,FALSE);
      else
        addConfigureNode((yyvsp[(1) - (1)].qstr).data(),NULL,FALSE,FALSE);
        levelCounter++;
    ;}
    break;

  case 751:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 752:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 753:

    {
               (yyval.qstr)=(yyvsp[(2) - (7)].qstr)+" "+(yyvsp[(3) - (7)].qstr)+" "+(yyvsp[(4) - (7)].qstr);
             ;}
    break;

  case 754:

    { (yyval.qstr)=""; ;}
    break;

  case 755:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 756:

    { (yyval.qstr)=""; ;}
    break;

  case 757:

    { 
  (yyval.qstr)=""; 
;}
    break;

  case 758:

    { (yyval.qstr)=""; ;}
    break;

  case 759:

    {
               addConfigureNode(compSpec.data(),(yyvsp[(2) - (3)].qstr).data(),FALSE,TRUE);
             ;}
    break;

  case 760:

    { 
               addConfigureNode((yyvsp[(2) - (4)].qstr).data(),(yyvsp[(3) - (4)].qstr).data(),TRUE,FALSE,TRUE);
             ;}
    break;

  case 761:

    { 
               addConfigureNode((yyvsp[(2) - (7)].qstr).data(),(yyvsp[(3) - (7)].qstr).data(),TRUE,FALSE,TRUE);
              ;}
    break;

  case 762:

    { 
                                                     (yyval.qstr)=(yyvsp[(2) - (2)].qstr);
                                                   ;}
    break;

  case 763:

    { 
  (yyval.qstr)="";
;}
    break;

  case 764:

    { 
                          (yyval.qstr)="";
                           ;}
    break;

  case 765:

    {
               (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+":"+(yyvsp[(3) - (3)].qstr);
               compSpec=(yyval.qstr);
             ;}
    break;

  case 766:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 767:

    { (yyval.qstr)="all"; ;}
    break;

  case 768:

    { (yyval.qstr)="others"; ;}
    break;

  case 769:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr); ;}
    break;

  case 770:

    { (yyval.qstr)=""; ;}
    break;

  case 771:

    { (yyval.qstr)="port map "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 772:

    { (yyval.qstr)=""; ;}
    break;

  case 773:

    { (yyval.qstr)="generic map "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 774:

    { (yyval.qstr)="entity "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 775:

    { (yyval.qstr)="configuration "+ (yyvsp[(2) - (2)].qstr); ;}
    break;

  case 776:

    { (yyval.qstr)="open "; ;}
    break;

  case 777:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 778:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 779:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 780:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+","+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 781:

    {
                      // $$=$2+":"+$4+$6;
                      (yyval.qstr)="("+(yyvsp[(4) - (8)].qstr)+(yyvsp[(6) - (8)].qstr)+")";
                      addVhdlType((yyvsp[(2) - (8)].qstr),getParsedLine(t_GROUP),Entry::VARIABLE_SEC,VhdlDocGen::GROUP,(yyval.qstr).data(),0);
                    ;}
    break;

  case 782:

    {
                      (yyval.qstr)=(yyvsp[(2) - (7)].qstr)+":"+(yyvsp[(5) - (7)].qstr);
                      addVhdlType((yyvsp[(2) - (7)].qstr),getParsedLine(t_GROUP),Entry::VARIABLE_SEC,VhdlDocGen::GROUP,(yyvsp[(5) - (7)].qstr).data(),0);
                    ;}
    break;

  case 783:

    { (yyval.qstr)=""; ;}
    break;

  case 784:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 785:

    { (yyval.qstr)="";   ;}
    break;

  case 786:

    { (yyval.qstr)="<>"; ;}
    break;

  case 787:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 788:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+","+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 789:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 790:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 791:

    {
      (yyval.qstr)=s_str.qstr;
    ;}
    break;

  case 792:

    {
      (yyval.qstr)=s_str.qstr;
    ;}
    break;

  case 793:

    {
      (yyval.qstr)=s_str.qstr;
    ;}
    break;

  case 794:

    {
      (yyval.qstr)=s_str.qstr;
    ;}
    break;

  case 795:

    {
      (yyval.qstr)=s_str.qstr;
    ;}
    break;

  case 796:

    { (yyval.qstr)=""; ;}
    break;

  case 797:

    { (yyval.qstr)=""; ;}
    break;

  case 807:

    { (yyval.qstr)=""; ;}
    break;

  case 808:

    { (yyval.qstr)=""; ;}
    break;

  case 815:

    { (yyval.qstr)="context "+(yyvsp[(2) - (3)].qstr); ;}
    break;

  case 816:

    { parse_sec=CONTEXT_SEC; ;}
    break;

  case 817:

    {
                          parse_sec=0;
                          QCString v=(yyvsp[(5) - (8)].qstr);
                          addVhdlType((yyvsp[(2) - (8)].qstr),getParsedLine(t_LIBRARY),Entry::VARIABLE_SEC,VhdlDocGen::LIBRARY,"context",(yyvsp[(5) - (8)].qstr).data());
                        ;}
    break;

  case 818:

    {
                          addVhdlType((yyvsp[(2) - (6)].qstr),getParsedLine(t_LIBRARY),Entry::VARIABLE_SEC,VhdlDocGen::LIBRARY,"context",0);
                        ;}
    break;

  case 821:

    { (yyval.qstr) = (yyvsp[(1) - (1)].qstr); ;}
    break;

  case 822:

    { (yyval.qstr) = (yyvsp[(1) - (2)].qstr)+"#"+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 823:

    { (yyval.qstr) = (yyvsp[(1) - (1)].qstr); ;}
    break;

  case 824:

    { (yyval.qstr) = (yyvsp[(1) - (1)].qstr); ;}
    break;

  case 825:

    { (yyval.qstr) = (yyvsp[(1) - (1)].qstr); ;}
    break;

  case 826:

    {
      (yyval.qstr)=" is new "+(yyvsp[(5) - (7)].qstr)+(yyvsp[(6) - (7)].qstr);
      //Entry * pp=lastCompound;
      //Entry * pps=lastEntity  ;
      //assert(false);
      addVhdlType((yyvsp[(2) - (7)].qstr),getParsedLine(t_PACKAGE),Entry::VARIABLE_SEC,VhdlDocGen::INSTANTIATION,"package",(yyval.qstr).data());
    ;}
    break;

  case 827:

    {
      (yyval.qstr)=" is new "+(yyvsp[(5) - (8)].qstr)+(yyvsp[(6) - (8)].qstr);
      addVhdlType((yyvsp[(2) - (8)].qstr),getParsedLine(t_PACKAGE),Entry::VARIABLE_SEC,VhdlDocGen::INSTANTIATION,"package",(yyval.qstr).data());
    ;}
    break;

  case 828:

    { (yyval.qstr)=""; ;}
    break;

  case 829:

    {
      (yyval.qstr)= " is new "+(yyvsp[(5) - (7)].qstr)+(yyvsp[(6) - (7)].qstr);
      addVhdlType((yyvsp[(2) - (7)].qstr),getParsedLine(t_FUNCTION),Entry::VARIABLE_SEC,VhdlDocGen::INSTANTIATION,"function ",(yyval.qstr).data());
    ;}
    break;

  case 830:

    {
      (yyval.qstr)=" is new "+(yyvsp[(5) - (8)].qstr)+(yyvsp[(6) - (8)].qstr);
      addVhdlType((yyvsp[(2) - (8)].qstr),getParsedLine(t_FUNCTION),Entry::VARIABLE_SEC,VhdlDocGen::INSTANTIATION,"function ",(yyval.qstr).data());
    ;}
    break;

  case 831:

    { (yyval.qstr)=""; ;}
    break;

  case 832:

    { (yyval.qstr)=""; ;}
    break;

  case 833:

    { (yyval.qstr)="["+(yyvsp[(2) - (3)].qstr)+" ]"; ;}
    break;

  case 834:

    { (yyval.qstr)="[ ]"; ;}
    break;

  case 835:

    { (yyval.qstr)="return "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 836:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 837:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" return "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 838:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 839:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 840:

    { (yyval.qstr)=" , "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 850:

    { (yyval.qstr)=""; ;}
    break;

  case 851:

    { (yyval.qstr)=""; ;}
    break;

  case 861:

    { (yyval.qstr)=""; ;}
    break;

  case 862:

    { (yyval.qstr)=""; ;}
    break;

  case 870:

    { (yyval.qstr)=""; ;}
    break;

  case 871:

    { (yyval.qstr)=" in "; ;}
    break;

  case 872:

    { (yyval.qstr)="out"; ;}
    break;

  case 873:

    { (yyval.qstr)=" transport "; ;}
    break;

  case 874:

    { (yyval.qstr)=" reject "+(yyvsp[(2) - (3)].qstr)+"inertial "; ;}
    break;

  case 875:

    { (yyval.qstr)=" inertial "; ;}
    break;

  case 881:

    { (yyval.qstr)=""; ;}
    break;

  case 887:

    { (yyval.qstr) = (yyvsp[(1) - (1)].qstr); ;}
    break;

  case 888:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 889:

    { (yyval.qstr) = "procedure "+(yyvsp[(2) - (3)].qstr)+(yyvsp[(3) - (3)].qstr); current->name=(yyvsp[(2) - (3)].qstr); ;}
    break;

  case 890:

    {
      QCString s=(yyvsp[(6) - (6)].qstr);
      if (!s.isEmpty())
      {
        s.prepend(" is ");
      }
      (yyval.qstr)=" function "+(yyvsp[(2) - (6)].qstr)+(yyvsp[(3) - (6)].qstr)+(yyvsp[(5) - (6)].qstr)+s;
      current->name=(yyvsp[(2) - (6)].qstr);
    ;}
    break;

  case 891:

    {
      QCString s=(yyvsp[(7) - (7)].qstr);
      if (!s.isEmpty())
      {
        s.prepend(" is ");
      }
      (yyval.qstr)=(yyvsp[(1) - (7)].qstr)+" function "+(yyvsp[(3) - (7)].qstr)+(yyvsp[(4) - (7)].qstr)+" return "+(yyvsp[(6) - (7)].qstr)+s;
      current->name=(yyvsp[(3) - (7)].qstr);
    ;}
    break;

  case 892:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 893:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 894:

    { (yyval.qstr)="";   ;}
    break;

  case 895:

    { (yyval.qstr)=(yyvsp[(2) - (2)].qstr);   ;}
    break;

  case 896:

    { (yyval.qstr)="<>"; ;}
    break;

  case 897:

    { (yyval.qstr)=""; ;}
    break;

  case 898:

    { (yyval.qstr)="parameter "; ;}
    break;

  case 899:

    { parse_sec=PARAM_SEC; ;}
    break;

  case 900:

    { parse_sec=0; ;}
    break;

  case 901:

    { (yyval.qstr)="("+(yyvsp[(2) - (4)].qstr)+")"; ;}
    break;

  case 902:

    {
                          (yyval.qstr)="package "+(yyvsp[(2) - (5)].qstr)+" is new "+(yyvsp[(5) - (5)].qstr);
                          current->name=(yyvsp[(2) - (5)].qstr);
                        ;}
    break;

  case 903:

    { 
                          (yyval.qstr)="package "+(yyvsp[(2) - (6)].qstr)+" is new "+(yyvsp[(5) - (6)].qstr)+"( ... )" ; 
                          current->name=(yyvsp[(2) - (6)].qstr); 
                        ;}
    break;

  case 905:

    {
                          //int u=s_str.iLine;
                          parse_sec=GEN_SEC;
                        ;}
    break;

  case 906:

    {
                          QCString vo=(yyvsp[(3) - (3)].qstr);
                          parse_sec=0;
                        ;}
    break;

  case 907:

    {
                          QCString s="<<"+(yyvsp[(2) - (6)].qstr);
                          QCString s1=(yyvsp[(3) - (6)].qstr)+":"+(yyvsp[(5) - (6)].qstr)+">>";
                          (yyval.qstr)=s+s1;
                        ;}
    break;

  case 908:

    { (yyval.qstr)="constant "; ;}
    break;

  case 909:

    { (yyval.qstr)="signal ";   ;}
    break;

  case 910:

    { (yyval.qstr)="variable "; ;}
    break;

  case 911:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 912:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 913:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 914:

    { (yyval.qstr)="."+(yyvsp[(2) - (3)].qstr)+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 915:

    { (yyval.qstr)="."+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 916:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+(yyvsp[(2) - (3)].qstr)+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 917:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 918:

    { (yyval.qstr)="^."; ;}
    break;

  case 919:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"^."; ;}
    break;

  case 920:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 921:

    { (yyval.qstr)=(yyvsp[(1) - (4)].qstr)+"("+(yyvsp[(3) - (4)].qstr)+")"; ;}
    break;

  case 922:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+"."; ;}
    break;

  case 923:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+(yyvsp[(2) - (3)].qstr)+"."; ;}
    break;

  case 924:

    { (yyval.qstr)="@"+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 925:

    {
// fprintf(stderr,"\n  tooldir %s",s_str.qstr.data() );
;}
    break;


/* Line 1267 of yacc.c.  */

      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}




extern FILE* yyout;
extern YYSTYPE vhdlScanYYlval;

void vhdlScanYYerror(const char* /*str*/)
{
  //  fprintf(stderr,"\n<---error at line %d  : [ %s]   in file : %s ---->",s_str.yyLineNr,s_str.qstr.data(),s_str.fileName);
  //   exit(0);
}

void vhdlParse()
{
  vhdlScanYYparse();
}

struct VhdlContainer*  getVhdlCont()
{
  return &s_str;
}

Entry* getVhdlCompound()
{
  if (lastEntity) return lastEntity;
  if (lastCompound) return lastCompound;
  return NULL;
}

QList<VhdlConfNode>& getVhdlConfiguration() { return  configL; }

static void addCompInst(char *n, char* instName, char* comp,int iLine)
{

  current->spec=VhdlDocGen::INSTANTIATION;
  current->section=Entry::VARIABLE_SEC;
  current->startLine=iLine;
  current->bodyLine=iLine;
  current->type=instName;                       // foo:instname e.g proto or work. proto(ttt)
  current->exception=genLabels.lower();         // |arch|label1:label2...
  current->name=n;                              // foo
  current->args=lastCompound->name;             // architecture name
  current->includeName=comp;                    // component/enity/configuration
  int u=genLabels.find("|",1);
  if (u>0)
  {
    current->write=genLabels.right(genLabels.length()-u);
    current->read=genLabels.left(u);
  }
  //printf  (" \n genlable: [%s]  inst: [%s]  name: [%s] %d\n",n,instName,comp,iLine);

  if (lastCompound)
  {
    current->args=lastCompound->name;
    if (true) // !findInstant(current->type))
    {
      initEntry(current);
      instFiles.append(new Entry(*current));
    }

    Entry *temp=current;  // hold  current pointer  (temp=oldEntry)
    current=new Entry;     // (oldEntry != current)
    delete  temp;
  }
  else
  {
    newEntry();
  }
}

static void pushLabel( QCString &label,QCString & val)
{
  label+="|";
  label+=val;
}

static QCString  popLabel(QCString & q)
{
  QCString u=q;
  int i=q.findRev("|");
  if (i<0) return "";
  q = q.left(i);
  return q;
}

static void addConfigureNode(const char* a,const char*b, bool,bool isLeaf,bool inlineConf)
{
  VhdlConfNode* co;
  QCString ent,arch,lab;
  QCString l=genLabels;
  ent=a;
  lab =  VhdlDocGen::parseForConfig(ent,arch);

  if (b)
  {
    ent=b;
    lab=VhdlDocGen::parseForBinding(ent,arch);
  }
  int level=0;

  if(!configL.isEmpty())
  {
    VhdlConfNode* vc=configL.last();
    level=vc->level;
    if (level<levelCounter)
    {
      if (!isLeaf)
      {
        pushLabel(forL,ent);
      }
    }
    else if (level>levelCounter)
    {
      forL=popLabel(forL); 
    }
  }
  else
  {
    pushLabel(forL,ent);
  }


  if (inlineConf)
  {
    confName=lastCompound->name;
  }

  //fprintf(stderr,"\n[%s %d %d]\n",forL.data(),levelCounter,level);
  co=new VhdlConfNode(a,b,confName.lower().data(),forL.lower().data(),isLeaf);

  if (inlineConf)
  {
    co->isInlineConf=TRUE;
  }

  configL.append(co);

}// addConfigure

//  ------------------------------------------------------------------------------------------------------------

static bool isFuncProcProced()
{
  if (currP==VhdlDocGen::FUNCTION ||
      currP==VhdlDocGen::PROCEDURE ||
      currP==VhdlDocGen::PROCESS
     )
  {
    return TRUE;
  }
  return FALSE;
}

static void initEntry(Entry *e)
{
  e->fileName = s_str.fileName;
  e->lang=SrcLangExt_VHDL;
  isVhdlDocPending();
  initGroupInfo(e);
}

static void addProto(const char *s1,const char *s2,const char *s3,
    const char *s4,const char *s5,const char *s6)
{
  (void)s5; // avoid unused warning
  static QRegExp reg("[\\s]");
  QCString name=s2;
  QStringList ql=QStringList::split(",",name,FALSE);

  for (uint u=0;u<ql.count();u++)
  {
    Argument *arg=new Argument;
    arg->name=ql[u].utf8();
    if (s3)
    {
      arg->type=s3;
    }
    arg->type+=" ";
    arg->type+=s4;
    if (s6)
    {
      arg->type+=s6;
    }
    if (parse_sec==GEN_SEC && param_sec==0)
    {
      arg->defval="gen!";
    }

    if (parse_sec==PARAM_SEC)
    {
      assert(false);
    }

    arg->defval+=s1;
    arg->attrib="";//s6;

    current->argList->append(arg);
    current->args+=s2;
    current->args+=",";
  }
}

static void createFunction(const QCString &impure,int spec,
    const QCString &fname)
{
  int it=0;
  current->spec=spec;
  current->section=Entry::FUNCTION_SEC;

  if (impure=="impure" || impure=="pure")  
  {
    current->exception=impure;
  }

  if (parse_sec==GEN_SEC)
  {
    current->spec= VhdlDocGen::GENERIC;
    current->section=Entry::FUNCTION_SEC;
  }

  if (currP==VhdlDocGen::PROCEDURE)
  {
    current->name=impure;
    current->exception="";
    it=t_PROCEDURE;
  }
  else
  {
    current->name=fname;
    it=t_FUNCTION;
  }

  if (spec==VhdlDocGen::PROCESS)
  {
    it=t_PROCESS;
    current->args=fname;
    current->name=impure;
    VhdlDocGen::deleteAllChars(current->args,' ');
    if (!fname.isEmpty())
    {
      QStringList q1=QStringList::split(",",fname);
      for (uint ii=0;ii<q1.count();ii++)
      {
        Argument *arg=new Argument;
        arg->name=q1[ii].utf8();
        current->argList->append(arg);
      }
    }
    return;
  }

  current->startLine=getParsedLine(it);
  current->bodyLine=getParsedLine(it);
}

static void addVhdlType(const QCString &name,int startLine,int section,int spec,
    const char* args,const char* type,Protection prot)
{
  static QRegExp reg("[\\s]");

  if (isFuncProcProced() || VhdlDocGen::getFlowMember())
  {
    return;
  }

  if (parse_sec==GEN_SEC)
  {
    spec= VhdlDocGen::GENERIC;
  }

  // more than one name   ?
  QStringList ql=QStringList::split(",",name,FALSE);

  for (uint u=0;u<ql.count();u++)
  {
    current->name=ql[u].utf8();
    //   if (section==Entry::VARIABLE_SEC &&  !(spec == VhdlDocGen::USE || spec == VhdlDocGen::LIBRARY) )
    //   {
    //     current->name.prepend(VhdlDocGen::getRecordNumber());
    //   }

    current->startLine=startLine;
    current->bodyLine=startLine;
    current->section=section;
    current->spec=spec;
    current->fileName=s_str.fileName;
    if (current->args.isEmpty())
    {
      current->args=args;
      current->args.replace(reg,"%"); // insert dummy chars because wihte spaces are removed
    }
    current->type=type;
    current->type.replace(reg,"%"); // insert dummy chars because white spaces are removed
    current->protection=prot;
    newEntry();
  }
}

static void newEntry()
{
  if (current->spec==VhdlDocGen::ENTITY       ||
      current->spec==VhdlDocGen::PACKAGE      ||
      current->spec==VhdlDocGen::ARCHITECTURE ||
      current->spec==VhdlDocGen::PACKAGE_BODY
     )
  {
    current_root->addSubEntry(current);
  }
  else
  {
    if (lastCompound)
    {
      lastCompound->addSubEntry(current);
    }
    else
    {
      if (lastEntity)
      {
        lastEntity->addSubEntry(current);
      }
      else
      {
        current_root->addSubEntry(current);
      }
    }
  }
  current = new Entry ;
  initEntry(current);
}

void createFlow()
{
  if (!VhdlDocGen::getFlowMember()) 
  {
    return;
  }
  QCString q,ret;

  if (currP==VhdlDocGen::FUNCTION)
  {
    q=":function( ";
    FlowChart::alignFuncProc(q,tempEntry->argList,true);
    q+=")";
  }
  else if (currP==VhdlDocGen::PROCEDURE)
  {
    q=":procedure (";    
    FlowChart::alignFuncProc(q,tempEntry->argList,false);
    q+=")";
  }
  else  
  {  
    q=":process( "+tempEntry->args;
    q+=")";
  }

  q.prepend(VhdlDocGen::getFlowMember()->name().data());

  FlowChart::addFlowChart(FlowChart::START_NO,q,0);

  if (currP==VhdlDocGen::FUNCTION)
  {
    ret="end function ";  
  }
  else if (currP==VhdlDocGen::PROCEDURE)
  {
    ret="end procedure";
  }
  else 
  {
    ret="end process ";
  }

  FlowChart::addFlowChart(FlowChart::END_NO,ret,0);
  //  FlowChart::printFlowList();
  FlowChart::writeFlowChart();  
  currP=0;
}


